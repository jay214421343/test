plugins {
    java
}

group = "world.arvee"
version = "0.3.0"

repositories {
    mavenCentral()
    maven("https://repo.helpch.at/releases/")
    maven("https://repo.papermc.io/repository/maven-public/")
}

// Match the exact Paper API named in the user's Paper 26.3 build 222 stack trace.
// Never compile Bukkit/Paper plugins against locally-invented stub classes.
dependencies {
    compileOnly("io.papermc.paper:paper-api:26.3.build.222-stable")
    compileOnly("me.clip:placeholderapi:2.11.6")
}

java {
    toolchain.languageVersion.set(JavaLanguageVersion.of(25))
}

tasks.withType<JavaCompile> {
    options.encoding = "UTF-8"
    options.release.set(25)
}

tasks.jar {
    archiveFileName.set("ArveePrison-${project.version}-Paper26.3.jar")
}
