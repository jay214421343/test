package world.arvee.prison;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.UUID;

public final class ArveePrison extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {
    private final Random random = new Random();
    private ProfileStore profiles;
    private Worlds worlds;
    private PrisonMenus menus;
    private PrisonHotbar hotbar;
    private PrisonGangs gangs;
    private NamespacedKey pickaxeKey;
    private NamespacedKey ownerKey;

    @Override public void onEnable() {
        saveDefaultConfig();
        pickaxeKey = new NamespacedKey(this, "prison_pickaxe");
        ownerKey = new NamespacedKey(this, "pickaxe_owner");
        profiles = new ProfileStore(this);
        worlds = new Worlds(this);
        menus = new PrisonMenus(this);
        gangs = new PrisonGangs(this);
        hotbar = new PrisonHotbar(this);
        Bukkit.getPluginManager().registerEvents(this, this);
        if (Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            try {
                if (new ArveePlaceholders(this).register()) getLogger().info("Registered %arveeprison_*% PlaceholderAPI expansion.");
                else getLogger().warning("PlaceholderAPI could not register ARVEE Prison expansion.");
            } catch (Exception | LinkageError e) { getLogger().warning("PlaceholderAPI integration failed: " + e.getMessage()); }
        }

        for (String name : Arrays.asList("prison", "mines", "mine", "rankup", "prestige", "sell",
            "balance", "tokens", "pickaxe", "autosell", "quests", "backpack", "prisonstats",
            "prisonrewards", "prisonbooster", "prisonmenu", "prisonadmin",
            "prisonresearch", "prisoncontracts", "prisoncrates", "prisontop", "prisonnews", "gang")) {
            PluginCommand command = getCommand(name);
            if (command == null) { getLogger().severe("Missing command in plugin.yml: " + name); continue; }
            command.setExecutor(this);
            command.setTabCompleter(this);
        }
        Bukkit.getScheduler().runTaskTimer(this, profiles::save, 20L * 300, 20L * 300);
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (getConfig().contains("lobby-spawn")) worlds.loadConfiguredLobby();
            else if (getConfig().getBoolean("worlds.create-lobby-on-start", false)) worlds.setupLobby();
        }, 5L);
        getLogger().info("ARVEE Prison 0.3.0 enabled. Your existing mines and player data are retained.");
    }

    @Override public void onDisable() {
        if (profiles != null) profiles.save();
        if (gangs != null) gangs.save();
        if (worlds != null) worlds.saveState();
    }

    public PrisonProfile profileByUuid(UUID uuid) { return profiles.profile(uuid); }
    public PrisonProfile profile(Player player) {
        PrisonProfile p = profiles.profile(player.getUniqueId());
        p.lastName = player.getName();
        p.refreshDaily();
        return p;
    }
    public void message(CommandSender recipient, String text) {
        String prefix = getConfig().getString("messages.prefix", "&b&lARVEE &8» &7");
        recipient.sendMessage(color(prefix + text));
    }
    public String color(String str) {
        if (str == null) return "";
        java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("&#([A-Fa-f0-9]{6})").matcher(str);
        StringBuilder rgb = new StringBuilder();
        while (matcher.find()) {
            String h = matcher.group(1);
            StringBuilder out = new StringBuilder("§x");
            for (char c : h.toCharArray()) out.append('§').append(c);
            matcher.appendReplacement(rgb, java.util.regex.Matcher.quoteReplacement(out.toString()));
        }
        matcher.appendTail(rgb);
        return ChatColor.translateAlternateColorCodes('&', rgb.toString());
    }
    public PrisonHotbar hotbar() { return hotbar; }
    public PrisonGangs gangs() { return gangs; }
    public java.util.List<PrisonProfile> allProfiles() { return profiles.all(); }
    public long backpackCapacity(PrisonProfile p) {
        return p.capacity(Math.max(100, getConfig().getLong("advanced.backpack-base-capacity", 10000)),
            getConfig().getDouble("advanced.backpack-capacity-multiplier", 1.65));
    }
    public Worlds worlds() { return worlds; }
    public PrisonMenus menus() { return menus; }

    public double nextRankPrice(int rank) {
        if (rank >= 25) return Double.POSITIVE_INFINITY;
        return getConfig().getDouble("progression.rankup-base-price", 1500.0)
            * Math.pow(getConfig().getDouble("progression.rankup-price-multiplier", 1.7), rank);
    }
    public double prestigePrice(int prestige) {
        return getConfig().getDouble("progression.prestige-cost", 500000000.0) * Math.pow(3.0, prestige);
    }
    public double blockValue(PrisonProfile p, int rank, Material type) {
        double materialBonus = switch (type) {
            case COAL_ORE -> 1.15;
            case IRON_ORE -> 1.25;
            case GOLD_ORE -> 1.5;
            case DIAMOND_ORE, DEEPSLATE_DIAMOND_ORE -> 1.75;
            case EMERALD_ORE, DEEPSLATE_EMERALD_ORE -> 2.0;
            case ANCIENT_DEBRIS -> 2.6;
            default -> 1.0;
        };
        double base = getConfig().getDouble("progression.ore-base-value", 8.0);
        double byRank = getConfig().getDouble("progression.ore-rank-value-multiplier", 1.50);
        return base * Math.pow(byRank, rank) * materialBonus
            * p.multiplier(getConfig().getDouble("progression.prestige-sell-bonus-per-level", 0.2))
            * (1 + Math.max(0, p.miningLevel - 1) * getConfig().getDouble("advanced.mining-level-sell-bonus", 0.01))
            * (p.boosted() ? getConfig().getDouble("advanced.booster-sell-multiplier", 2.0) : 1.0)
            * (1 + p.researchIncome * getConfig().getDouble("research.income-bonus-per-level", .035));
    }

    @EventHandler public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        profile(player);
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (!player.isOnline()) return;
            if (getConfig().getBoolean("hotbar.give-on-join", true)) hotbar.give(player);
            if (getConfig().getBoolean("worlds.teleport-on-join", true)) {
                Location spawn = worlds.lobbySpawn();
                if (spawn != null) player.teleport(spawn);
            }
        }, 5L);
    }
    @EventHandler public void onQuit(PlayerQuitEvent event) {
        profile(event.getPlayer());
        profiles.save();
    }
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Block block = event.getBlock();
        int rank = worlds.rankFor(block.getWorld());
        if (rank < 0) { if (worlds.isLobby(block.getWorld())) event.setCancelled(true); return; }
        if (!player.hasPermission("arveeprison.admin") && (rank > profile(player).rank || !worlds.isMineBlock(block))) {
            event.setCancelled(true);
            message(player, "&cYou cannot mine here. Use /mines to select an unlocked mine.");
            return;
        }
        if (!worlds.isMineBlock(block)) { event.setCancelled(true); return; }
        if (worlds.isResetting(rank)) { event.setCancelled(true); return; }
        if (block.getType().isAir() || block.getType() == Material.BEDROCK) { event.setCancelled(true); return; }
        if (!getConfig().getBoolean("mines.allow-breaking-without-arvee-pickaxe", true) && !hasArveePickaxe(player)) {
            event.setCancelled(true);
            message(player, "&cYou must use an ARVEE pickaxe. Type /pickaxe get.");
            return;
        }
        event.setDropItems(false);
        event.setExpToDrop(0);
        PrisonProfile p = profile(player);
        creditBlock(p, rank, block.getType(), hasArveePickaxe(player));
        worlds.recordBreak(rank);
        if (p.minedBlocks % 25 == 0 && getConfig().getBoolean("advanced.mining-actionbar", true)) {
            player.sendActionBar(net.kyori.adventure.text.Component.text("ARVEE Prison | " + Amounts.format(p.minedBlocks)
                + " mined | Lv " + p.miningLevel + " | " + Amounts.rank(p.rank) + " | " + Amounts.format(p.tokens) + " tokens"));
        }
        if (p.jackhammer > 0 && hasArveePickaxe(player)
            && random.nextDouble() < Math.min(.35, p.jackhammer * getConfig().getDouble("pickaxe.jackhammer-chance-per-level", .008)
                + p.researchJackhammer * getConfig().getDouble("research.jackhammer-chance-per-level", .003))) {
            for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) continue;
                if (worlds.isResetting(rank)) return;
                Block target = block.getRelative(dx, 0, dz);
                if (!worlds.isMineBlock(target) || target.getType().isAir()) continue;
                Material type = target.getType();
                target.setType(Material.AIR, false);
                creditBlock(p, rank, type, true);
                worlds.recordBreak(rank);
            }
        }
    }

    private void creditBlock(PrisonProfile p, int rank, Material blockType, boolean customPickaxe) {
        double amount = blockValue(p, rank, blockType);
        if (customPickaxe && p.fortune > 0 && random.nextDouble() < Math.min(.75, p.fortune * .10)) {
            amount *= 2.0;
        }
        if (p.autoSellUnlocked && p.autoSellEnabled) earn(p, amount);
        else {
            long capacity = backpackCapacity(p);
            double free = Math.max(0, capacity - p.backpackValue);
            double toStore = Math.min(free, amount);
            p.backpackValue = safeAdd(p.backpackValue, toStore);
            // Overflow sells directly rather than deleting mined earnings.
            if (amount > toStore) earn(p, amount - toStore);
        }
        if (p.minedBlocks < Long.MAX_VALUE) p.minedBlocks++;
        gangs.countBlock(p.uuid);
        if (p.minedBlocks % Math.max(50, getConfig().getInt("crates.key-every-blocks", 250)) == 0
            && getConfig().getBoolean("crates.automatic-keys", true) && p.crateKeys < 1000000) {
            p.crateKeys++;
            Player owner = Bukkit.getPlayer(p.uuid);
            if (owner != null) message(owner, "&e&lKEY FOUND! &7Open it using /prisoncrates");
        }
        if (p.dailyBlocks < Integer.MAX_VALUE) p.dailyBlocks++;
        int oldLevel = p.miningLevel;
        p.addXp(Math.max(1, Math.round(getConfig().getLong("advanced.xp-per-block", 3)
            * (1 + p.researchXp * getConfig().getDouble("research.xp-bonus-per-level", .07)))));
        if (p.miningLevel > oldLevel) {
            Player player = Bukkit.getPlayer(p.uuid);
            if (player != null) message(player, "&b&lMINING LEVEL UP! &f" + oldLevel + " &7→ &b" + p.miningLevel);
        }
        if (random.nextDouble() < Math.min(.5, getConfig().getDouble("progression.tokens-chance-per-block", 0.03)
            + p.researchTokens * getConfig().getDouble("research.tokens-chance-per-level", .003))) {
            long prize = getConfig().getLong("progression.token-reward", 1);
            p.tokens = safeAddTokens(p.tokens, prize);
            p.lifetimeTokens = safeAddTokens(p.lifetimeTokens, prize);
        }
    }
    private void earn(PrisonProfile p, double amount) {
        p.money = safeAdd(p.money, amount);
        p.totalEarned = Math.max(p.totalEarned, (long) Math.min(Long.MAX_VALUE,
            (double)p.totalEarned + Math.max(0, amount)));
    }
    static double safeAdd(double a, double b) {
        double sum = a + b;
        return !Double.isFinite(sum) ? Double.MAX_VALUE : Math.max(0, sum);
    }
    static long safeAddTokens(long a, long b) { return b > Long.MAX_VALUE - a ? Long.MAX_VALUE : a + b; }

    @EventHandler(ignoreCancelled = true) public void onPlace(BlockPlaceEvent e) {
        if (worlds.rankFor(e.getBlock().getWorld()) >= 0 || worlds.isLobby(e.getBlock().getWorld())) e.setCancelled(true);
    }
    @EventHandler(ignoreCancelled = true) public void onExplosion(EntityExplodeEvent e) {
        if (worlds.rankFor(e.getLocation().getWorld()) >= 0 || worlds.isLobby(e.getLocation().getWorld())) e.blockList().clear();
    }
    @EventHandler(ignoreCancelled = true) public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player && (worlds.rankFor(e.getEntity().getWorld()) >= 0 || worlds.isLobby(e.getEntity().getWorld()))
            && (e.getCause() == EntityDamageEvent.DamageCause.FALL || e.getCause() == EntityDamageEvent.DamageCause.VOID)) {
            e.setCancelled(true);
        }
    }

    private boolean isPrisonPickaxe(ItemStack item) {
        return item != null && item.hasItemMeta()
            && item.getItemMeta().getPersistentDataContainer().has(pickaxeKey, PersistentDataType.BYTE);
    }
    public boolean hasArveePickaxe(Player player) {
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item.getType() != Material.NETHERITE_PICKAXE || !isPrisonPickaxe(item)) return false;
        String owner = item.getItemMeta().getPersistentDataContainer().get(ownerKey, PersistentDataType.STRING);
        return player.getUniqueId().toString().equals(owner);
    }
    @EventHandler(ignoreCancelled = true) public void onDrop(PlayerDropItemEvent e) {
        if (isPrisonPickaxe(e.getItemDrop().getItemStack())) {
            e.setCancelled(true);
            message(e.getPlayer(), "&cYour ARVEE pickaxe is soulbound and cannot be dropped.");
        }
    }
    @EventHandler public void onDeath(PlayerDeathEvent e) {
        e.getDrops().removeIf(this::isPrisonPickaxe);
    }
    public void grantPickaxe(Player player) {
        PrisonProfile p = profile(player);
        ItemStack pickaxe = new ItemStack(Material.NETHERITE_PICKAXE);
        ItemMeta meta = pickaxe.getItemMeta();
        meta.setDisplayName(color("&b&lARVEE &f&lPRISON PICKAXE"));
        int efficiency = getConfig().getInt("pickaxe.base-efficiency", 3)
            + p.efficiency * getConfig().getInt("pickaxe.efficiency-per-upgrade", 2);
        meta.addEnchant(Enchantment.EFFICIENCY, efficiency, true);
        meta.setUnbreakable(true);
        meta.getPersistentDataContainer().set(pickaxeKey, PersistentDataType.BYTE, (byte) 1);
        meta.getPersistentDataContainer().set(ownerKey, PersistentDataType.STRING, player.getUniqueId().toString());
        meta.setLore(Arrays.asList(color("&7Efficiency Upgrade: &b" + p.efficiency),
            color("&7Fortune Upgrade: &b" + p.fortune),
            color("&7Jackhammer Upgrade: &b" + p.jackhammer),
            color("&8Use /pickaxe to improve this tool.")));
        pickaxe.setItemMeta(meta);
        for (int slot = 0; slot < player.getInventory().getSize(); slot++) {
            ItemStack old = player.getInventory().getItem(slot);
            if (old != null && isPrisonPickaxe(old)) {
                player.getInventory().setItem(slot, pickaxe);
                message(player, "&aARVEE Pickaxe updated.");
                return;
            }
        }
        if (player.getInventory().firstEmpty() == -1) {
            message(player, "&cInventory full. Clear a slot before claiming your pickaxe.");
            return;
        }
        player.getInventory().addItem(pickaxe);
        message(player, "&aReceived your ARVEE Prison Pickaxe!");
    }

    // Research is bought with earned tokens and bounded per node.
    public void research(Player player, String node) {
        PrisonProfile p = profile(player);
        int level = switch (node) {
            case "income" -> p.researchIncome;
            case "tokens" -> p.researchTokens;
            case "xp" -> p.researchXp;
            case "jackhammer" -> p.researchJackhammer;
            default -> -1;
        };
        if (level < 0) { message(player, "&cUnknown research path."); return; }
        int cap = Math.max(1, Math.min(10, getConfig().getInt("research.max-level", 10)));
        if (level >= cap) { message(player, "&eResearch already mastered!"); return; }
        int requiredMiningLevel = (level + 1) * Math.max(1, getConfig().getInt("research.mining-level-per-tier", 4));
        if (p.miningLevel < requiredMiningLevel) { message(player, "&cRequires mining level " + requiredMiningLevel + "."); return; }
        long base = Math.max(1, getConfig().getLong("research.base-token-cost", 100));
        long cost = Math.min(Long.MAX_VALUE / 2, base * (long)(level + 1) * (level + 1));
        if (p.tokens < cost) { message(player, "&cThis research costs &e" + Amounts.format(cost) + " tokens."); return; }
        p.tokens -= cost;
        switch (node) {
            case "income" -> p.researchIncome++;
            case "tokens" -> p.researchTokens++;
            case "xp" -> p.researchXp++;
            case "jackhammer" -> p.researchJackhammer++;
        }
        message(player, "&aResearch complete! &f" + node + " &7» &bLevel " + (level + 1));
        menus.openResearch(player);
    }

    public void claimContract(Player player, int tier) {
        if (tier < 0 || tier > 2) return;
        PrisonProfile p = profile(player);
        p.refreshDaily();
        if ((p.contractClaims & (1 << tier)) != 0) { message(player, "&eContract already claimed today."); return; }
        int goal = getConfig().getInt("contracts.tier-" + (tier + 1) + "-blocks", new int[]{150,500,1500}[tier]);
        if (p.dailyBlocks < goal) { message(player, "&cMine " + (goal - p.dailyBlocks) + " more blocks to complete this contract."); return; }
        long tokenPrize = getConfig().getLong("contracts.tier-" + (tier + 1) + "-tokens", (tier + 1) * 75);
        double moneyPrize = getConfig().getDouble("contracts.tier-" + (tier + 1) + "-money", (tier + 1) * 15000)
            * Math.pow(1.20, Math.min(25, p.rank));
        p.contractClaims |= (1 << tier);
        p.tokens = safeAddTokens(p.tokens, Math.max(0,tokenPrize));
        p.lifetimeTokens = safeAddTokens(p.lifetimeTokens, Math.max(0,tokenPrize));
        earn(p, Math.max(0,moneyPrize));
        message(player, "&a&lCONTRACT COMPLETE! &6$" + Amounts.format(moneyPrize) + " &7+ &e" + tokenPrize + " tokens");
        menus.openContracts(player);
    }

    public void openCrate(Player player) {
        PrisonProfile p = profile(player);
        if (p.crateKeys < 1) { message(player, "&eYou need a key. Mine to earn crate keys!"); return; }
        p.crateKeys--;
        p.cratesOpened++;
        int roll = random.nextInt(100);
        if (roll < 50) {
            long reward = (long)(20 + random.nextInt(41)) * (1 + p.prestige);
            p.tokens = safeAddTokens(p.tokens, reward);
            p.lifetimeTokens = safeAddTokens(p.lifetimeTokens, reward);
            message(player, "&e&lCRATE &7» &a+" + reward + " tokens");
        } else if (roll < 90) {
            double reward = 2500 * (1 + p.rank) * (1 + p.prestige);
            earn(p, reward);
            message(player, "&e&lCRATE &7» &6+$" + Amounts.format(reward));
        } else {
            long bonus = 10 * 60_000L;
            p.boosterUntil = Math.max(System.currentTimeMillis(),p.boosterUntil) + bonus;
            message(player, "&e&lCRATE &7» &d10-minute income boost!");
        }
        menus.openCrates(player);
    }

    public void leaderboard(Player player, String key) {
        java.util.Comparator<PrisonProfile> comparator = switch (key) {
            case "prestige" -> java.util.Comparator.comparingInt((PrisonProfile p) -> p.prestige).reversed()
                .thenComparing(java.util.Comparator.comparingLong((PrisonProfile p) -> p.minedBlocks).reversed());
            case "level" -> java.util.Comparator.comparingInt((PrisonProfile p) -> p.miningLevel).reversed();
            case "money" -> java.util.Comparator.comparingDouble((PrisonProfile p) -> p.money).reversed();
            default -> java.util.Comparator.comparingLong((PrisonProfile p) -> p.minedBlocks).reversed();
        };
        message(player, "&b&lPRISON LEADERBOARD &7- &f" + key);
        java.util.List<PrisonProfile> sorted = profiles.all().stream().sorted(comparator).limit(10).toList();
        for (int i = 0; i < sorted.size(); i++) {
            PrisonProfile s = sorted.get(i);
            String amount = switch (key) {
                case "prestige" -> "P" + s.prestige;
                case "level" -> "Lv " + s.miningLevel;
                case "money" -> "$" + Amounts.format(s.money);
                default -> Amounts.format(s.minedBlocks) + " blocks";
            };
            player.sendMessage(color("&8#" + (i + 1) + " &f" + (s.lastName == null ? s.uuid.toString().substring(0,8) : s.lastName) + " &7- &e" + amount));
        }
    }

    private void rankup(Player player, boolean max) {
        PrisonProfile p = profile(player);
        int purchases = 0;
        while (p.rank < 25) {
            double cost = nextRankPrice(p.rank);
            if (p.money < cost) break;
            p.money -= cost;
            p.rank++;
            purchases++;
            if (!max) break;
        }
        if (purchases == 0) {
            if (p.rank == 25) message(player, "&eYou're rank Z! Save up for /prestige.");
            else message(player, "&cRank " + Amounts.rank(p.rank + 1) + " costs &6$" + Amounts.format(nextRankPrice(p.rank)) + "&c.");
            return;
        }
        message(player, "&aRanked up " + purchases + " time(s)! You're now &bRank " + Amounts.rank(p.rank) + "&a!");
    }
    private void prestige(Player player) {
        PrisonProfile p = profile(player);
        if (p.rank != 25) { message(player, "&cReach Rank Z before prestiging."); return; }
        double cost = prestigePrice(p.prestige);
        if (p.money < cost) { message(player, "&cPrestige costs &6$" + Amounts.format(cost) + "&c."); return; }
        p.money -= cost;
        p.prestige++;
        p.rank = 0;
        message(player, "&6&lPRESTIGE! &eNow Prestige " + p.prestige + ". You keep your upgrades and gain a permanent sell bonus!");
        worlds.travel(player, 0);
    }
    private void sell(Player player) {
        PrisonProfile p = profile(player);
        if (p.backpackValue <= 0) { message(player, "&eYour virtual backpack is empty."); return; }
        double amount = p.backpackValue;
        earn(p, amount);
        p.backpackValue = 0;
        message(player, "&aSold your ores for &6$" + Amounts.format(amount) + "&a!");
    }
    private void toggleAutoSell(Player player) {
        PrisonProfile p = profile(player);
        if (!p.autoSellUnlocked) { message(player, "&cUnlock Auto-Sell through /pickaxe first."); return; }
        p.autoSellEnabled = !p.autoSellEnabled;
        message(player, "&fAuto-Sell is now " + (p.autoSellEnabled ? "&aENABLED" : "&cDISABLED"));
    }
    private void quests(Player player, boolean claim) {
        PrisonProfile p = profile(player);
        int target = getConfig().getInt("quests.daily-blocks", 400);
        if (!claim) {
            message(player, "&bDaily Quest: &fMine " + target + " blocks. Progress: &e" + Math.min(target, p.dailyBlocks) + "/" + target
                + "&7 | &fClaimed: " + (p.claimedDaily ? "&aYes" : "&cNo") + "&7 | &fUse /quests claim");
            return;
        }
        if (p.claimedDaily) { message(player, "&cYou've already claimed today's quest."); return; }
        if (p.dailyBlocks < target) { message(player, "&cMine " + (target - p.dailyBlocks) + " more blocks first."); return; }
        p.claimedDaily = true;
        double money = getConfig().getDouble("quests.reward-money", 30000);
        long tokens = getConfig().getLong("quests.reward-tokens", 75);
        p.money = safeAdd(p.money, money);
        p.tokens = safeAddTokens(p.tokens, tokens);
        message(player, "&aDaily quest complete! &6$" + Amounts.format(money) + " &7+ &e" + tokens + " tokens&a!");
    }

    public void upgradeBackpack(Player player) {
        PrisonProfile p = profile(player);
        int max = Math.max(1, getConfig().getInt("advanced.backpack-max-level", 40));
        if (p.backpackLevel >= max) { message(player, "&eYour backpack is fully upgraded."); return; }
        long cost = (long)getConfig().getInt("advanced.backpack-upgrade-token-cost", 75) * (p.backpackLevel + 1L);
        if (p.tokens < cost) { message(player, "&cYou need " + Amounts.format(cost) + " tokens."); return; }
        p.tokens -= cost;
        p.backpackLevel++;
        message(player, "&aBackpack upgraded! &fCapacity: &6$" + Amounts.format(backpackCapacity(p)));
        menus.openBackpack(player);
    }
    public void purchaseBooster(Player player) {
        PrisonProfile p = profile(player);
        long cost = Math.max(1, getConfig().getLong("advanced.booster-price-tokens", 200));
        if (p.tokens < cost) { message(player, "&cNot enough tokens for the booster (&e" + cost + "&c)."); return; }
        long millis = Math.max(1, getConfig().getLong("advanced.booster-duration-minutes", 30)) * 60_000L;
        p.tokens -= cost;
        p.boosterUntil = Math.max(System.currentTimeMillis(), p.boosterUntil) + millis;
        p.boosterPurchases++;
        message(player, "&aBooster purchased! Your ore values are increased for " + (millis / 60000) + " minutes.");
        menus.openRewards(player);
    }
    public void claimLoginReward(Player player) {
        PrisonProfile p = profile(player);
        java.time.LocalDate today = java.time.LocalDate.now(java.time.ZoneOffset.UTC);
        if (today.toString().equals(p.lastDailyClaim)) { message(player, "&eYou have already claimed today's reward (UTC)."); return; }
        boolean consecutive = today.minusDays(1).toString().equals(p.lastDailyClaim);
        p.dailyStreak = consecutive ? Math.min(365, p.dailyStreak + 1) : 1;
        p.lastDailyClaim = today.toString();
        double money = Math.max(0, getConfig().getDouble("advanced.daily-login-money", 1000))
            * (1 + Math.max(0, p.dailyStreak - 1) * getConfig().getDouble("advanced.daily-streak-money-multiplier", .1));
        long tokens = Math.max(0, getConfig().getLong("advanced.daily-login-tokens", 20));
        earn(p, money);
        p.tokens = safeAddTokens(p.tokens, tokens);
        p.lifetimeTokens = safeAddTokens(p.lifetimeTokens, tokens);
        message(player, "&aDaily login claimed! &6$" + Amounts.format(money) + " &7+ &e" + tokens
            + " tokens &7| &bStreak " + p.dailyStreak);
        menus.openRewards(player);
    }
    public void claimAchievement(Player player) {
        PrisonProfile p = profile(player);
        java.util.List<Integer> thresholds = getConfig().getIntegerList("advanced.achievement-thresholds");
        int index = p.achievementClaims;
        if (index >= thresholds.size()) { message(player, "&aAll mining milestones claimed!"); return; }
        int target = thresholds.get(index);
        if (p.minedBlocks < target) { message(player, "&cMine " + (target - p.minedBlocks) + " more blocks."); return; }
        java.util.List<Integer> money = getConfig().getIntegerList("advanced.achievement-rewards-money");
        java.util.List<Integer> tokens = getConfig().getIntegerList("advanced.achievement-rewards-tokens");
        double rewardMoney = index < money.size() ? Math.max(0, money.get(index)) : 0;
        long rewardTokens = index < tokens.size() ? Math.max(0, tokens.get(index)) : 0;
        p.achievementClaims++;
        earn(p, rewardMoney);
        p.tokens = safeAddTokens(p.tokens, rewardTokens);
        p.lifetimeTokens = safeAddTokens(p.lifetimeTokens, rewardTokens);
        message(player, "&6&lMILESTONE! &aClaimed &6$" + Amounts.format(rewardMoney) + " &7+ &e" + rewardTokens + " tokens!");
        menus.openRewards(player);
    }
    private void detailedStats(Player player) {
        PrisonProfile p = profile(player);
        message(player, "&b&lPRISON PROFILE &7| &fRank &b" + Amounts.rank(p.rank) + " &7| &fPrestige &6" + p.prestige);
        message(player, "&fMining Lv. &b" + p.miningLevel + " &8(" + p.miningXp + "/" + p.xpToNextLevel() + " XP&8) &7| &fBlocks &e" + Amounts.format(p.minedBlocks));
        message(player, "&fBalance &6$" + Amounts.format(p.money) + " &7| &fTokens &e" + Amounts.format(p.tokens));
        message(player, "&fBackpack &6$" + Amounts.format(p.backpackValue) + "&7 / &6$" + Amounts.format(backpackCapacity(p)));
        message(player, "&fBooster: " + (p.boosted() ? "&aActive" : "&cInactive") + " &7| &fDaily streak: &e" + p.dailyStreak);
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String cmd = command.getName().toLowerCase(Locale.ROOT);
        if (cmd.equals("prisonadmin")) return admin(sender, args);
        if (!(sender instanceof Player player)) { message(sender, "&cThis is a player command."); return true; }
        PrisonProfile p = profile(player);
        switch (cmd) {
            case "prison" -> menus.openMain(player);
            case "prisonstats" -> detailedStats(player);
            case "prisonmenu" -> {
                String mode = args.length == 0 ? "get" : args[0].toLowerCase(Locale.ROOT);
                switch (mode) {
                    case "off" -> { p.menuEnabled = false; hotbar.remove(player); message(player, "&7Hotbar Prison menu disabled. Use /prisonmenu on to re-enable."); }
                    case "on", "get" -> { p.menuEnabled = true; hotbar.give(player); message(player, "&aPrison hotbar menu enabled."); }
                    default -> message(player, "&cUsage: /prisonmenu [on|off|get]");
                }
            }
            case "backpack" -> { if (args.length > 0 && args[0].equalsIgnoreCase("upgrade")) upgradeBackpack(player); else menus.openBackpack(player); }
            case "prisonrewards" -> {
                if (args.length > 0 && args[0].equalsIgnoreCase("daily")) claimLoginReward(player);
                else if (args.length > 0 && args[0].equalsIgnoreCase("milestone")) claimAchievement(player);
                else menus.openRewards(player);
            }
            case "prisonbooster" -> { if (args.length > 0 && args[0].equalsIgnoreCase("buy")) purchaseBooster(player); else menus.openRewards(player); }
            case "prisonresearch" -> {
                if (args.length > 0) research(player, args[0].toLowerCase(Locale.ROOT));
                else menus.openResearch(player);
            }
            case "prisoncontracts" -> {
                if (args.length > 0) {
                    try { claimContract(player, Integer.parseInt(args[0]) - 1); }
                    catch (NumberFormatException e) { message(player, "&cUsage: /prisoncontracts [1|2|3]"); }
                } else menus.openContracts(player);
            }
            case "prisoncrates" -> { if (args.length > 0 && args[0].equalsIgnoreCase("open")) openCrate(player); else menus.openCrates(player); }
            case "prisontop" -> leaderboard(player, args.length == 0 ? "blocks" : args[0].toLowerCase(Locale.ROOT));
            case "prisonnews" -> { message(player, "&b&lARVEE PRISON 0.3.0 &7- &fAdvanced Progression Update");
                message(player, "&fNew: &bResearch Tree&7, &eContracts&7, &6Crates&7, &dGangs&7, &fLeaderboards&7 & &bPlaceholderAPI"); }
            case "gang" -> gangs.command(player, args);
            case "mines" -> menus.openMines(player);
            case "mine" -> {
                if (args.length == 0) { menus.openMines(player); return true; }
                int rank = Amounts.rank(args[0]);
                if (rank < 0) { message(player, "&cUse /mine A through /mine Z."); return true; }
                if (rank > p.rank && !player.hasPermission("arveeprison.admin")) {
                    message(player, "&cUnlock Rank " + Amounts.rank(rank) + " first."); return true;
                }
                worlds.travel(player, rank);
            }
            case "rankup" -> rankup(player, args.length > 0 && args[0].equalsIgnoreCase("max"));
            case "prestige" -> prestige(player);
            case "sell" -> sell(player);
            case "balance" -> message(player, "&fMoney: &6$" + Amounts.format(p.money) + "&7 | &fUnsold ore: &e$" + Amounts.format(p.backpackValue));
            case "tokens" -> message(player, "&fTokens: &e" + Amounts.format(p.tokens));
            case "pickaxe" -> {
                if (args.length > 0 && args[0].equalsIgnoreCase("get")) grantPickaxe(player);
                else menus.openUpgrades(player);
            }
            case "autosell" -> toggleAutoSell(player);
            case "quests" -> quests(player, args.length > 0 && args[0].equalsIgnoreCase("claim"));
            default -> { return false; }
        }
        return true;
    }

    public void upgrade(Player player, String type) {
        PrisonProfile p = profile(player);
        int cost;
        int level;
        int cap;
        switch (type) {
            case "efficiency" -> { level = p.efficiency; cap = getConfig().getInt("pickaxe.max-efficiency-upgrade", 6); cost = getConfig().getInt("pickaxe.efficiency-token-cost", 80) * (level + 1); }
            case "fortune" -> { level = p.fortune; cap = getConfig().getInt("pickaxe.max-fortune-upgrade", 5); cost = getConfig().getInt("pickaxe.fortune-token-cost", 125) * (level + 1); }
            case "jackhammer" -> { level = p.jackhammer; cap = getConfig().getInt("pickaxe.max-jackhammer-upgrade", 5); cost = getConfig().getInt("pickaxe.jackhammer-token-cost", 250) * (level + 1); }
            case "autosell" -> {
                if (p.autoSellUnlocked) { message(player, "&eAuto-Sell already unlocked. Toggle with /autosell."); return; }
                cost = getConfig().getInt("pickaxe.autosell-token-cost", 500);
                if (p.tokens < cost) { message(player, "&cAuto-Sell costs " + cost + " tokens."); return; }
                p.tokens -= cost;
                p.autoSellUnlocked = true;
                p.autoSellEnabled = true;
                message(player, "&aAuto-Sell unlocked and enabled!");
                menus.openUpgrades(player);
                return;
            }
            default -> { return; }
        }
        if (level >= cap) { message(player, "&eThat upgrade is already maxed."); return; }
        if (p.tokens < cost) { message(player, "&cYou need " + cost + " tokens for this upgrade."); return; }
        p.tokens -= cost;
        switch (type) {
            case "efficiency" -> p.efficiency++;
            case "fortune" -> p.fortune++;
            case "jackhammer" -> p.jackhammer++;
        }
        message(player, "&aUpgraded " + type + " to level " + (level + 1) + "!");
        // Refreshes the already-held pickaxe, or gives one when there is room.
        grantPickaxe(player);
        menus.openUpgrades(player);
    }

    private boolean admin(CommandSender sender, String[] args) {
        if (!sender.hasPermission("arveeprison.admin")) { message(sender, "&cNo permission."); return true; }
        if (args.length == 0) {
            message(sender, "&eAdmin: /prisonadmin setup | setspawn | reset <A-Z> | setrank <player> <A-Z> | addmoney <player> <amount> | addtokens <player> <amount> | reload | status");
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "setup" -> {
                World lobby = worlds.setupLobby();
                message(sender, lobby == null ? "&cCould not create Prison spawn." : "&aPrison lobby ready! Use /prisonadmin setspawn to change its spawn.");
            }
            case "setspawn" -> {
                if (!(sender instanceof Player player)) { message(sender, "&cStand at the intended spawn in-game."); break; }
                getConfig().set("worlds.lobby", player.getWorld().getName());
                getConfig().set("lobby-spawn", player.getLocation());
                saveConfig();
                worlds.markCustomLobbyReady();
                message(sender, "&aSpawn saved in world " + player.getWorld().getName() + ".");
            }
            case "reset" -> {
                if (args.length < 2 || Amounts.rank(args[1]) < 0) { message(sender, "&cUsage: /prisonadmin reset <A-Z>"); break; }
                int rank = Amounts.rank(args[1]);
                worlds.getMine(rank);
                worlds.queueReset(rank, false);
                message(sender, "&aQueued reset for mine " + Amounts.rank(rank) + ".");
            }
            case "setrank" -> {
                if (args.length < 3 || Amounts.rank(args[2]) < 0) { message(sender, "&cUsage: /prisonadmin setrank <online-player> <A-Z>"); break; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { message(sender, "&cPlayer not online."); break; }
                profile(target).rank = Amounts.rank(args[2]);
                message(sender, "&aRank updated for " + target.getName() + ".");
            }
            case "addmoney", "addtokens" -> {
                if (args.length < 3) { message(sender, "&cUsage: /prisonadmin " + sub + " <online-player> <positive-number>"); break; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { message(sender, "&cPlayer not online."); break; }
                try {
                    double value = Double.parseDouble(args[2]);
                    if (!Double.isFinite(value) || value <= 0) throw new NumberFormatException();
                    PrisonProfile p = profile(target);
                    if (sub.equals("addmoney")) p.money = safeAdd(p.money, value);
                    else {
                        if (value > Long.MAX_VALUE) throw new NumberFormatException();
                        p.tokens = safeAddTokens(p.tokens, (long) value);
                    }
                    message(sender, "&aAwarded " + Amounts.format(value) + " " + sub.substring(3) + " to " + target.getName() + ".");
                } catch (NumberFormatException e) { message(sender, "&cAmount must be a positive finite number."); }
            }
            case "reload" -> { reloadConfig(); message(sender, "&aConfig reloaded. Structural mine changes require a fresh world or restart."); }
            case "status" -> message(sender, "&bARVEE Prison 0.3.0 &7| &fLoaded worlds: &e" + Bukkit.getWorlds().stream().filter(w -> worlds.rankFor(w) >= 0).count() + "/26 &7| &fData: &eYAML");
            default -> message(sender, "&cUnknown subcommand. Use /prisonadmin.");
        }
        return true;
    }

    @Override public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);
        if (name.equals("prisonresearch") && args.length == 1) return match(args[0], List.of("income", "tokens", "xp", "jackhammer"));
        if (name.equals("prisoncontracts") && args.length == 1) return match(args[0], List.of("1", "2", "3"));
        if (name.equals("prisoncrates") && args.length == 1) return match(args[0], List.of("open"));
        if (name.equals("prisontop") && args.length == 1) return match(args[0], List.of("blocks", "prestige", "level", "money"));
        if (name.equals("gang") && args.length == 1) return match(args[0], List.of("create", "invite", "join", "leave", "info", "top", "disband"));
        if (name.equals("mine") && args.length == 1) return match(args[0], rankLetters());
        if (name.equals("rankup") && args.length == 1) return match(args[0], List.of("max"));
        if (name.equals("prisonmenu") && args.length == 1) return match(args[0], List.of("on", "off", "get"));
        if (name.equals("backpack") && args.length == 1) return match(args[0], List.of("upgrade"));
        if (name.equals("prisonrewards") && args.length == 1) return match(args[0], List.of("daily", "milestone"));
        if (name.equals("prisonbooster") && args.length == 1) return match(args[0], List.of("buy"));
        if (name.equals("pickaxe") && args.length == 1) return match(args[0], List.of("get"));
        if (name.equals("quests") && args.length == 1) return match(args[0], List.of("claim"));
        if (name.equals("prisonadmin")) {
            if (!sender.hasPermission("arveeprison.admin")) return Collections.emptyList();
            if (args.length == 1) return match(args[0], List.of("setup", "setspawn", "reset", "setrank", "addmoney", "addtokens", "reload", "status"));
            if (args.length == 2 && args[0].equalsIgnoreCase("reset")) return match(args[1], rankLetters());
            if (args.length == 3 && args[0].equalsIgnoreCase("setrank")) return match(args[2], rankLetters());
        }
        return Collections.emptyList();
    }
    private static List<String> rankLetters() {
        List<String> letters = new ArrayList<>();
        for (int i = 0; i < 26; i++) letters.add(Amounts.rank(i));
        return letters;
    }
    private static List<String> match(String token, List<String> options) {
        return options.stream().filter(option -> option.toLowerCase(Locale.ROOT).startsWith(token.toLowerCase(Locale.ROOT))).toList();
    }
}
