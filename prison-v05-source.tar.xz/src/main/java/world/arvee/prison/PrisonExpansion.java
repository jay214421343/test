package world.arvee.prison;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.util.Vector;
import java.io.File;
import java.io.IOException;
import java.util.*;

/** Additive systems for v0.5: no existing player/world file is rewritten. Main-thread only. */
public final class PrisonExpansion implements Listener {
    private final ArveePrison plugin;
    private final File file;
    private final YamlConfiguration data;
    private final NamespacedKey pickaxeKey;
    private final Map<UUID,Integer> boughtPlots = new HashMap<>();
    private final Map<Integer,Listing> listings = new TreeMap<>();
    private final Map<String,Integer> gangLevels = new HashMap<>();
    private final Map<UUID,Integer> explosive = new HashMap<>(), treasure = new HashMap<>();
    private int nextAuction = 1;
    private final String plotWorld;
    private record Listing(int id, UUID seller, double price, ItemStack item) { }

    public PrisonExpansion(ArveePrison plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "expansion.yml");
        this.data = YamlConfiguration.loadConfiguration(file);
        this.pickaxeKey = new NamespacedKey(plugin, "prison_pickaxe");
        this.plotWorld = plugin.getConfig().getString("expansion.plot-world", "prison_plots");
        this.nextAuction = Math.max(1, data.getInt("auction-next-id", 1));
        ConfigurationSection plots = data.getConfigurationSection("plots");
        if(plots!=null)for(String s:plots.getKeys(false))try{boughtPlots.put(UUID.fromString(s),plots.getInt(s));}catch(Exception ignored){}
        ConfigurationSection ench = data.getConfigurationSection("enchants");
        if(ench!=null)for(String s:ench.getKeys(false))try{UUID id=UUID.fromString(s);explosive.put(id,ench.getInt(s+".explosive"));treasure.put(id,ench.getInt(s+".treasure"));}catch(Exception ignored){}
        ConfigurationSection levels = data.getConfigurationSection("gang-levels");
        if(levels!=null)for(String s:levels.getKeys(false))gangLevels.put(s.toLowerCase(Locale.ROOT),levels.getInt(s));
        ConfigurationSection sales = data.getConfigurationSection("auction-listings");
        if(sales!=null)for(String s:sales.getKeys(false))try{
            int id=Integer.parseInt(s);UUID seller=UUID.fromString(sales.getString(s+".seller",""));
            double price=sales.getDouble(s+".price");ItemStack item=sales.getItemStack(s+".item");
            if(price>0&&Double.isFinite(price)&&item!=null&&item.getType()!=Material.AIR)listings.put(id,new Listing(id,seller,price,item));
        }catch(Exception ex){plugin.getLogger().warning("Skipped invalid auction "+s);}
        Bukkit.getPluginManager().registerEvents(this,plugin);
        Bukkit.getScheduler().runTaskTimer(plugin,this::save,20L*300,20L*300);
    }
    public void save(){
        data.set("plots",null);boughtPlots.forEach((id,n)->data.set("plots."+id,n));
        data.set("enchants",null);for(UUID id:explosive.keySet())data.set("enchants."+id+".explosive",explosive.get(id));
        for(UUID id:treasure.keySet())data.set("enchants."+id+".treasure",treasure.get(id));
        data.set("gang-levels",null);gangLevels.forEach((id,n)->data.set("gang-levels."+id,n));
        data.set("auction-next-id",nextAuction);data.set("auction-listings",null);
        for(Listing a:listings.values()){String base="auction-listings."+a.id+".";data.set(base+"seller",a.seller.toString());data.set(base+"price",a.price);data.set(base+"item",a.item);}
        try{data.save(file);}catch(IOException ex){plugin.getLogger().severe("Failed saving expansion: "+ex.getMessage());}
    }
    public boolean command(Player player,String command,String[] args){
        switch(command){
            case "plot" -> plot(player,args);
            case "auction" -> auction(player,args);
            case "prisonseason" -> season(player,args);
            case "advancedenchants" -> enchant(player,args);
            case "gangupgrade" -> gangUpgrade(player,args);
            default -> {return false;}
        }
        return true;
    }
    private void say(Player p,String s){plugin.message(p,s);}
    private int plotLimit(){return Math.max(1,Math.min(2000,plugin.getConfig().getInt("expansion.max-plots",200)));}
    private int width(){return Math.max(16,Math.min(128,plugin.getConfig().getInt("expansion.plot-size",48)));}
    private int gap(){return Math.max(8,Math.min(128,plugin.getConfig().getInt("expansion.plot-gap",16)));}
    private int plotX(int index){return ((index-1)%20)*(width()+gap());}
    private int plotZ(int index){return ((index-1)/20)*(width()+gap());}
    private World plotWorld(){
        World existing=Bukkit.getWorld(plotWorld);
        if(existing!=null)return existing;
        // Explicit on-demand generator: existing worlds are never deleted or regenerated.
        WorldCreator creator=new WorldCreator(plotWorld).environment(World.Environment.NORMAL).generateStructures(false).generator(new ChunkGenerator(){});
        World world=creator.createWorld();
        if(world!=null){world.setDifficulty(Difficulty.PEACEFUL);world.setGameRule(GameRule.DO_MOB_SPAWNING,false);}
        return world;
    }
    private void plot(Player p,String[] args){
        if(args.length==0){say(p,"&b/plot claim &7(one plot per player), &b/plot home&7, &b/plot visit <player>");return;}
        switch(args[0].toLowerCase(Locale.ROOT)){
            case "claim" -> {
                if(boughtPlots.containsKey(p.getUniqueId())){say(p,"&cYou already own a plot. /plot home");return;}
                if(boughtPlots.size()>=plotLimit()){say(p,"&cAll plots claimed. Ask staff to raise expansion.max-plots.");return;}
                World w=plotWorld();if(w==null){say(p,"&cPlot world could not load.");return;}
                int index=1;while(boughtPlots.containsValue(index))index++;
                int x=plotX(index), z=plotZ(index);
                // Spawnproof platform; an existing plot world is never cleared.
                for(int dx=0;dx<width();dx++)for(int dz=0;dz<width();dz++){
                    Block b=w.getBlockAt(x+dx,63,z+dz);if(b.getType()==Material.AIR)b.setType(Material.GRASS_BLOCK,false);
                }
                boughtPlots.put(p.getUniqueId(),index);save();
                p.teleport(new Location(w,x+width()/2.0,64,z+width()/2.0));say(p,"&aPlot #"+index+" claimed! World and ownership persist across restarts.");
            }
            case "home" -> {
                Integer index=boughtPlots.get(p.getUniqueId());if(index==null){say(p,"&cClaim a plot with /plot claim.");return;}
                World w=plotWorld();if(w!=null)p.teleport(new Location(w,plotX(index)+width()/2.0,64,plotZ(index)+width()/2.0));
            }
            case "visit" -> {
                if(args.length<2){say(p,"&c/plot visit <online-player>");return;}
                Player target=Bukkit.getPlayerExact(args[1]);Integer index=target==null?null:boughtPlots.get(target.getUniqueId());
                if(index==null){say(p,"&cNo plot found for that online player.");return;}
                World w=plotWorld();if(w!=null)p.teleport(new Location(w,plotX(index)+width()/2.0,64,plotZ(index)+width()/2.0));
            }
            default -> say(p,"&c/plot claim | home | visit <player>");
        }
    }
    private UUID ownerAt(Block block){
        if(!block.getWorld().getName().equals(plotWorld))return null;
        int cell=width()+gap();int x=block.getX(),z=block.getZ();
        if(x<0||z<0)return new UUID(0,0);
        int row=x/cell, column=z/cell;
        if(row>=20||x%cell>=width()||z%cell>=width())return new UUID(0,0);
        int number=column*20+row+1;
        for(var e:boughtPlots.entrySet())if(e.getValue()==number)return e.getKey();
        return new UUID(0,0);
    }
    private boolean deny(Player player,Block block){
        if(!block.getWorld().getName().equals(plotWorld))return false;
        UUID id=ownerAt(block);
        if(id!=null&&!id.equals(player.getUniqueId())&&!player.hasPermission("arveeprison.plots.bypass")){
            say(player,"&cYou cannot modify another player's plot or roads.");return true;
        }return false;
    }
    @EventHandler(ignoreCancelled=true,priority=EventPriority.HIGH)public void onPlotBreak(BlockBreakEvent event){if(deny(event.getPlayer(),event.getBlock()))event.setCancelled(true);}
    @EventHandler(ignoreCancelled=true,priority=EventPriority.HIGH)public void onPlotPlace(BlockPlaceEvent event){if(deny(event.getPlayer(),event.getBlock()))event.setCancelled(true);}
    @EventHandler(ignoreCancelled=true,priority=EventPriority.HIGH)public void onExplode(org.bukkit.event.entity.EntityExplodeEvent event){if(event.getLocation().getWorld()!=null&&event.getLocation().getWorld().getName().equals(plotWorld))event.setCancelled(true);}
    @EventHandler(ignoreCancelled=true)public void onPiston(org.bukkit.event.block.BlockPistonExtendEvent event){if(event.getBlock().getWorld().getName().equals(plotWorld))event.setCancelled(true);}
    @EventHandler(ignoreCancelled=true)public void onPistonRetract(org.bukkit.event.block.BlockPistonRetractEvent event){if(event.getBlock().getWorld().getName().equals(plotWorld))event.setCancelled(true);}
    private void enchant(Player p,String[] args){
        int ex=explosive.getOrDefault(p.getUniqueId(),0), tr=treasure.getOrDefault(p.getUniqueId(),0);
        if(args.length==0){say(p,"&bExtra pickaxe enchants: &fExplosive "+ex+"/10 &7and &fTreasure "+tr+"/10. &e/advancedenchants buy <explosive|treasure>");return;}
        if(args.length!=2||!args[0].equalsIgnoreCase("buy")){say(p,"&c/advancedenchants buy <explosive|treasure>");return;}
        String type=args[1].toLowerCase(Locale.ROOT);if(!type.equals("explosive")&&!type.equals("treasure")){say(p,"&cUnknown enchant.");return;}
        int level=type.equals("explosive")?ex:tr;
        if(level>=10){say(p,"&cAlready at level 10.");return;}
        long cost=(type.equals("explosive")?500L:750L)*(level+1)*(level+1);
        PrisonProfile d=plugin.profile(p);if(d.tokens<cost){say(p,"&cNeed "+Amounts.format(cost)+" tokens.");return;}
        d.tokens-=cost;if(type.equals("explosive"))explosive.put(p.getUniqueId(),level+1);else treasure.put(p.getUniqueId(),level+1);
        save();say(p,"&aUnlocked "+type+" "+(level+1)+" for "+Amounts.format(cost)+" tokens.");
    }
    /** Triggered only on a successfully mined ARVEE mine block; capped rewards and no recursive calls. */
    public void mineBonus(Player p,Block source){
        ItemStack tool=p.getInventory().getItemInMainHand();
        if(tool==null||!tool.hasItemMeta()||!tool.getItemMeta().getPersistentDataContainer().has(pickaxeKey,PersistentDataType.BYTE))return;
        int lv=treasure.getOrDefault(p.getUniqueId(),0);
        if(lv>0&&Math.random()<lv*.002){PrisonProfile d=plugin.profile(p);d.crateKeys=Math.min(1_000_000,d.crateKeys+1);say(p,"&6Treasure Hunter found a crate key!");}
        // Explosion is server-side, capped, confined to the mine and accounted as normal mined blocks.
        lv=explosive.getOrDefault(p.getUniqueId(),0);
        if(lv>0&&Math.random()<lv*.003){
            plugin.bonusBurst(p,source,Math.min(2+lv,10));
        }
    }
    private void gangUpgrade(Player p,String[] args){
        String name=plugin.gangs().nameOf(p.getUniqueId());if(name.equals("None")){say(p,"&cJoin a gang first: /gang");return;}
        String key=name.toLowerCase(Locale.ROOT);int lv=gangLevels.getOrDefault(key,0);
        if(args.length==0){say(p,"&bGang "+name+" shared vault level: &f"+lv+"/20 &7| &e/gangupgrade buy");return;}
        if(!args[0].equalsIgnoreCase("buy")){say(p,"&c/gangupgrade buy");return;}
        if(lv>=20){say(p,"&cMaximum level.");return;}
        long cost=1000L*(lv+1)*(lv+1);PrisonProfile profile=plugin.profile(p);
        if(profile.tokens<cost){say(p,"&cNeed "+Amounts.format(cost)+" tokens.");return;}
        profile.tokens-=cost;gangLevels.put(key,lv+1);save();say(p,"&aGang upgrade "+(lv+1)+" purchased! Shared gang-level progression saved.");
    }
    private void auction(Player p,String[] args){
        if(args.length==0||args[0].equalsIgnoreCase("list")){
            say(p,"&bAuction House &7("+listings.size()+" listings) &f/auction sell <price>, /auction buy <id>, /auction cancel <id>");
            listings.values().stream().limit(12).forEach(a->say(p,"&7#"+a.id+" &f"+a.item.getAmount()+"x "+a.item.getType()+" &6$"+Amounts.format(a.price)));return;
        }
        if(args.length<2){say(p,"&cUsage: /auction sell <price> | buy <id> | cancel <id>");return;}
        switch(args[0].toLowerCase(Locale.ROOT)){
            case "sell" -> {
                double price;try{price=Double.parseDouble(args[1]);}catch(NumberFormatException ex){say(p,"&cInvalid price.");return;}
                if(!Double.isFinite(price)||price<1||price>1e15){say(p,"&cPrice must be $1-$1 quadrillion.");return;}
                long owned=listings.values().stream().filter(x->x.seller.equals(p.getUniqueId())).count();
                if(owned>=10){say(p,"&cMaximum 10 active listings.");return;}
                ItemStack held=p.getInventory().getItemInMainHand();
                if(held==null||held.getType().isAir()||held.getItemMeta()!=null&&held.getItemMeta().getPersistentDataContainer().has(pickaxeKey,PersistentDataType.BYTE)){
                    say(p,"&cHold a tradeable item (not your ARVEE pickaxe).");return;}
                ItemStack item=held.clone();p.getInventory().setItemInMainHand(null);
                int id=nextAuction++;listings.put(id,new Listing(id,p.getUniqueId(),price,item));save();
                say(p,"&aAuction #"+id+" created. Your item is held in escrow.");
            }
            case "buy" -> {
                int id;try{id=Integer.parseInt(args[1]);}catch(NumberFormatException e){say(p,"&cInvalid listing ID.");return;}
                Listing a=listings.get(id);if(a==null){say(p,"&cListing no longer available.");return;}
                if(a.seller.equals(p.getUniqueId())){say(p,"&cYou cannot buy your own listing.");return;}
                PrisonProfile buyer=plugin.profile(p),seller=plugin.profileByUuid(a.seller);
                if(buyer.money<a.price){say(p,"&cInsufficient money.");return;}
                // Check room before debiting, so items cannot spill onto the ground or disappear.
                if(p.getInventory().firstEmpty()==-1){say(p,"&cFree an inventory slot first.");return;}
                buyer.money-=a.price;seller.money=Math.min(1e18,seller.money+a.price);
                p.getInventory().addItem(a.item.clone());listings.remove(id);save();
                say(p,"&aPurchased auction #"+id+" for $"+Amounts.format(a.price));
            }
            case "cancel" -> {
                int id;try{id=Integer.parseInt(args[1]);}catch(NumberFormatException e){say(p,"&cInvalid ID.");return;}
                Listing a=listings.get(id);
                if(a==null||!a.seller.equals(p.getUniqueId())){say(p,"&cYou don't own that listing.");return;}
                if(p.getInventory().firstEmpty()==-1){say(p,"&cFree an inventory slot to reclaim your item.");return;}
                p.getInventory().addItem(a.item.clone());listings.remove(id);save();say(p,"&aListing cancelled; item returned.");
            }
            default -> say(p,"&c/auction list | sell <price> | buy <id> | cancel <id>");
        }
    }
    private void season(Player p,String[] args){
        long epoch=System.currentTimeMillis()/1000;
        long start=plugin.getConfig().getLong("expansion.season-start-epoch",1792800000L);
        long period=Math.max(86400,plugin.getConfig().getLong("expansion.season-length-seconds",2592000L));
        long season=Math.max(1,Math.floorDiv(epoch-start,period)+1);
        long remaining=period-Math.floorMod(epoch-start,period);
        PrisonProfile d=plugin.profile(p);
        long points=Math.min(Long.MAX_VALUE/10,d.minedBlocks/100 + d.prestige*250L);
        say(p,"&d&lARVEE PRISON SEASON "+season+" &7| &f"+(remaining/86400)+" days left");
        say(p,"&7Your lifetime-based score: &e"+Amounts.format(points)+" &7| Mining level: &b"+d.miningLevel);
        say(p,"&7Seasonal rewards and resets will be opt-in; no existing progression is wiped.");
    }
}
