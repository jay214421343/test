# ARVEE Advanced Prison v0.4.0 — persistence, physical crates, deep mines, scheduled resets

Built for **Paper 26.3 build 222 / Java 25** with **PlaceholderAPI (optional)**.

## Upgrade without resetting

1. Stop the Prison server. Back up `plugins/ArveePrison/`, **all** `prison_mine_*` folders and your current lobby world.
2. Remove the old `ArveePrison-0.3.0-Paper26.3.jar`, insert the new JAR, **keep the data directory**.
3. Restart. The plugin automatically loads/adopts the saved lobby without running `/prisonadmin setup` again. `lobby-spawn` and `worlds.yml` state are reused, no existing world directories are deleted or re-created.
4. `/prisonadmin status`, `/prisonmenu get`, `/mines` to check.

### Why every mine looked unlocked

Previous versions let OPs access all mines implicitly because `arveeprison.admin` defaulted to OP. v0.4 enforces actual rank restrictions, **including OPs**, by default. To restore the old privilege, set `progression.admin-bypass-mine-locks: true`. Admins can still run `/prisonadmin setrank <player> <A-Z>` to change a player's rank without resetting other data.

### Physical crates (one-time setup)

Stand in your Prison lobby, look at an existing chest, barrel or ender chest, and run **`/prisonadmin crate add`**. If looking into empty space, the command safely places an ender chest in front of you. Players then right-click that block to open Mining Crates; key balances and rewards reuse your existing `/prisoncrates` system.

`/prisonadmin crate remove` unlinks the targeted block without breaking it. `/prisonadmin crate list` shows all saved locations. All locations persist in `plugins/ArveePrison/crates.yml` across restarts. Only in the saved Prison lobby; protected from explosions/breakage.

### Worlds, difficulty and void

All **new** ARVEE worlds use a blank void chunk generator (not superflat), get peaceful difficulty, no mobs, no PvP, fixed noon and clear weather. **Existing world terrain is never deleted or replaced**. A previously generated superflat world retains already generated terrain; to convert a whole existing map to void would require a separate migration or a new world.

The lobby builds **once only when the folder does not already exist**. Existing lobby worlds are adopted and the saved spawn retained. Imported lobbies are never painted over.

### Much deeper mines

New installations create 21 × 21 × 64-block pits with the floor at Y=26 and rim at Y=90. Existing installs keep their `config.yml` dimensions. To opt into deepening existing ARVEE-generated frames, run **`/prisonadmin deepen` once**: this saves the new dimensions and marks that the upgrade should also be applied lazily when older mine worlds are loaded. For safety, it will only deepen pits whose original ARVEE v0.3.0 frame signature is detected. **Custom/imported mine maps are not rebuilt.**

Deepening queues mine refill jobs in small batches to avoid large single-tick refills; consider doing this during maintenance with a server backup. The command can trigger edits to recognized generated mines and should be treated as deliberate migration.

### Scheduled regeneration

The scheduler now runs every 5 seconds; resets occur by interval (`mines.reset-every-minutes`, default 20) or when mined below the configured remaining percentage. It announces **5m, 1m, 30s, 10s** before a scheduled reset, once per reset cycle, to players in that mine. Block refills are spread across server ticks; `last-reset` is persisted in worlds.yml on completion and the countdown is retained after restarts.

PlaceholderAPI: `%arveeprison_mine_reset_seconds%`, `%arveeprison_physical_crates%`, alongside all existing `%arveeprison_*%` placeholders.

### Safety notes

Do not run `/reload`. Stop/start the server after JAR replacement. Keep the original world files and player saves, and test on staging first. Build compilation is not proof of gameplay correctness; test void world generation and the new crate blocks live before public release.
