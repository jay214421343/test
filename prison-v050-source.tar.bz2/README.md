# ARVEE Advanced Prison v0.5.0 — Expansion Pack

Target: **Paper 26.3 build 222**, **Java 25**, and optional **PlaceholderAPI**.

The new systems intentionally preserve existing `plugins/ArveePrison/` files (`config.yml`, `players.yml`, `worlds.yml`, `gangs.yml`, `crates.yml`) and all existing Prison worlds. No `/prisonadmin setup` is needed after upgrade. Keep the old folder. New saves are additive: `plots.yml`, `auctions.yml`, `season.yml`.

## Upgrade

1. Shut down the Prison Paper backend (do not hot-reload).
2. Back up the entire Prison world folders, `plugins/ArveePrison/`, and the old JAR.
3. Remove old ArveePrison JAR versions (only keep one), upload `ArveePrison-0.5.0-Paper26.3.jar`.
4. Restart; test `/prison`, `/plot info`, `/auction list`, `/season`, `/gang info`.
5. Test as a non-operator account; operator status is deliberately **not** a mine rank bypass.

The base configuration for newly installed copies includes `plots`, `auctions`, `seasons`, new pickaxe enchants and gang upgrades. **Old configs are still supported via code defaults.** You can add their keys to an existing config to customize pricing.

## Features

- **Private plot world:** `/plot claim` one time to create a 37x37 plot in `prison_plots` (size configurable). `/plot home`, `/plot visit <online player>`, `/plot trust <player>`, `/plot untrust <player>`. Created plots are saved in `plots.yml` and **never rebuilt automatically**. Owner/trusted users may edit their plot; others are blocked from construction and container access. Plot world remains void, separate from Prison mines. Only basic Bukkit events are protected: admin tools bypassing Bukkit events or external plugins can still modify plots.
- **Auction House:** Main menu -> Auction House to browse 28-item pages. Hold a normal item and `/auction sell <price>`. `/auction buy <id>`, `/auction cancel <id>` (seller), `/auction claim` (buyer, or seller collecting cancelled listings), `/auction list [page]`. Items, listings and claimable deliveries are persisted to `auctions.yml`; buyers pay **ARVEE Prison currency** and sellers receive sale price minus configurable tax. Prison pickaxes/menu items cannot be sold. For safety, stage-test transactional behavior and back up files before using with the public.
- **Season progression:** `/season` (view progress), `/season claim` (claim earned tiers). Earn XP from mined blocks. New season only starts by explicit `/prisonadmin season next`. `season.yml` holds the current season, players' season XP/claimed tiers live in their existing `players.yml`. The `length-days` countdown is **informational only**: it does not automatically reset player progression.
- **Pickaxe:** Prospector, Veinminer and Treasure Hunter alongside existing efficiency, fortune and jackhammer in `/pickaxe`. Purchase with tokens and refresh your soulbound tool.
- **Gang upgrades:** `/gang donate <tokens>`, `/gang upgrade income|tokens|capacity` (leader only), `/gang info`. Uses persistent gang token bank and upgrade levels in `gangs.yml`. Income and token luck apply to members' mining.
- **Main menu:** Hotbar star opens a larger feature hub; auction browsing and the season pass each have their own interactive menu.

## New PlaceholderAPI variables

`%arveeprison_plot_id%`, `%arveeprison_auction_listings%`, `%arveeprison_auction_claims%`, `%arveeprison_season%`, `%arveeprison_season_level%`, `%arveeprison_season_xp%`, `%arveeprison_season_days_remaining%`, `%arveeprison_prospector%`, `%arveeprison_veinminer%`, `%arveeprison_treasure%`.

On Velocity, PlaceholderAPI must run on the backend and TAB-Bridge must be working to show the Prison placeholders on the proxy scoreboard.

## Important limitations

This JAR is built against the real Paper API; compilation and JAR validation **are not the same as live gameplay testing**. In particular, test auction restarts and concurrent interactions on a staging server. YAML-based auction/player balances are saved in separate files, so they are not an ACID transaction across a sudden host power loss; for high-volume production economies, SQL/journaled transfers would be the next hardening step. Plot protection uses standard events but does not replace a dedicated full-featured claims protection system. Season rollover is administrator-controlled, not automatic.
