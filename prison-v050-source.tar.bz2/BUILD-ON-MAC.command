#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

printf '\n=== ARVEE Prison 0.1.1 | REAL Paper 26.3 API build ===\n\n'

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "This shortcut is for macOS. On Linux use Gradle 9.2.1+ with JDK 25: gradle clean build --no-daemon"
  exit 1
fi
if ! command -v /usr/libexec/java_home >/dev/null 2>&1; then
  echo "macOS Java discovery missing. Please install JDK 25."
  exit 1
fi
if ! JAVA_HOME=$(/usr/libexec/java_home -v 25 2>/dev/null); then
  echo "JDK 25 not found. Install Temurin 25 and retry."
  exit 1
fi
export JAVA_HOME
export PATH="$JAVA_HOME/bin:$PATH"
echo "Using Java: $(java -version 2>&1 | head -n 1)"
if [[ "$(javac -version 2>&1)" != "javac 25"* ]]; then
  echo "Requires JDK 25, got $(javac -version 2>&1)"
  exit 1
fi
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle not installed. Please run: brew install gradle"
  exit 1
fi

printf '\nFetching official Paper API via Gradle and compiling...\n'
gradle clean build --no-daemon
jar='build/libs/ArveePrison-0.1.1-Paper26.3.jar'
if [[ ! -s "$jar" ]]; then
  echo "ERROR: JAR not generated at $jar" >&2
  exit 1
fi
mkdir -p dist
cp "$jar" dist/
printf '\nBUILD COMPLETE: %s/dist/%s\n' "$(pwd)" "$(basename "$jar")"
open dist
