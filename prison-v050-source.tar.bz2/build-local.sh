#!/usr/bin/env bash
set -euo pipefail
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle is missing. Install Gradle 9.2.1+ or build via GitHub Actions." >&2
  exit 1
fi
if ! command -v javac >/dev/null 2>&1; then
  echo "JDK 25 required. javac not found." >&2
  exit 1
fi
javac -version 2>&1
java -version 2>&1 | head -n 1
gradle --version | grep -E 'Gradle|JVM' || true
gradle clean build --no-daemon
printf '\nBuilt %s\n' "$(pwd)/build/libs/ArveePrison-0.1.1-Paper26.3.jar"
