package world.arvee.prison;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import java.util.*;

/** Read-only GUI surfaces for season and auction actions; all purchases use server-side validation. */
public final class PrisonExpansionMenus implements Listener {
    private final ArveePrison plugin;
    private static final class Holder implements InventoryHolder {
        final String kind; int page; final Map<Integer,Integer> auctionIds = new HashMap<>();
        Inventory inventory;
        Holder(String kind,int page){this.kind=kind;this.page=page;}
        @Override public Inventory getInventory(){return inventory;}
    }
    public PrisonExpansionMenus(ArveePrison plugin){this.plugin=plugin;Bukkit.getPluginManager().registerEvents(this,plugin);}
    private ItemStack icon(Material type,String title,List<String> desc){
        ItemStack item=new ItemStack(type);ItemMeta meta=item.getItemMeta();
        meta.setDisplayName(plugin.color(title));meta.setLore(desc.stream().map(plugin::color).toList());item.setItemMeta(meta);return item;
    }
    private ItemStack icon(Material type,String title,String... desc){return icon(type,title,Arrays.asList(desc));}
    private Inventory newMenu(Holder holder,String title){
        holder.inventory=Bukkit.createInventory(holder,54,title);
        ItemStack glass=icon(Material.BLACK_STAINED_GLASS_PANE," ");
        for(int i=0;i<54;i++)holder.inventory.setItem(i,glass);
        return holder.inventory;
    }
    public void openAuction(Player player,int page){
        Holder holder=new Holder("auctions",Math.max(1,page));Inventory inv=newMenu(holder,"ARVEE Prison • Auction House");
        inv.setItem(4,icon(Material.EMERALD_BLOCK,"&e&lAUCTION HOUSE","&7Player to player marketplace","&7Hold an item and type &f/auction sell <price>","&7Purchased/cancelled items: &f/auction claim"));
        int offset=(holder.page-1)*28;
        List<PrisonAuctions.AuctionView> views=plugin.auctions().page(offset,28);
        int[] slots={10,11,12,13,14,15,16,19,20,21,22,23,24,25,28,29,30,31,32,33,34,37,38,39,40,41,42,43};
        for(int i=0;i<views.size();i++){
            var l=views.get(i);int slot=slots[i];holder.auctionIds.put(slot,l.id());
            ItemStack display=l.item().clone();ItemMeta meta=display.getItemMeta();
            meta.setDisplayName(plugin.color("&b#"+l.id()+" &f"+l.item().getType()));
            meta.setLore(List.of(plugin.color("&6Price: $"+Amounts.format(l.price())),plugin.color("&7Seller: "+l.sellerName()),plugin.color("&eClick to buy &7| &cShift-click to cancel yours")));
            display.setItemMeta(meta);inv.setItem(slot,display);
        }
        inv.setItem(45,icon(Material.ARROW,"&ePrevious page"));
        inv.setItem(49,icon(Material.CHEST,"&a&lCLAIM ITEMS","&7Unclaimed deliveries: "+plugin.auctions().pending(player.getUniqueId())));
        inv.setItem(53,icon(Material.ARROW,"&eNext page"));
        player.openInventory(inv);
    }
    public void openSeason(Player player){
        PrisonProfile p=plugin.profile(player);plugin.seasons().update(p);
        Holder holder=new Holder("season",0);Inventory inv=newMenu(holder,"ARVEE Prison • Season Pass");
        PrisonSeasons season=plugin.seasons();
        inv.setItem(4,icon(Material.CLOCK,"&d&lSEASON "+season.id(),"&7Tier "+season.level(p)+"/"+season.maxTier(),"&7XP: "+p.seasonXp,"&7Season period: "+season.daysRemaining()+" days to planned rollover"));
        for(int i=1;i<=season.maxTier();i++){
            int slot=i-1 + 10 + (i-1)/7*2;
            if(slot>=45)break;
            boolean owned=(p.seasonClaims&(1L<<(i-1)))!=0;
            boolean ready=season.level(p)>=i;
            inv.setItem(slot,icon(owned?Material.EMERALD_BLOCK:ready?Material.GOLD_BLOCK:Material.REDSTONE_BLOCK,
                "&b&lTIER "+i,owned?"&aAlready claimed":ready?"&eReady to claim":"&7Unlock at "+(i*season.tierXp())+" XP",
                "&7Money: "+Amounts.format(plugin.getConfig().getDouble("seasons.money-per-tier",3500)*i),
                "&7Tokens: "+plugin.getConfig().getLong("seasons.tokens-per-tier",30)));
        }
        inv.setItem(49,icon(Material.NETHER_STAR,"&a&lCLAIM SEASON REWARDS","&eClick to collect every earned tier"));
        player.openInventory(inv);
    }
    @EventHandler public void click(InventoryClickEvent e){
        if(!(e.getView().getTopInventory().getHolder() instanceof Holder h))return;
        e.setCancelled(true);if(!(e.getWhoClicked() instanceof Player p))return;
        int slot=e.getRawSlot();if(slot<0||slot>=54)return;
        if(h.kind.equals("season")){
            if(slot==49)Bukkit.getScheduler().runTask(plugin,()->{plugin.seasons().command(p,new String[]{"claim"});openSeason(p);});
            return;
        }
        if(slot==45&&h.page>1)Bukkit.getScheduler().runTask(plugin,()->openAuction(p,h.page-1));
        else if(slot==53 && plugin.auctions().count()>h.page*28)Bukkit.getScheduler().runTask(plugin,()->openAuction(p,h.page+1));
        else if(slot==49){Bukkit.getScheduler().runTask(plugin,()->{plugin.auctions().command(p,new String[]{"claim"});openAuction(p,h.page);});}
        else if(h.auctionIds.containsKey(slot)){
            int id=h.auctionIds.get(slot);
            Bukkit.getScheduler().runTask(plugin,()->{
                plugin.auctions().command(p,new String[]{e.isShiftClick()?"cancel":"buy",String.valueOf(id)});
                openAuction(p,h.page);
            });
        }
    }
}
