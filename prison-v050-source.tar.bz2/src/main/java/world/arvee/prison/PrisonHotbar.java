package world.arvee.prison;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import java.util.ArrayList;
import java.util.List;

public final class PrisonHotbar implements Listener {
    private final ArveePrison plugin;
    private final NamespacedKey menuKey;
    public PrisonHotbar(ArveePrison plugin) {
        this.plugin = plugin;
        this.menuKey = new NamespacedKey(plugin, "menu_item");
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }
    public boolean isMenu(ItemStack item) {
        return item != null && item.hasItemMeta()
            && item.getItemMeta().getPersistentDataContainer().has(menuKey, PersistentDataType.BYTE);
    }
    private ItemStack make() {
        Material material = Material.matchMaterial(plugin.getConfig().getString("hotbar.item", "NETHER_STAR"));
        ItemStack item = new ItemStack(material == null ? Material.NETHER_STAR : material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(plugin.color(plugin.getConfig().getString("hotbar.name", "&b&lARVEE PRISON")));
        List<String> lore = new ArrayList<>();
        for (String line : plugin.getConfig().getStringList("hotbar.lore")) lore.add(plugin.color(line));
        meta.setLore(lore);
        meta.getPersistentDataContainer().set(menuKey, PersistentDataType.BYTE, (byte)1);
        item.setItemMeta(meta);
        return item;
    }
    public void remove(Player p) {
        for (int i = 0; i < 36; i++) if (isMenu(p.getInventory().getItem(i))) p.getInventory().setItem(i, null);
    }
    public void give(Player p) {
        if (!plugin.getConfig().getBoolean("hotbar.enabled", true) || !plugin.profile(p).menuEnabled) return;
        int existing = -1;
        for (int i = 0; i < 36; i++) if (isMenu(p.getInventory().getItem(i))) { existing = i; break; }
        if (existing >= 0 && existing <= 8) return; // already in the hotbar
        int desired = Math.max(0, Math.min(8, plugin.getConfig().getInt("hotbar.preferred-slot", 8)));
        for (int slot = -1; slot < 9; slot++) {
            int candidate = slot == -1 ? desired : slot;
            ItemStack old = p.getInventory().getItem(candidate);
            if (old != null && !old.getType().isAir()) continue;
            p.getInventory().setItem(candidate, existing >= 0 ? p.getInventory().getItem(existing) : make());
            if (existing >= 0) p.getInventory().setItem(existing, null);
            return;
        }
        if (existing < 0) {
            int free = p.getInventory().firstEmpty();
            if (free >= 0 && free < 36) p.getInventory().setItem(free, make());
            else plugin.message(p, "&eInventory and hotbar full! Use /prison to open menus or clear a slot.");
        } else plugin.message(p, "&eYour Prison star is in the inventory; clear a hotbar slot to move it there.");
    }
    @EventHandler public void rightClick(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (!isMenu(event.getItem())) return;
        event.setCancelled(true);
        if (event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (event.getPlayer().isOnline()) plugin.menus().openMain(event.getPlayer());
            });
        }
    }
    @EventHandler public void drop(PlayerDropItemEvent event) {
        if (isMenu(event.getItemDrop().getItemStack())) event.setCancelled(true);
    }
    @EventHandler public void click(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        if (isMenu(event.getCurrentItem()) || isMenu(event.getCursor())) event.setCancelled(true);
        // Hotbar swap via the number keys must not remove a protected menu item.
        if (event.getHotbarButton() >= 0 && event.getHotbarButton() < 9
            && isMenu(((Player)event.getWhoClicked()).getInventory().getItem(event.getHotbarButton()))) event.setCancelled(true);
    }
    @EventHandler public void drag(InventoryDragEvent event) {
        if (isMenu(event.getOldCursor())) event.setCancelled(true);
    }
    @EventHandler public void respawn(PlayerRespawnEvent event) {
        Bukkit.getScheduler().runTaskLater(plugin, () -> { if (event.getPlayer().isOnline()) give(event.getPlayer()); }, 5L);
    }
}
