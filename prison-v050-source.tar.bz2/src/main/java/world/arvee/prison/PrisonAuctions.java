package world.arvee.prison;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Persistent item marketplace. All inventory/economy operations run on the server thread. */
public final class PrisonAuctions {
    private final ArveePrison plugin; private final File file;
    private final LinkedHashMap<Integer, Listing> listings=new LinkedHashMap<>();
    private final Map<UUID,List<ItemStack>> pending=new HashMap<>();
    private int nextId=1;
    private static final class Listing {
        int id;UUID seller;String name;ItemStack item;double price;long created;
    }
    public PrisonAuctions(ArveePrison plugin){this.plugin=plugin;file=new File(plugin.getDataFolder(),"auctions.yml");load();}
    public int count(){return listings.size();}
    public int pending(UUID id){return pending.getOrDefault(id,List.of()).size();}
    public void command(Player p,String[] args){
        String sub=args.length==0?"list":args[0].toLowerCase(Locale.ROOT);
        switch(sub){
            case "list" -> list(p,args);
            case "sell" -> sell(p,args);
            case "buy" -> buy(p,args);
            case "cancel" -> cancel(p,args);
            case "claim" -> claim(p);
            default -> plugin.message(p,"&eAuction: /auction list [page] | sell <price> (hold item) | buy <id> | cancel <id> | claim");
        }
    }
    private void list(Player p,String[] args){
        int page=1;if(args.length>1)try{page=Math.max(1,Integer.parseInt(args[1]));}catch(NumberFormatException ignored){}
        List<Listing> view=new ArrayList<>(listings.values());
        view.sort(Comparator.comparingInt(l->l.id));
        int start=Math.min(view.size(),(page-1)*7);
        plugin.message(p,"&6&lAUCTION HOUSE &7| &fPage " + page + " &7| &e"+view.size()+" listings");
        for(int i=start;i<Math.min(view.size(),start+7);i++){
            Listing l=view.get(i);
            plugin.message(p,"&8#"+l.id+" &b"+l.item.getAmount()+"x "+l.item.getType()+" &7by &f"+l.name+" &7- &6$"+Amounts.format(l.price)+" &e/auction buy "+l.id);
        }
        plugin.message(p,"&7Hold an item and &f/auction sell <price>&7. Unclaimed purchases: &e"+pending(p.getUniqueId()));
    }
    private void sell(Player p,String[] args){
        if(args.length<2){plugin.message(p,"&cUsage: /auction sell <price>");return;}
        double price;
        try{price=Double.parseDouble(args[1]);}catch(NumberFormatException e){plugin.message(p,"&cInvalid price.");return;}
        if(!Double.isFinite(price)||price<1||price>1e15){plugin.message(p,"&cPrice must be from $1 to $1 quadrillion.");return;}
        ItemStack held=p.getInventory().getItemInMainHand();
        if(held==null||held.getType().isAir()||plugin.isBoundItem(held)){plugin.message(p,"&cHold a tradable item. Prison pickaxes/menu stars can't be listed.");return;}
        long active=listings.values().stream().filter(l->l.seller.equals(p.getUniqueId())).count();
        if(active>=Math.max(1,plugin.getConfig().getInt("auctions.max-listings-per-player",5))){plugin.message(p,"&cYour auction slots are full.");return;}
        ItemStack item=held.clone();
        Listing l=new Listing();l.id=nextId++;l.seller=p.getUniqueId();l.name=p.getName();l.price=price;l.item=item;l.created=System.currentTimeMillis();
        p.getInventory().setItemInMainHand(new ItemStack(Material.AIR));
        listings.put(l.id,l);
        if(!save()){
            listings.remove(l.id);p.getInventory().setItemInMainHand(item);plugin.message(p,"&cAuction save failed. Your item has been returned.");return;
        }
        plugin.message(p,"&aListed " +item.getAmount()+"x "+item.getType()+" for &6$"+Amounts.format(price)+"&a (#"+l.id+").");
    }
    private int getId(String[] args){if(args.length<2)return -1;try{return Integer.parseInt(args[1]);}catch(NumberFormatException e){return -1;}}
    private void buy(Player p,String[] args){
        Listing l=listings.get(getId(args));
        if(l==null){plugin.message(p,"&cNo listing found. Use /auction list.");return;}
        if(l.seller.equals(p.getUniqueId())){plugin.message(p,"&cYou cannot buy your own listing.");return;}
        PrisonProfile buyer=plugin.profile(p),seller=plugin.profileByUuid(l.seller);
        if(buyer.money<l.price){plugin.message(p,"&cYou need $"+Amounts.format(l.price)+".");return;}
        double tax=Math.max(0,Math.min(.25,plugin.getConfig().getDouble("auctions.sale-tax",.03)));
        // Persist escrowed delivery before announcing success; on full inventories the item remains claimable.
        buyer.money-=l.price;seller.money=Math.min(1e300,seller.money+l.price*(1-tax));
        pending.computeIfAbsent(p.getUniqueId(), k->new ArrayList<>()).add(l.item.clone());listings.remove(l.id);
        if(!save()){
            buyer.money+=l.price;seller.money-=l.price*(1-tax);
            pending.get(p.getUniqueId()).remove(l.item);listings.put(l.id,l);
            plugin.message(p,"&cPurchase cancelled: could not save auctions.");return;
        }
        plugin.savePlayers();
        plugin.message(p,"&aBought auction #"+l.id+"! &fUse /auction claim to receive your item.");
        Player online=Bukkit.getPlayer(l.seller);if(online!=null)plugin.message(online,"&aYour auction #"+l.id+" sold for &6$"+Amounts.format(l.price)+"&a!");
    }
    private void cancel(Player p,String[] args){
        Listing l=listings.get(getId(args));
        if(l==null||(!l.seller.equals(p.getUniqueId())&&!p.hasPermission("arveeprison.admin"))){plugin.message(p,"&cUnknown or unauthorized auction listing.");return;}
        listings.remove(l.id);pending.computeIfAbsent(l.seller,k->new ArrayList<>()).add(l.item.clone());
        if(!save()){listings.put(l.id,l);pending.get(l.seller).remove(l.item);plugin.message(p,"&cAuction cancel failed to save.");return;}
        plugin.message(p,"&aAuction #"+l.id+" cancelled. Owner can use /auction claim to retrieve the item.");
    }
    private void claim(Player p){
        List<ItemStack> items=pending.get(p.getUniqueId());
        if(items==null||items.isEmpty()){plugin.message(p,"&eNo pending auction items.");return;}
        List<ItemStack> remaining=new ArrayList<>();int delivered=0;
        for(ItemStack item:items){
            Map<Integer,ItemStack> leftover=p.getInventory().addItem(item.clone());
            if(leftover.isEmpty())delivered++;
            else remaining.addAll(leftover.values());
        }
        pending.put(p.getUniqueId(),remaining);
        if(!save()) plugin.getLogger().warning("Could not save auction deliveries; check persistence before restart.");
        plugin.message(p,"&aClaimed "+delivered+" auction deliveries. &e"+remaining.size()+" &7items remain due to inventory space.");
    }
    private void load(){
        YamlConfiguration y=YamlConfiguration.loadConfiguration(file);nextId=Math.max(1,y.getInt("next-id",1));
        if(y.getConfigurationSection("listings")!=null)for(String key:y.getConfigurationSection("listings").getKeys(false)){
            try{
                int id=Integer.parseInt(key),n=id;String path="listings."+key+".";
                Listing l=new Listing();l.id=n;l.seller=UUID.fromString(y.getString(path+"seller",""));l.name=y.getString(path+"name","Unknown");
                l.item=y.getItemStack(path+"item");l.price=y.getDouble(path+"price");l.created=y.getLong(path+"created");
                if(l.item==null||l.item.getType().isAir()||l.price<=0||!Double.isFinite(l.price))continue;
                listings.put(id,l);nextId=Math.max(nextId,id+1);
            }catch(IllegalArgumentException e){plugin.getLogger().warning("Skipped corrupt auction "+key);}
        }
        if(y.getConfigurationSection("pending")!=null)for(String key:y.getConfigurationSection("pending").getKeys(false)){
            try{
                UUID owner=UUID.fromString(key);List<?> list=y.getList("pending."+key,List.of());List<ItemStack> items=new ArrayList<>();
                for(Object o:list)if(o instanceof ItemStack i&&!i.getType().isAir())items.add(i);
                pending.put(owner,items);
            }catch(IllegalArgumentException ignored){}
        }
    }
    public boolean save(){
        YamlConfiguration y=new YamlConfiguration();y.set("next-id",nextId);
        for(Listing l:listings.values()){
            String k="listings."+l.id+".";y.set(k+"seller",l.seller.toString());y.set(k+"name",l.name);
            y.set(k+"price",l.price);y.set(k+"created",l.created);y.set(k+"item",l.item);
        }
        for(var e:pending.entrySet())if(!e.getValue().isEmpty())y.set("pending."+e.getKey(),e.getValue());
        try{
            File tmp=new File(file.getParentFile(),"auctions.yml.tmp");y.save(tmp);
            try{Files.move(tmp.toPath(),file.toPath(),StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}catch(AtomicMoveNotSupportedException e){Files.move(tmp.toPath(),file.toPath(),StandardCopyOption.REPLACE_EXISTING);}
            return true;
        }catch(IOException e){plugin.getLogger().severe("Could not save auctions: "+e.getMessage());return false;}
    }
}
