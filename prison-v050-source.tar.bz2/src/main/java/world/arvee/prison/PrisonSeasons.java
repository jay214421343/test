package world.arvee.prison;

import org.bukkit.entity.Player;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.*;
import java.nio.file.*;
import java.time.*;

/** Season passes reset only the season XP/reward track; never reset old progression or the world. */
public final class PrisonSeasons {
    private final ArveePrison plugin;
    private final File file;
    private int season;
    private long started;
    public PrisonSeasons(ArveePrison plugin){
        this.plugin=plugin;file=new File(plugin.getDataFolder(),"season.yml");
        YamlConfiguration yaml=YamlConfiguration.loadConfiguration(file);
        season=Math.max(1,yaml.getInt("current-season",1));
        started=yaml.getLong("started",System.currentTimeMillis());
        if(!file.exists())save();
    }
    public int id(){return season;}
    public int tierXp(){return Math.max(20,plugin.getConfig().getInt("seasons.xp-per-tier",200));}
    public int maxTier(){return Math.max(1,Math.min(30,plugin.getConfig().getInt("seasons.tiers",20)));}
    public void update(PrisonProfile p){if(p.seasonId!=season){p.seasonId=season;p.seasonXp=0;p.seasonClaims=0;}}
    public int level(PrisonProfile p){return (int)Math.min(maxTier(),Math.max(0,p.seasonXp/tierXp()));}
    public void mined(PrisonProfile p,int rank){update(p);p.seasonXp=Math.min(Long.MAX_VALUE-4,p.seasonXp)+1+rank/10;}
    public int daysRemaining(){
        long elapsed=(System.currentTimeMillis()-started)/86400000;
        return Math.max(0,plugin.getConfig().getInt("seasons.length-days",30)-(int)elapsed);
    }
    public void command(Player player,String[] args){
        PrisonProfile p=plugin.profile(player);update(p);
        if(args.length==0||!args[0].equalsIgnoreCase("claim")){
            plugin.message(player,"&e&lSEASON "+season+" &7| &fTier &b"+level(p)+"/&b"+maxTier()+" &7| &fXP &e"+p.seasonXp+" &7| &f"+daysRemaining()+" days to planned rollover");
            plugin.message(player,"&7Each tier gives money and tokens. &a/season claim &7collects earned rewards; only admins start new seasons.");return;
        }
        int level=level(p),gained=0;
        double moneyPer=plugin.getConfig().getDouble("seasons.money-per-tier",3500.0);
        long tokenPer=Math.max(0,plugin.getConfig().getLong("seasons.tokens-per-tier",30));
        for(int tier=1;tier<=level;tier++){
            long bit=1L<<(tier-1);
            if((p.seasonClaims & bit)!=0)continue;
            p.seasonClaims|=bit;
            p.money=Math.min(1.0e300,p.money+moneyPer*tier);
            p.tokens=Math.min(Long.MAX_VALUE-tokenPer,p.tokens)+tokenPer;
            gained++;
        }
        if(gained==0)plugin.message(player,"&eNo unclaimed seasonal tiers. Keep mining!");
        else {plugin.message(player,"&aClaimed " +gained+" season rewards!");plugin.savePlayers();}
    }
    public void advance(){season++;started=System.currentTimeMillis();save();}
    private void save(){
        YamlConfiguration y=new YamlConfiguration();y.set("current-season",season);y.set("started",started);
        try{File tmp=new File(file.getParentFile(),"season.yml.tmp");y.save(tmp);try{Files.move(tmp.toPath(),file.toPath(),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}catch(AtomicMoveNotSupportedException e){Files.move(tmp.toPath(),file.toPath(),StandardCopyOption.REPLACE_EXISTING);}}
        catch(IOException e){plugin.getLogger().severe("Could not save season metadata: "+e.getMessage());}
    }
}
