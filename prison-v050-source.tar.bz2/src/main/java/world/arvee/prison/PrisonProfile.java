package world.arvee.prison;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.UUID;

public final class PrisonProfile {
    public final UUID uuid;
    public String lastName;
    public int rank = 0;
    public int prestige = 0;
    public double money;
    public long tokens;
    public double backpackValue = 0;
    public long minedBlocks = 0;
    public int efficiency = 0;
    public int fortune = 0;
    public int jackhammer = 0;
    public int backpackLevel = 0;
    public long miningXp = 0;
    public int miningLevel = 1;
    public int achievementClaims = 0;
    public long totalEarned = 0;
    public int dailyStreak = 0;
    public String lastDailyClaim = "";
    public long boosterUntil = 0;
    public int boosterPurchases = 0;
    public long lifetimeTokens = 0;
    // Additive fields: existing 0.1.x and 0.2.x profile saves remain readable.
    public int researchIncome = 0;
    public int researchTokens = 0;
    public int researchXp = 0;
    public int researchJackhammer = 0;
    public int contractClaims = 0; // Bitset of 3 daily contract rewards
    public int prospector = 0;
    public int veinminer = 0;
    public int treasure = 0;
    public int seasonId = 1;
    public long seasonXp = 0;
    public long seasonClaims = 0;
    public int crateKeys = 0;
    public int cratesOpened = 0;
    public boolean menuEnabled = true;
    public boolean autoSellUnlocked = false;
    public boolean autoSellEnabled = false;
    public String questDay = LocalDate.now(ZoneOffset.UTC).toString();
    public int dailyBlocks = 0;
    public boolean claimedDaily = false;

    public PrisonProfile(UUID uuid) { this.uuid = uuid; }

    public void refreshDaily() {
        String today = LocalDate.now(ZoneOffset.UTC).toString();
        if (!today.equals(questDay)) {
            questDay = today;
            dailyBlocks = 0;
            claimedDaily = false;
            contractClaims = 0;
        }
    }

    public long capacity(long base, double factor) {
        double v = base * Math.pow(Math.max(1.05, factor), backpackLevel);
        return !Double.isFinite(v) || v >= Long.MAX_VALUE ? Long.MAX_VALUE : (long) Math.max(1, v);
    }
    public boolean boosted() { return System.currentTimeMillis() < boosterUntil; }
    public long xpToNextLevel() { return 100L * miningLevel * miningLevel; }
    public void addXp(long amount) {
        miningXp = Math.min(Long.MAX_VALUE - Math.max(0, amount), miningXp) + Math.max(0, amount);
        while (miningLevel < 200 && miningXp >= xpToNextLevel()) {
            miningXp -= xpToNextLevel();
            miningLevel++;
        }
    }
    public double multiplier(double bonusPerPrestige) {
        return 1 + prestige * bonusPerPrestige;
    }
}
