package world.arvee.prison;

import org.bukkit.Bukkit;
import org.bukkit.Difficulty;
import org.bukkit.GameRule;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.WorldType;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.logging.Level;

public final class Worlds {
    private final ArveePrison plugin;
    private final File stateFile;
    private final YamlConfiguration state;
    private final Deque<ResetJob> jobs = new ArrayDeque<>();
    private final Set<Integer> resetting = new HashSet<>();
    private final Set<Integer> loadedThisSession = new HashSet<>();
    private final int[] remaining = new int[26];
    private final long[] lastReset = new long[26];
    private final Random random = new Random();
    private final Map<Integer, Set<Integer>> resetWarnings = new HashMap<>();
    private static final int OLD_BOTTOM = 76;
    private static final int OLD_DEPTH = 14;

    public Worlds(ArveePrison plugin) {
        this.plugin = plugin;
        this.stateFile = new File(plugin.getDataFolder(), "worlds.yml");
        this.state = YamlConfiguration.loadConfiguration(stateFile);
        for (int rank = 0; rank < 26; rank++) {
            remaining[rank] = Math.max(0, Math.min(volume(), state.getInt("remaining." + rank, volume())));
            lastReset[rank] = state.getLong("last-reset." + rank, System.currentTimeMillis());
        }
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
        Bukkit.getScheduler().runTaskTimer(plugin, this::periodicResets, 20L, 20L * 5);
        // Same persisted timer continues after restart: last-reset values live in worlds.yml.
    }

    public int radius() { return Math.max(5, Math.min(30, plugin.getConfig().getInt("mines.radius", 10))); }
    public int bottom() { return Math.max(0, Math.min(240, plugin.getConfig().getInt("mines.bottom-y", 26))); }
    public int depth() { return Math.max(5, Math.min(128, plugin.getConfig().getInt("mines.depth", 64))); }
    public int volume() { return (2 * radius() + 1) * (2 * radius() + 1) * depth(); }
    public String mineName(int rank) { return plugin.getConfig().getString("worlds.mine-prefix", "prison_mine_") + Amounts.rank(rank).toLowerCase(java.util.Locale.ROOT); }
    public int rankFor(World world) {
        if (world == null) return -1;
        String name = world.getName();
        for (int r = 0; r < 26; r++) if (mineName(r).equals(name)) return r;
        return -1;
    }
    public boolean isLobby(World w) {
        return w != null && w.getName().equals(plugin.getConfig().getString("worlds.lobby", "prison_spawn"));
    }
    public boolean isMineBlock(Block b) {
        int radius = radius();
        return Math.abs(b.getX()) <= radius && Math.abs(b.getZ()) <= radius
            && b.getY() >= bottom() && b.getY() < bottom() + depth();
    }
    public boolean isResetting(int rank) { return resetting.contains(rank); }
    public long secondsUntilReset(int rank) {
        if (rank < 0 || rank >= 26) return 0;
        long time = Math.max(2, plugin.getConfig().getInt("mines.reset-every-minutes", 20)) * 60000L;
        return Math.max(0, (time - Math.max(0, System.currentTimeMillis() - lastReset[rank]) + 999L) / 1000L);
    }
    private WorldCreator creator(String name) {
        WorldCreator creator = new WorldCreator(name).type(WorldType.NORMAL).generateStructures(false);
        if (plugin.getConfig().getBoolean("world-settings.void-generator", true)) creator.generator(new VoidMineGenerator());
        return creator;
    }
    private void configureWorld(World w) {
        if (w == null) return;
        w.setDifficulty(Difficulty.PEACEFUL);
        w.setPVP(false);
        w.setSpawnFlags(false, false);
        w.setGameRule(GameRule.DO_MOB_SPAWNING, false);
        w.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
        w.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
        w.setTime(plugin.getConfig().getLong("world-settings.fixed-time", 6000L));
        w.setStorm(false);
        w.setAutoSave(true);
    }
    // A new world has no terrain at all; old worlds are never deleted or regenerated.
    private static final class VoidMineGenerator extends ChunkGenerator {
        @Override public boolean shouldGenerateNoise() { return false; }
        @Override public boolean shouldGenerateSurface() { return false; }
        @Override public boolean shouldGenerateCaves() { return false; }
        @Override public boolean shouldGenerateDecorations() { return false; }
        @Override public boolean shouldGenerateMobs() { return false; }
        @Override public boolean shouldGenerateStructures() { return false; }
    }


    public World getMine(int rank) {
        if (rank < 0 || rank > 25) return null;
        String name = mineName(rank);
        // Safety: only build the frame and fill blocks in a world that is actually new.
        // An imported or previously-created mine world is always treated as existing,
        // even when worlds.yml has been lost, reset or migrated from older versions.
        World world = Bukkit.getWorld(name);
        boolean existed = world != null || new File(Bukkit.getWorldContainer(), name).isDirectory();
        if (world == null) world = Bukkit.createWorld(creator(name));
        if (world == null) return null;
        configureWorld(world);
        maybeUpgradeGeneratedFrame(world, rank);
        if (!state.getBoolean("initialized." + name, false)) {
            loadedThisSession.add(rank);
            if (!existed) {
                buildFrame(world);
                queueReset(rank, true);
            } else {
                plugin.getLogger().info("Adopted existing mine world '" + name + "' without modifying any blocks.");
            }
            state.set("initialized." + name, true);
            saveState();
        } else if (loadedThisSession.add(rank)) {
            // Preserve existing mine builds/blocks across restarts unless explicitly requested.
            if (plugin.getConfig().getBoolean("mines.reset-on-load", false)) queueReset(rank, false);
        }
        return world;
    }

    public void travel(Player player, int rank) {
        World world = getMine(rank);
        if (world == null) { plugin.message(player, "&cCould not create the mine world."); return; }
        int radius = radius();
        player.teleport(new Location(world, 0.5, bottom() + depth() + 6, -radius - 10.5f, 0, 12));
        plugin.message(player, "&fTeleported to &bMine " + Amounts.rank(rank) + "&f.");
    }

    public void loadConfiguredLobby() {
        String name = plugin.getConfig().getString("worlds.lobby", "prison_spawn");
        World w = Bukkit.getWorld(name);
        if (w == null && new File(Bukkit.getWorldContainer(), name).isDirectory()) {
            w = Bukkit.createWorld(creator(name));
        }
        configureWorld(w);
    }
    public void ensureLobbyOnStart() {
        String name = plugin.getConfig().getString("worlds.lobby", "prison_spawn");
        boolean exists = Bukkit.getWorld(name) != null || new File(Bukkit.getWorldContainer(), name).isDirectory();
        if (exists) loadConfiguredLobby();
        else setupLobby();
        if (plugin.getConfig().getLocation("lobby-spawn") == null) {
            World lobby = Bukkit.getWorld(name);
            if (lobby != null) {
                // Adopt the world's original spawn if the config was lost; never rebuild the map.
                Location loc = state.getLocation("saved-lobby-spawn");
                if (loc == null || loc.getWorld() == null) loc = lobby.getSpawnLocation().clone().add(.5, 0, .5);
                plugin.getConfig().set("lobby-spawn", loc);
                plugin.saveConfig();
            }
        }
    }

    public void markCustomLobbyReady() {
        state.set("saved-lobby-spawn", plugin.getConfig().getLocation("lobby-spawn"));
        state.set("lobby-built", true);
        saveState();
    }

    public World setupLobby() {
        String name = plugin.getConfig().getString("worlds.lobby", "prison_spawn");
        World world = Bukkit.getWorld(name);
        boolean existed = world != null || new File(Bukkit.getWorldContainer(), name).isDirectory();
        if (world == null) world = Bukkit.createWorld(creator(name));
        if (world != null) configureWorld(world);
        if (world != null && !state.getBoolean("lobby-built", false)) {
            // ONLY construct when the world is brand new; adopt imported/custom lobbies.
            if (!existed) buildLobby(world);
            state.set("lobby-built", true);
            saveState();
            if (plugin.getConfig().getLocation("lobby-spawn") == null) {
                plugin.getConfig().set("lobby-spawn", !existed ? new Location(world, .5, 95, .5, 180, 0)
                    : world.getSpawnLocation().clone().add(.5, 0, .5));
                plugin.saveConfig();
            }
        }
        return world;
    }

    public Location lobbySpawn() {
        Location loc = plugin.getConfig().getLocation("lobby-spawn");
        if (loc != null && loc.getWorld() != null) return loc;
        World world = Bukkit.getWorld(plugin.getConfig().getString("worlds.lobby", "prison_spawn"));
        if (world == null) return null;
        return world.getSpawnLocation().add(.5, 0, .5);
    }

    public void recordBreak(int rank) {
        if (rank < 0 || rank > 25 || isResetting(rank)) return;
        if (remaining[rank] > 0) remaining[rank]--;
        if (!plugin.getConfig().getBoolean("mines.reset-when-empty", true)) return;
        int threshold = Math.max(1, Math.min(95, plugin.getConfig().getInt("mines.reset-at-remaining-percent", 20)));
        if (remaining[rank] * 100L <= (long) volume() * threshold) queueReset(rank, false);
    }

    public void queueReset(int rank, boolean initial) {
        if (rank < 0 || rank > 25 || !resetting.add(rank)) return;
        jobs.add(new ResetJob(rank, initial));
        resetWarnings.remove(rank);
        World world = Bukkit.getWorld(mineName(rank));
        if (world != null && !initial) {
            for (Player p : world.getPlayers()) plugin.message(p, "&eMine reset started! Mining resumes shortly.");
        }
    }

    private void tick() {
        int budget = Math.max(50, Math.min(1200, plugin.getConfig().getInt("mines.blocks-per-tick", 450)));
        while (budget > 0 && !jobs.isEmpty()) {
            ResetJob job = jobs.peek();
            World world = Bukkit.getWorld(mineName(job.rank));
            if (world == null) { jobs.poll(); resetting.remove(job.rank); continue; }
            int width = 2 * radius() + 1;
            int max = width * width * depth();
            int count = Math.min(budget, max - job.cursor);
            for (int i = 0; i < count; i++, job.cursor++) {
                int index = job.cursor;
                int x = index % width - radius();
                int z = (index / width) % width - radius();
                int y = bottom() + index / (width * width);
                Material material = blockFor(job.rank);
                world.getBlockAt(x, y, z).setType(material, false);
            }
            budget -= count;
            if (job.cursor == max) {
                jobs.poll(); resetting.remove(job.rank);
                remaining[job.rank] = volume();
                lastReset[job.rank] = System.currentTimeMillis();
                saveState(); // Persist immediately; resets remain correctly scheduled across restarts.
                for (Player p : world.getPlayers()) plugin.message(p, "&aMine " + Amounts.rank(job.rank) + " is ready!");
            }
        }
    }

    private void periodicResets() {
        long interval = Math.max(2, plugin.getConfig().getInt("mines.reset-every-minutes", 20)) * 60_000L;
        long now = System.currentTimeMillis();
        for (int rank = 0; rank < 26; rank++) {
            World w = Bukkit.getWorld(mineName(rank));
            if (w == null || resetting.contains(rank)) continue;
            long left = Math.max(0, interval - (now - lastReset[rank]));
            if (left == 0) { queueReset(rank, false); continue; }
            // Each threshold announces once per reset cycle, regardless of repeated checks.
            Set<Integer> announced = resetWarnings.computeIfAbsent(rank, x -> new HashSet<>());
            for (int seconds : plugin.getConfig().getIntegerList("mines.reset-warnings-seconds")) {
                if (seconds <= 0 || seconds >= interval / 1000L) continue;
                if (left <= seconds * 1000L && announced.add(seconds)) {
                    String human = seconds >= 60 ? (seconds / 60) + "m" : seconds + "s";
                    for (Player player : w.getPlayers()) plugin.message(player, "&eMine " + Amounts.rank(rank) + " regenerates in &6" + human + "&e!");
                }
            }
        }
    }

    /** Only deepens recognisable, plugin-generated arena walls. Never edits imported custom arenas. */
    private boolean recognisableOldFrame(World w) {
        int r = radius();
        return w.getBlockAt(r + 1, OLD_BOTTOM, 0).getType() == Material.POLISHED_DEEPSLATE
            && w.getBlockAt(0, OLD_BOTTOM - 1, 0).getType() == Material.BEDROCK
            && w.getBlockAt(0, OLD_BOTTOM + OLD_DEPTH + 5, -r - 10).getType() == Material.SEA_LANTERN;
    }
    private void maybeUpgradeGeneratedFrame(World w, int rank) {
        String name = mineName(rank);
        if (bottom() >= OLD_BOTTOM || state.getBoolean("deepened." + name, false) || !state.getBoolean("deepening-enabled", false)) return;
        if (!recognisableOldFrame(w)) return;
        // The new pit uses the same top Y, so the existing lobby/entry platform stays intact.
        // Build the walls from lower boundary to the previous bottom, then reset in batches.
        int radius = radius();
        for (int x = -radius - 2; x <= radius + 2; x++) for (int z = -radius - 2; z <= radius + 2; z++) {
            boolean wall = Math.abs(x) > radius || Math.abs(z) > radius;
            w.getBlockAt(x, bottom() - 1, z).setType(Material.BEDROCK, false);
            if (wall) for (int y = bottom(); y < OLD_BOTTOM; y++)
                w.getBlockAt(x, y, z).setType(Material.POLISHED_DEEPSLATE, false);
        }
        state.set("deepened." + name, true);
        queueReset(rank, false);
        remaining[rank] = volume();
        saveState();
    }
    public boolean deepenGeneratedMines() {
        if (bottom() >= OLD_BOTTOM) {
            plugin.getConfig().set("mines.bottom-y", 26);
            plugin.getConfig().set("mines.depth", 64);
            plugin.saveConfig();
        }
        state.set("deepening-enabled", true);
        boolean had = false;
        for (World w : Bukkit.getWorlds()) {
            int rank = rankFor(w);
            if (rank >= 0 && recognisableOldFrame(w)) { had = true; maybeUpgradeGeneratedFrame(w, rank); }
        }
        saveState();
        return had;
    }

    private Material blockFor(int rank) {
        // The SAME arena layout in every world; different ore distributions for each rank.
        double roll = random.nextDouble();
        if (rank <= 2) {
            if (roll < .65) return Material.STONE;
            return roll < .90 ? Material.COAL_ORE : Material.IRON_ORE;
        }
        if (rank <= 6) {
            if (roll < .40) return Material.STONE;
            return roll < .73 ? Material.IRON_ORE : Material.GOLD_ORE;
        }
        if (rank <= 12) {
            if (roll < .32) return Material.DEEPSLATE;
            return roll < .65 ? Material.GOLD_ORE : Material.DIAMOND_ORE;
        }
        if (rank <= 19) {
            if (roll < .30) return Material.DIAMOND_ORE;
            return roll < .75 ? Material.EMERALD_ORE : Material.DEEPSLATE_DIAMOND_ORE;
        }
        if (roll < .22) return Material.ANCIENT_DEBRIS;
        return roll < .58 ? Material.EMERALD_ORE : Material.DEEPSLATE_EMERALD_ORE;
    }

    private void buildFrame(World w) {
        int r = radius();
        int by = bottom();
        int top = by + depth();
        for (int x = -r - 2; x <= r + 2; x++) {
            for (int z = -r - 2; z <= r + 2; z++) {
                boolean wall = Math.abs(x) > r || Math.abs(z) > r;
                w.getBlockAt(x, by - 1, z).setType(Material.BEDROCK, false);
                if (wall) for (int y = by; y < top + 5; y++) {
                    w.getBlockAt(x, y, z).setType(y == top + 4 ? Material.SEA_LANTERN : Material.POLISHED_DEEPSLATE, false);
                }
            }
        }
        for (int x = -4; x <= 4; x++) {
            for (int z = -r - 15; z <= -r - 2; z++) {
                w.getBlockAt(x, top + 5, z).setType(Material.POLISHED_BLACKSTONE_BRICKS, false);
                for (int y = top + 6; y <= top + 9; y++) w.getBlockAt(x, y, z).setType(Material.AIR, false);
            }
        }
        for (int z = -r - 15; z <= -r - 2; z++) {
            w.getBlockAt(-4, top + 6, z).setType(Material.CYAN_STAINED_GLASS_PANE, false);
            w.getBlockAt(4, top + 6, z).setType(Material.CYAN_STAINED_GLASS_PANE, false);
        }
        w.getBlockAt(0, top + 5, -r - 10).setType(Material.SEA_LANTERN, false);
        w.setTime(6000);
        w.setStorm(false);
        w.getWorldBorder().setCenter(0, 0);
        w.getWorldBorder().setSize(Math.max(90, plugin.getConfig().getDouble("mines.world-border-size", 160)));
    }

    private void buildLobby(World w) {
        int y = 94;
        for (int x = -28; x <= 28; x++) for (int z = -28; z <= 28; z++) {
            boolean inside = Math.abs(x) <= 25 && Math.abs(z) <= 25;
            if (inside) {
                w.getBlockAt(x, y, z).setType((x % 7 == 0 || z % 7 == 0) ? Material.SMOOTH_QUARTZ : Material.POLISHED_DEEPSLATE, false);
                for (int h = 1; h <= 7; h++) w.getBlockAt(x, y + h, z).setType(Material.AIR, false);
                if (Math.abs(x) == 25 || Math.abs(z) == 25) {
                    w.getBlockAt(x, y + 1, z).setType(Material.CYAN_STAINED_GLASS, false);
                }
            } else {
                w.getBlockAt(x, y, z).setType(Material.DEEPSLATE_BRICKS, false);
            }
        }
        for (int x : new int[]{-18, 18}) for (int z : new int[]{-18, 18}) {
            for (int h = 1; h <= 11; h++) w.getBlockAt(x, y + h, z).setType(Material.DARK_PRISMARINE, false);
            w.getBlockAt(x, y + 12, z).setType(Material.SEA_LANTERN, false);
        }
        w.getBlockAt(0, y, 0).setType(Material.SEA_LANTERN, false);
        w.setTime(6000);
        w.setStorm(false);
        w.setSpawnLocation(0, 95, 0);
        w.getWorldBorder().setCenter(0, 0);
        w.getWorldBorder().setSize(256);
    }

    public int remaining(int rank) { return rank < 0 || rank > 25 ? 0 : remaining[rank]; }
    public int percentRemaining(int rank) { return rank < 0 || rank > 25 ? 0 : Math.max(0, (int) (100L * remaining[rank] / Math.max(1, volume()))); }
    public void saveState() {
        for (int i = 0; i < 26; i++) {
            state.set("remaining." + i, remaining[i]);
            state.set("last-reset." + i, lastReset[i]);
        }
        try { state.save(stateFile); }
        catch (IOException ex) { plugin.getLogger().log(Level.SEVERE, "Could not save worlds.yml", ex); }
    }
    private static final class ResetJob {
        final int rank;
        final boolean initial;
        int cursor = 0;
        ResetJob(int rank, boolean initial) { this.rank = rank; this.initial = initial; }
    }
}
