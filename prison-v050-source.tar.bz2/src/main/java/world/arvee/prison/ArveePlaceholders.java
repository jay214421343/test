package world.arvee.prison;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;

/** Optional PlaceholderAPI hook. Never loaded when PlaceholderAPI is absent. */
public final class ArveePlaceholders extends PlaceholderExpansion {
    private final ArveePrison plugin;
    public ArveePlaceholders(ArveePrison plugin) { this.plugin = plugin; }
    @Override public @NotNull String getIdentifier() { return "arveeprison"; }
    @Override public @NotNull String getAuthor() { return "ARVEE"; }
    @Override public @NotNull String getVersion() { return plugin.getPluginMeta().getVersion(); }
    @Override public boolean persist() { return true; }
    @Override public String onRequest(OfflinePlayer player, @NotNull String input) {
        if (player == null || player.getUniqueId() == null) return "";
        PrisonProfile p = plugin.profileByUuid(player.getUniqueId());
        String key = input.toLowerCase(java.util.Locale.ROOT);
        return switch (key) {
            case "rank" -> Amounts.rank(p.rank);
            case "rank_index" -> String.valueOf(p.rank + 1);
            case "next_rank" -> p.rank == 25 ? "MAX" : Amounts.rank(p.rank + 1);
            case "rankup_cost" -> p.rank == 25 ? "MAX" : Amounts.format(plugin.nextRankPrice(p.rank));
            case "rankup_cost_raw" -> p.rank == 25 ? "0" : String.valueOf((long) plugin.nextRankPrice(p.rank));
            case "prestige" -> String.valueOf(p.prestige);
            case "prestige_cost" -> Amounts.format(plugin.prestigePrice(p.prestige));
            case "balance", "money" -> Amounts.format(p.money);
            case "balance_raw", "money_raw" -> String.valueOf(p.money);
            case "tokens" -> Amounts.format(p.tokens);
            case "tokens_raw" -> String.valueOf(p.tokens);
            case "backpack" -> Amounts.format(p.backpackValue);
            case "backpack_raw" -> String.valueOf(p.backpackValue);
            case "backpack_level" -> String.valueOf(p.backpackLevel);
            case "backpack_capacity" -> Amounts.format(plugin.backpackCapacity(p));
            case "mined", "blocks_mined" -> Amounts.format(p.minedBlocks);
            case "mined_raw", "blocks_mined_raw" -> String.valueOf(p.minedBlocks);
            case "mining_level" -> String.valueOf(p.miningLevel);
            case "mining_xp" -> String.valueOf(p.miningXp);
            case "mining_xp_required" -> String.valueOf(p.xpToNextLevel());
            case "mining_progress" -> String.valueOf((int)(100 * p.miningXp / Math.max(1, p.xpToNextLevel())));
            case "efficiency" -> String.valueOf(p.efficiency);
            case "fortune" -> String.valueOf(p.fortune);
            case "prospector" -> String.valueOf(p.prospector);
            case "veinminer" -> String.valueOf(p.veinminer);
            case "treasure" -> String.valueOf(p.treasure);
            case "plot_id" -> String.valueOf(plugin.plots().plotId(player.getUniqueId()));
            case "auction_listings" -> String.valueOf(plugin.auctions().count());
            case "auction_claims" -> String.valueOf(plugin.auctions().pending(player.getUniqueId()));
            case "season" -> String.valueOf(plugin.seasons().id());
            case "season_level" -> {plugin.seasons().update(p);yield String.valueOf(plugin.seasons().level(p));}
            case "season_xp" -> {plugin.seasons().update(p);yield String.valueOf(p.seasonXp);}
            case "season_days_remaining" -> String.valueOf(plugin.seasons().daysRemaining());
            case "jackhammer" -> String.valueOf(p.jackhammer);
            case "autosell" -> p.autoSellUnlocked && p.autoSellEnabled ? "Enabled" : "Disabled";
            case "boost_active" -> p.boosted() ? "Yes" : "No";
            case "boost_seconds" -> String.valueOf(Math.max(0, (p.boosterUntil - System.currentTimeMillis()) / 1000));
            case "daily_blocks" -> String.valueOf(p.dailyBlocks);
            case "daily_streak" -> String.valueOf(p.dailyStreak);
            case "daily_claimed" -> String.valueOf(p.claimedDaily);
            case "achievement_claims" -> String.valueOf(p.achievementClaims);
            case "research_income" -> String.valueOf(p.researchIncome);
            case "research_tokens" -> String.valueOf(p.researchTokens);
            case "research_xp" -> String.valueOf(p.researchXp);
            case "research_jackhammer" -> String.valueOf(p.researchJackhammer);
            case "contract_progress" -> String.valueOf(p.dailyBlocks);
            case "contracts_claimed" -> String.valueOf(Integer.bitCount(p.contractClaims));
            case "crate_keys" -> String.valueOf(p.crateKeys);
            case "crates_opened" -> String.valueOf(p.cratesOpened);
            case "gang" -> plugin.gangs().nameOf(player.getUniqueId());
            case "gang_members" -> String.valueOf(plugin.gangs().sizeOf(player.getUniqueId()));
            case "mine" -> player.getPlayer() == null ? "Offline" :
                (plugin.worlds().rankFor(player.getPlayer().getWorld()) < 0 ? "Lobby" :
                    Amounts.rank(plugin.worlds().rankFor(player.getPlayer().getWorld())));
            case "mine_reset_seconds" -> player.getPlayer() == null ? "0" :
                String.valueOf(plugin.worlds().secondsUntilReset(plugin.worlds().rankFor(player.getPlayer().getWorld())));
            case "physical_crates" -> String.valueOf(plugin.physicalCrates().count());
            case "mine_remaining_percent" -> player.getPlayer() == null ? "0" :
                String.valueOf(plugin.worlds().percentRemaining(plugin.worlds().rankFor(player.getPlayer().getWorld())));
            default -> null;
        };
    }
}
