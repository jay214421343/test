package world.arvee.prison;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Small persistent social system, isolated from the player economy and mine worlds. */
public final class PrisonGangs {
    private static final long INVITE_MILLIS = 5 * 60_000L;
    private final ArveePrison plugin;
    private final File file;
    private final Map<String, Gang> gangs = new HashMap<>();
    private final Map<UUID, Invite> invites = new HashMap<>();
    private final Map<UUID, String> membership = new HashMap<>();

    private static final class Gang {
        String name;
        UUID leader;
        final Set<UUID> members = new LinkedHashSet<>();
        long blocks; // earned while a member was mining; distinct from lifetime totals
        long bankTokens;
        int incomeLevel;
        int tokenLevel;
        int capacityLevel;
        Gang(String name, UUID leader) {
            this.name = name; this.leader = leader; members.add(leader);
        }
    }
    private record Invite(String gang, long expiresAt) { }

    public PrisonGangs(ArveePrison plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "gangs.yml");
        load();
    }
    public String nameOf(UUID id) {
        Gang g = gangOf(id);
        return g == null ? "None" : g.name;
    }
    public int sizeOf(UUID id) {
        Gang g = gangOf(id);
        return g == null ? 0 : g.members.size();
    }
    private Gang gangOf(UUID id) {
        String key = membership.get(id);
        return key == null ? null : gangs.get(key);
    }
    public double incomeMultiplier(UUID id) {
        Gang g=gangOf(id);return g==null?1.0:1.0+g.incomeLevel*plugin.getConfig().getDouble("gangs.income-bonus-per-level",.025);
    }
    public double tokenBonus(UUID id) {
        Gang g=gangOf(id);return g==null?0:g.tokenLevel*plugin.getConfig().getDouble("gangs.token-bonus-per-level",.005);
    }
    public void countBlock(UUID id) {
        Gang g = gangOf(id);
        if (g != null && g.blocks < Long.MAX_VALUE) g.blocks++;
    }
    public void command(Player player, String[] args) {
        if (args.length == 0) {
            plugin.message(player, "&bGangs: &f/gang create <name>&7, &f/gang invite <player>&7, &f/gang join&7, &f/gang info&7, &f/gang leave&7, &f/gang kick <player>&7, &f/gang top&7, &f/gang disband");
            return;
        }
        UUID id = player.getUniqueId();
        Gang gang = gangOf(id);
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "create" -> {
                if (gang != null) { plugin.message(player, "&cYou're already in a gang."); return; }
                if (args.length != 2 || !args[1].matches("[A-Za-z0-9_]{3,16}")) {
                    plugin.message(player, "&cGang name must be 3-16 letters, numbers or underscores."); return;
                }
                String key = args[1].toLowerCase(Locale.ROOT);
                if (gangs.containsKey(key)) { plugin.message(player, "&cThat gang name is taken."); return; }
                Gang created = new Gang(args[1], id);
                gangs.put(key, created); membership.put(id, key);
                save();
                plugin.message(player, "&aFounded &b" + created.name + "&a! Invite friends using /gang invite.");
            }
            case "invite" -> {
                if (gang == null || !gang.leader.equals(id)) { plugin.message(player, "&cOnly your gang leader can invite players."); return; }
                if (args.length != 2) { plugin.message(player, "&cUsage: /gang invite <online player>"); return; }
                int max = Math.max(2, Math.min(100, plugin.getConfig().getInt("gangs.max-members", 12) + gang.capacityLevel * 2));
                if (gang.members.size() >= max) { plugin.message(player, "&cGang is full."); return; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null || membership.containsKey(target.getUniqueId())) {
                    plugin.message(player, "&cPlayer offline or already in a gang."); return;
                }
                invites.put(target.getUniqueId(), new Invite(gang.name.toLowerCase(Locale.ROOT), System.currentTimeMillis() + INVITE_MILLIS));
                plugin.message(target, "&e" + player.getName() + " invited you to &b" + gang.name + "&e! Type &f/gang join&e within five minutes.");
                plugin.message(player, "&aInvite sent to " + target.getName() + ".");
            }
            case "join" -> {
                if (gang != null) { plugin.message(player, "&cLeave your current gang first."); return; }
                Invite invite = invites.remove(id);
                Gang joining = invite == null || invite.expiresAt() < System.currentTimeMillis() ? null : gangs.get(invite.gang());
                if (joining == null) { plugin.message(player, "&cYou have no valid gang invite."); return; }
                int max = Math.max(2, Math.min(100, plugin.getConfig().getInt("gangs.max-members", 12) + joining.capacityLevel * 2));
                if (joining.members.size() >= max) { plugin.message(player, "&cThat gang is full."); return; }
                joining.members.add(id); membership.put(id, invite.gang());
                save(); plugin.message(player, "&aJoined &b" + joining.name + "&a!");
            }
            case "leave" -> {
                if (gang == null) { plugin.message(player, "&cYou're not in a gang."); return; }
                if (gang.leader.equals(id)) {
                    plugin.message(player, "&cLeaders must use /gang disband, or /gang transfer <online member>."); return;
                }
                gang.members.remove(id); membership.remove(id); save();
                plugin.message(player, "&eYou left the gang.");
            }
            case "transfer" -> {
                if (gang == null || !gang.leader.equals(id)) { plugin.message(player, "&cOnly the leader can transfer ownership."); return; }
                Player target = args.length > 1 ? Bukkit.getPlayerExact(args[1]) : null;
                if (target == null || !gang.members.contains(target.getUniqueId()) || target.getUniqueId().equals(id)) {
                    plugin.message(player, "&cTransfer to another online gang member."); return;
                }
                gang.leader = target.getUniqueId(); save();
                plugin.message(player, "&aTransferred leadership to " + target.getName() + ".");
                plugin.message(target, "&aYou're the new leader of " + gang.name + "!");
            }
            case "kick" -> {
                if (gang == null || !gang.leader.equals(id)) { plugin.message(player, "&cOnly your leader can kick members."); return; }
                Player target = args.length > 1 ? Bukkit.getPlayerExact(args[1]) : null;
                if (target == null || target.getUniqueId().equals(id) || !gang.members.contains(target.getUniqueId())) {
                    plugin.message(player, "&cSpecify a different online member."); return;
                }
                gang.members.remove(target.getUniqueId()); membership.remove(target.getUniqueId()); save();
                plugin.message(target, "&cYou were removed from " + gang.name + ".");
                plugin.message(player, "&aMember removed.");
            }
            case "disband" -> {
                if (gang == null || !gang.leader.equals(id)) { plugin.message(player, "&cOnly your gang leader can disband it."); return; }
                String key = gang.name.toLowerCase(Locale.ROOT);
                for (UUID member : gang.members) membership.remove(member);
                gangs.remove(key); save();
                plugin.message(player, "&eYour gang was disbanded.");
            }
            case "donate" -> {
                if(gang==null){plugin.message(player,"&cJoin a gang first.");return;}
                long count;
                try{count=Long.parseLong(args.length>1?args[1]:"");}catch(NumberFormatException ex){plugin.message(player,"&cUsage: /gang donate <tokens>");return;}
                PrisonProfile p=plugin.profile(player);
                if(count<=0||p.tokens<count||Long.MAX_VALUE-gang.bankTokens<count){plugin.message(player,"&cInvalid token amount or insufficient funds.");return;}
                p.tokens-=count;gang.bankTokens+=count;save();plugin.savePlayers();
                plugin.message(player,"&aDonated "+Amounts.format(count)+" tokens to your gang bank.");
            }
            case "upgrade" -> {
                if(gang==null||!gang.leader.equals(id)){plugin.message(player,"&cOnly the gang leader can upgrade.");return;}
                String branch=args.length>1?args[1].toLowerCase(Locale.ROOT):"";
                int lvl=switch(branch){case "income"->gang.incomeLevel;case "tokens"->gang.tokenLevel;case "capacity"->gang.capacityLevel;default->-1;};
                if(lvl<0){plugin.message(player,"&cUse /gang upgrade income|tokens|capacity");return;}
                int max=Math.max(1,plugin.getConfig().getInt("gangs.max-upgrade-level",10));
                if(lvl>=max){plugin.message(player,"&eThat perk is maxed.");return;}
                long base=Math.max(1,plugin.getConfig().getLong("gangs.upgrade-base-token-cost",1000));
                long cost=base*(lvl+1L)*(lvl+1L);
                if(gang.bankTokens<cost){plugin.message(player,"&cGang bank needs "+Amounts.format(cost)+" tokens. Use /gang donate.");return;}
                gang.bankTokens-=cost;
                switch(branch){case "income"->gang.incomeLevel++;case "tokens"->gang.tokenLevel++;case "capacity"->gang.capacityLevel++;default->{} }
                save();plugin.message(player,"&aGang "+branch+" upgraded to "+(lvl+1)+"!");
            }
            case "info" -> {
                if (gang == null) { plugin.message(player, "&eYou don't belong to a gang. /gang create <name>"); return; }
                plugin.message(player, "&b&l" + gang.name + " &7| &fMembers &e" + gang.members.size()
                    + " &7| &fGang mined &e" + Amounts.format(gang.blocks));
                plugin.message(player, "&fLeader: &b" + Bukkit.getOfflinePlayer(gang.leader).getName());
                plugin.message(player,"&fBank: &e"+Amounts.format(gang.bankTokens)+" tokens &7| &fIncome &b"+gang.incomeLevel+" &7| &fToken Luck &b"+gang.tokenLevel+" &7| &fCapacity &b"+gang.capacityLevel);
                plugin.message(player,"&7Donate tokens: &f/gang donate <amount> &7| Upgrade: &f/gang upgrade income|tokens|capacity");
            }
            case "top" -> {
                List<Gang> ranking = new ArrayList<>(gangs.values());
                ranking.sort(Comparator.comparingLong((Gang g) -> g.blocks).reversed());
                plugin.message(player, "&b&lTOP GANGS &7- blocks earned together");
                for (int i = 0; i < Math.min(10, ranking.size()); i++) {
                    Gang g = ranking.get(i);
                    player.sendMessage(plugin.color("&8#" + (i + 1) + " &b" + g.name + " &7- &e" + Amounts.format(g.blocks) + " blocks"));
                }
            }
            default -> plugin.message(player, "&cUnknown gang command. Use /gang for help.");
        }
    }
    private void load() {
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = yaml.getConfigurationSection("gangs");
        if (section == null) return;
        for (String key : section.getKeys(false)) {
            try {
                String prefix = "gangs." + key + ".";
                UUID leader = UUID.fromString(yaml.getString(prefix + "leader", ""));
                String name = yaml.getString(prefix + "name", key);
                if (!name.matches("[A-Za-z0-9_]{3,16}")) continue;
                Gang g = new Gang(name, leader);
                g.blocks = Math.max(0, yaml.getLong(prefix + "blocks", 0));
                g.bankTokens=Math.max(0,yaml.getLong(prefix+"bank-tokens",0));
                g.incomeLevel=Math.max(0,yaml.getInt(prefix+"income-level",0));
                g.tokenLevel=Math.max(0,yaml.getInt(prefix+"token-level",0));
                g.capacityLevel=Math.max(0,yaml.getInt(prefix+"capacity-level",0));
                for (String id : yaml.getStringList(prefix + "members")) g.members.add(UUID.fromString(id));
                for (UUID member : g.members) if (membership.containsKey(member)) {
                    plugin.getLogger().warning("Skipping conflicting gang membership for " + member);
                    g.members.remove(member); break;
                }
                gangs.put(key, g);
                for (UUID member : g.members) membership.put(member, key);
            } catch (IllegalArgumentException ex) { plugin.getLogger().warning("Ignoring invalid gang entry: " + key); }
        }
    }
    public void save() {
        YamlConfiguration yaml = new YamlConfiguration();
        for (var entry : gangs.entrySet()) {
            String prefix = "gangs." + entry.getKey() + ".";
            Gang g = entry.getValue();
            yaml.set(prefix + "name", g.name);
            yaml.set(prefix + "leader", g.leader.toString());
            yaml.set(prefix + "blocks", g.blocks);
            yaml.set(prefix + "bank-tokens", g.bankTokens);
            yaml.set(prefix + "income-level", g.incomeLevel);
            yaml.set(prefix + "token-level", g.tokenLevel);
            yaml.set(prefix + "capacity-level", g.capacityLevel);
            yaml.set(prefix + "members", g.members.stream().map(UUID::toString).toList());
        }
        try {
            File tmp = new File(file.getParentFile(), "gangs.yml.tmp");
            yaml.save(tmp);
            try { Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (java.nio.file.AtomicMoveNotSupportedException e) {
                Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException e) { plugin.getLogger().severe("Could not save gangs.yml: " + e.getMessage()); }
    }
}
