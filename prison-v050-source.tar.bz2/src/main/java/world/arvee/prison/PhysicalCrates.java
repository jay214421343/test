package world.arvee.prison;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerInteractEvent;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;

/** Persisted interactive crates. Never replaces an existing block or resets a world. */
public final class PhysicalCrates implements Listener {
    private final ArveePrison plugin;
    private final File file;
    private final Set<String> locations = new HashSet<>();

    public PhysicalCrates(ArveePrison plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "crates.yml");
        locations.addAll(YamlConfiguration.loadConfiguration(file).getStringList("locations"));
        Bukkit.getPluginManager().registerEvents(this, plugin);
        plugin.getLogger().info("Loaded " + locations.size() + " persistent physical crate locations");
    }

    private String key(Block b) {
        return b.getWorld().getName() + ":" + b.getX() + ":" + b.getY() + ":" + b.getZ();
    }
    public int count() { return locations.size(); }

    public void add(Player player) {
        Block target = player.getTargetBlockExact(Math.max(2, Math.min(12, plugin.getConfig().getInt("physical-crates.interact-range", 6))));
        if (target == null || !(target.getType() == Material.CHEST || target.getType() == Material.BARREL || target.getType() == Material.ENDER_CHEST)) {
            // Automatic, safe placement: only ever replace AIR.
            Location loc = player.getEyeLocation().add(player.getEyeLocation().getDirection().multiply(2));
            target = loc.getBlock();
            if (!target.getType().isAir()) {
                plugin.message(player, "&cLook at a chest/barrel/ender chest or face an empty block 2 blocks away.");
                return;
            }
            if (!plugin.worlds().isLobby(target.getWorld())) {
                plugin.message(player, "&cStand in your saved Prison lobby to place physical crates.");
                return;
            }
            target.setType(Material.ENDER_CHEST, false);
        }
        if (!plugin.worlds().isLobby(target.getWorld())) {
            plugin.message(player, "&cPhysical Prison crates can only be placed in your saved Prison lobby.");
            return;
        }
        if (locations.add(key(target))) {
            save();
            plugin.message(player, "&aPhysical crate registered and permanently saved. Right-click it to open your Mining Crates!");
        } else plugin.message(player, "&eThis crate is already registered.");
    }

    public void remove(Player player) {
        Block b = player.getTargetBlockExact(10);
        if (b != null && locations.remove(key(b))) {
            save();
            plugin.message(player, "&aCrate registration removed; the block was not changed.");
        } else plugin.message(player, "&cLook directly at a registered physical crate.");
    }

    public void list(Player player) {
        plugin.message(player, "&bRegistered physical crates: &f" + count());
        locations.stream().sorted().limit(30).forEach(s -> player.sendMessage(plugin.color("&7- " + s)));
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void open(PlayerInteractEvent event) {
        if (!plugin.getConfig().getBoolean("physical-crates.enabled", true)) return;
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK || event.getClickedBlock() == null) return;
        if (!locations.contains(key(event.getClickedBlock()))) return;
        event.setCancelled(true);
        Player player = event.getPlayer();
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (player.isOnline()) plugin.menus().openCrates(player);
        });
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void protect(BlockBreakEvent event) {
        if (locations.contains(key(event.getBlock()))) {
            event.setCancelled(true);
            plugin.message(event.getPlayer(), "&cThis is a protected Prison crate. Use /prisonadmin crate remove to unlink it.");
        }
    }

    @EventHandler public void explosions(EntityExplodeEvent event) {
        event.blockList().removeIf(b -> locations.contains(key(b)));
    }
    @EventHandler public void explosions(BlockExplodeEvent event) {
        event.blockList().removeIf(b -> locations.contains(key(b)));
    }

    public void save() {
        YamlConfiguration yaml = new YamlConfiguration();
        yaml.set("locations", locations.stream().sorted().toList());
        try { yaml.save(file); }
        catch (IOException e) { plugin.getLogger().log(Level.SEVERE, "Could not save physical crates", e); }
    }
}
