package world.arvee.prison;

import java.text.DecimalFormat;
import java.util.Locale;

public final class Amounts {
    private Amounts() {}
    private static final String[] UNITS = {"", "K", "M", "B", "T", "Qa", "Qi"};
    public static String format(double value) {
        if (!Double.isFinite(value)) return "MAX";
        if (value < 0) return "-" + format(-value);
        int i = 0;
        while (value >= 1000 && i < UNITS.length - 1) { value /= 1000; i++; }
        return new DecimalFormat(value >= 100 ? "#,##0" : value >= 10 ? "#,##0.#" : "#,##0.##")
            .format(value) + UNITS[i];
    }
    public static String rank(int rank) { return String.valueOf((char)('A' + Math.max(0, Math.min(25, rank)))); }
    public static int rank(String rank) {
        if (rank == null || rank.length() != 1) return -1;
        char c = rank.toUpperCase(Locale.ROOT).charAt(0);
        return c >= 'A' && c <= 'Z' ? c - 'A' : -1;
    }
}
