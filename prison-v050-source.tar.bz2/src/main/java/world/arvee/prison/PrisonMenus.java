package world.arvee.prison;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;

/** Inventory-based, permission-aware menu router; actions dispatched on next tick. */
public final class PrisonMenus implements Listener {
    private final ArveePrison plugin;
    private static final String MAIN = "ARVEE Prison • Main Menu";
    private static final String MINES = "ARVEE Prison • A-Z Mines";
    private static final String UPGRADES = "ARVEE Prison • Pickaxe";
    private static final String BACKPACK = "ARVEE Prison • Backpack";
    private static final String REWARDS = "ARVEE Prison • Rewards";
    private static final String PROFILE = "ARVEE Prison • Profile";
    private static final String PROGRESSION = "ARVEE Prison • Progression";
    private static final String RESEARCH = "ARVEE Prison • Research Tree";
    private static final String CONTRACTS = "ARVEE Prison • Daily Contracts";
    private static final String CRATES = "ARVEE Prison • Mining Crates";
    private static final String LEADERBOARD = "ARVEE Prison • Hall of Fame";
    public PrisonMenus(ArveePrison plugin) {
        this.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }
    private ItemStack item(Material material, String name, String... description) {
        ItemStack result = new ItemStack(material);
        ItemMeta meta = result.getItemMeta();
        meta.setDisplayName(plugin.color(name));
        List<String> lore = new ArrayList<>();
        for (String s : description) lore.add(plugin.color(s));
        meta.setLore(lore);
        result.setItemMeta(meta);
        return result;
    }
    private Inventory gui(String title, int rows) {
        Inventory gui = Bukkit.createInventory(null, rows * 9, title);
        ItemStack background = item(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < gui.getSize(); i++) gui.setItem(i, background);
        return gui;
    }
    private void back(Inventory gui) { gui.setItem(gui.getSize() - 5, item(Material.ARROW, "&b&lBACK", "&7Return to the main Prison menu")); }
    public void openMain(Player p) {
        PrisonProfile d = plugin.profile(p);
        Inventory gui = gui(MAIN, 6);
        gui.setItem(4, item(Material.NETHER_STAR, "&#19E6FF&lARVEE &f&lADVANCED PRISON",
            "&8Your mining adventure starts here", "&7Rank: &b" + Amounts.rank(d.rank) + " &7| Prestige: &6" + d.prestige,
            "&7Mining Level: &b" + d.miningLevel, "&7Tokens: &e" + Amounts.format(d.tokens)));
        gui.setItem(10, item(Material.DIAMOND_PICKAXE, "&b&lMINES &8• &fA-Z", "&7Travel between 26 rank mines", "&7Your highest mine: &b" + Amounts.rank(d.rank), "&eClick to browse"));
        gui.setItem(12, item(Material.EMERALD, "&a&lRANKS & PRESTIGE", "&7Rank-up, maximum rank-up & prestige", "&7Next rank: &6$" + Amounts.format(plugin.nextRankPrice(d.rank)), "&eClick to open"));
        gui.setItem(14, item(Material.NETHERITE_PICKAXE, "&d&lPICKAXE ENCHANTS", "&7Upgrade efficiency, fortune & jackhammer", "&eClick to manage"));
        gui.setItem(16, item(Material.CHEST, "&6&lBACKPACK", "&7Capacity: &6$" + Amounts.format(plugin.backpackCapacity(d)), "&7Stored: &6$" + Amounts.format(d.backpackValue), "&eClick to open"));
        gui.setItem(19, item(Material.CLOCK, "&e&lDAILY QUEST", "&7Mined today: &f" + d.dailyBlocks, "&7Use /quests claim when complete", "&eClick to see quest"));
        gui.setItem(21, item(Material.GOLD_INGOT, "&6&lSELL ORES", "&7Sell all ore stored in your backpack", "&7Estimated value: &6$" + Amounts.format(d.backpackValue), "&eClick to sell"));
        gui.setItem(23, item(Material.TOTEM_OF_UNDYING, "&a&lREWARDS & BOOSTERS", "&7Daily login, milestones, income boosts", "&eClick to open"));
        gui.setItem(25, item(Material.PLAYER_HEAD, "&b&lPLAYER PROFILE", "&7Money, mining XP, rank and statistics", "&eClick to open"));
        gui.setItem(30, item(Material.COMPARATOR, "&a&lAUTO-SELL", "&7Unlocked: &f" + d.autoSellUnlocked, "&7Enabled: &f" + d.autoSellEnabled, "&eClick to toggle"));
        gui.setItem(32, item(Material.ENCHANTING_TABLE, "&b&lMINING RESEARCH", "&7Four permanent skill paths", "&7Mining level &b" + d.miningLevel, "&eClick to unlock powerful perks"));
        gui.setItem(37, item(Material.WRITABLE_BOOK, "&d&lDAILY CONTRACTS", "&7Three tiered mining contracts", "&7Claimed today: &b" + Integer.bitCount(d.contractClaims) + "/3", "&eClick to view"));
        gui.setItem(39, item(Material.TRIAL_KEY, "&6&lMINING CRATES", "&7Keys earned from mining", "&7Your keys: &e" + d.crateKeys, "&eClick to open"));
        gui.setItem(41, item(Material.WHITE_BANNER, "&a&lGANGS", "&7Build a mining crew", "&7Current: &b" + plugin.gangs().nameOf(p.getUniqueId()), "&eClick for information"));
        gui.setItem(43, item(Material.DIAMOND, "&e&lHALL OF FAME", "&7Top miners and most prestigious players", "&eClick to view"));
        gui.setItem(40, item(Material.BOOK, "&d&lHELP & COMMANDS", "&f/mine &7- browse mines", "&f/rankup max &7- multiple ranks", "&f/pickaxe &7- enchants", "&f/backpack &7- storage", "&f/prisonmenu off &7- disable hotbar item"));
        gui.setItem(45, item(Material.GRASS_BLOCK,"&a&lPLAYER PLOTS","&7Claim your private building island","&eClick for /plot home or claim"));
        gui.setItem(47, item(Material.EMERALD_BLOCK,"&6&lAUCTION HOUSE","&7Buy and sell items with players","&eClick to view listings"));
        gui.setItem(51, item(Material.CLOCK,"&d&lSEASON PASS","&7Season "+plugin.seasons().id()+" &7| &fTier "+plugin.seasons().level(d),"&eClick to inspect rewards"));
        gui.setItem(53, item(Material.GOLDEN_HELMET,"&b&lGANG UPGRADES","&7Earn team bonuses and expand your gang","&eClick to view"));
        gui.setItem(49, item(Material.BARRIER, "&cClose Menu"));
        p.openInventory(gui);
    }
    public void openMines(Player p) {
        PrisonProfile d = plugin.profile(p);
        Inventory gui = gui(MINES, 6);
        int[] mineSlots = {10,11,12,13,14,15,16,19,20,21,22,23,24,25,28,29,30,31,32,33,34,37,38,39,40,41};
        for (int i = 0; i < 26; i++) {
            boolean unlocked = plugin.canEnterMine(p, i);
            gui.setItem(mineSlots[i], item(unlocked ? Material.DIAMOND_ORE : Material.RED_STAINED_GLASS,
                (unlocked ? "&a" : "&c") + "&lMINE " + Amounts.rank(i), unlocked ? "&aUNLOCKED" : "&cLOCKED",
                "&7World: &f" + plugin.worlds().mineName(i),
                "&7Blocks left: &e" + plugin.worlds().percentRemaining(i) + "%",
                "&7Next reset: &b" + plugin.worlds().secondsUntilReset(i) + "s",
                unlocked ? "&eClick to teleport" : "&7Rank-up to gain access"));
        }
        back(gui);
        p.openInventory(gui);
    }
    public void openUpgrades(Player p) {
        PrisonProfile d = plugin.profile(p);
        Inventory gui = gui(UPGRADES, 4);
        gui.setItem(4, item(Material.NETHERITE_PICKAXE, "&b&lPRISON PICKAXE", "&7Permanent upgrades bought with tokens", "&eTokens: " + Amounts.format(d.tokens)));
        gui.setItem(10, item(Material.GOLDEN_PICKAXE, "&b&lEFFICIENCY &f" + d.efficiency,
            "&7Faster block breaking", "&eCost: " + (plugin.getConfig().getInt("pickaxe.efficiency-token-cost",80)*(d.efficiency+1)) + " tokens"));
        gui.setItem(12, item(Material.DIAMOND, "&b&lFORTUNE &f" + d.fortune,
            "&7Chance of doubling ore value", "&eCost: " + (plugin.getConfig().getInt("pickaxe.fortune-token-cost",125)*(d.fortune+1)) + " tokens"));
        gui.setItem(14, item(Material.TNT, "&c&lJACKHAMMER &f" + d.jackhammer,
            "&7Chance of breaking nearby blocks", "&eCost: " + (plugin.getConfig().getInt("pickaxe.jackhammer-token-cost",250)*(d.jackhammer+1)) + " tokens"));
        gui.setItem(16, item(Material.HOPPER, "&a&lAUTO-SELL", d.autoSellUnlocked ? "&aAlready purchased" : "&eCost: " + plugin.getConfig().getInt("pickaxe.autosell-token-cost", 500), "&7Sell mined ore automatically"));
        gui.setItem(28,item(Material.EMERALD_ORE,"&a&lPROSPECTOR &f"+d.prospector,"&7Bonus income on each ore","&eCost: "+(plugin.getConfig().getInt("pickaxe.prospector-token-cost",400)*(d.prospector+1))+" tokens"));
        gui.setItem(30,item(Material.IRON_PICKAXE,"&b&lVEINMINER &f"+d.veinminer,"&7Chance to break a connected 2x2x2 slice","&eCost: "+(plugin.getConfig().getInt("pickaxe.veinminer-token-cost",650)*(d.veinminer+1))+" tokens"));
        gui.setItem(32,item(Material.TRIAL_KEY,"&e&lTREASURE HUNTER &f"+d.treasure,"&7Find extra crate keys while mining","&eCost: "+(plugin.getConfig().getInt("pickaxe.treasure-token-cost",900)*(d.treasure+1))+" tokens"));
        gui.setItem(22, item(Material.NETHERITE_PICKAXE, "&b&lCLAIM / REFRESH PICKAXE", "&7Soulbound to your account", "&eClick to claim"));
        back(gui); p.openInventory(gui);
    }
    public void openBackpack(Player p) {
        PrisonProfile d = plugin.profile(p);
        Inventory gui = gui(BACKPACK, 4);
        gui.setItem(4, item(Material.CHEST, "&6&lVIRTUAL BACKPACK", "&7Your ore earnings are stored here", "&7Level: &f" + d.backpackLevel,
            "&7Stored: &6$" + Amounts.format(d.backpackValue), "&7Capacity: &6$" + Amounts.format(plugin.backpackCapacity(d))));
        gui.setItem(11, item(Material.EMERALD, "&a&lUPGRADE CAPACITY", "&7Increase how much unsold ore you can store",
            "&7Current level: &f" + d.backpackLevel, "&eCost: " + ((long)plugin.getConfig().getInt("advanced.backpack-upgrade-token-cost",75)*(d.backpackLevel+1)) + " tokens"));
        gui.setItem(13, item(Material.GOLD_INGOT, "&6&lSELL BACKPACK", "&7Stored: &6$" + Amounts.format(d.backpackValue), "&eClick to sell everything"));
        gui.setItem(15, item(Material.HOPPER, "&a&lAUTO-SELL", "&7Unlocked: " + d.autoSellUnlocked, "&7Enabled: " + d.autoSellEnabled, "&eClick to toggle (unlock in Pickaxe)"));
        back(gui); p.openInventory(gui);
    }
    public void openRewards(Player p) {
        PrisonProfile d = plugin.profile(p);
        Inventory gui = gui(REWARDS, 4);
        boolean claimable = !LocalDate.now(ZoneOffset.UTC).toString().equals(d.lastDailyClaim);
        List<Integer> milestones = plugin.getConfig().getIntegerList("advanced.achievement-thresholds");
        String target = d.achievementClaims >= milestones.size() ? "All milestones claimed" :
            Amounts.format(milestones.get(d.achievementClaims)) + " blocks needed";
        gui.setItem(4, item(Material.NETHER_STAR, "&e&lREWARDS HUB", "&7Mine, return each day, earn boosters"));
        gui.setItem(11, item(Material.CLOCK, "&6&lDAILY LOGIN", "&7Current streak: &e" + d.dailyStreak,
            claimable ? "&aReady to claim!" : "&cAlready claimed today", "&7Resets at midnight UTC"));
        gui.setItem(13, item(Material.AMETHYST_SHARD, "&d&lMINING MILESTONES", "&7Total mined: &f" + Amounts.format(d.minedBlocks),
            "&7Next target: &b" + target, "&7Claimed milestones: &a" + d.achievementClaims,
            "&eClick to claim available milestone"));
        gui.setItem(15, item(Material.BLAZE_POWDER, "&e&lINCOME BOOSTER", "&7Double income temporarily", "&7Active: " + (d.boosted()?"&aYES":"&cNO"),
            "&7Cost: &e" + plugin.getConfig().getLong("advanced.booster-price-tokens",200) + " tokens", "&eClick to buy / extend"));
        back(gui); p.openInventory(gui);
    }
    public void openProfile(Player p) {
        PrisonProfile d = plugin.profile(p);
        Inventory gui = gui(PROFILE, 4);
        gui.setItem(4, item(Material.PLAYER_HEAD, "&b&l" + p.getName() + " &f&lPROFILE", "&7Prison character statistics"));
        gui.setItem(10, item(Material.EMERALD, "&aRANK &b" + Amounts.rank(d.rank), "&7Next cost: &6$" + Amounts.format(plugin.nextRankPrice(d.rank))));
        gui.setItem(12, item(Material.NETHER_STAR, "&6PRESTIGE &f" + d.prestige, "&7Permanent ore sell bonus"));
        gui.setItem(14, item(Material.EXPERIENCE_BOTTLE, "&bMINING LEVEL &f" + d.miningLevel,
            "&7Experience: &e" + d.miningXp + "/" + d.xpToNextLevel(), "&7Blocks mined: &e" + Amounts.format(d.minedBlocks)));
        gui.setItem(16, item(Material.GOLD_INGOT, "&6ECONOMY", "&7Money: &6$" + Amounts.format(d.money), "&7Tokens: &e" + Amounts.format(d.tokens),
            "&7Lifetime earned: &6$" + Amounts.format(d.totalEarned)));
        gui.setItem(22, item(Material.BOOK, "&dADDITIONAL STATS", "&7Backpack level: " + d.backpackLevel,
            "&7Milestones claimed: " + d.achievementClaims, "&7Daily streak: " + d.dailyStreak,
            "&7Boosters purchased: " + d.boosterPurchases));
        back(gui); p.openInventory(gui);
    }
    public void openProgression(Player p) {
        PrisonProfile d = plugin.profile(p);
        Inventory gui = gui(PROGRESSION, 4);
        gui.setItem(4, item(Material.NETHER_STAR, "&e&lRANKS & PRESTIGE", "&7Unlock mines and permanent multipliers"));
        gui.setItem(11, item(Material.EMERALD, "&a&lRANK UP", "&7Current rank: &f" + Amounts.rank(d.rank),
            "&7Next cost: &6$" + Amounts.format(plugin.nextRankPrice(d.rank)), "&eClick to purchase next rank"));
        gui.setItem(13, item(Material.EMERALD_BLOCK, "&a&lRANK UP MAX", "&7Purchase as many ranks as you can afford", "&eClick to rank up repeatedly"));
        gui.setItem(15, item(Material.BEACON, "&6&lPRESTIGE", "&7Requires Rank Z", "&7Current prestige: &f" + d.prestige,
            "&7Prestige cost: &6$" + Amounts.format(plugin.prestigePrice(d.prestige)), "&eClick to prestige"));
        back(gui); p.openInventory(gui);
    }
    public void openResearch(Player p) {
        PrisonProfile d = plugin.profile(p);
        Inventory gui = gui(RESEARCH, 4);
        gui.setItem(4, item(Material.ENCHANTING_TABLE, "&b&lMINING RESEARCH TREE", "&7Use tokens to unlock permanent passive bonuses", "&7Requires increasing mining levels", "&eYour tokens: " + Amounts.format(d.tokens)));
        node(gui, 10, Material.GOLD_INGOT, "ORE ECONOMY", "income", d.researchIncome, "More value per mined ore");
        node(gui, 12, Material.SUNFLOWER, "TOKEN FINDER", "tokens", d.researchTokens, "Find extra tokens while mining");
        node(gui, 14, Material.EXPERIENCE_BOTTLE, "MINING KNOWLEDGE", "xp", d.researchXp, "Earn mining XP faster");
        node(gui, 16, Material.TNT, "DEEP EXCAVATION", "jackhammer", d.researchJackhammer, "Jackhammer triggers more often");
        back(gui); p.openInventory(gui);
    }
    private void node(Inventory gui, int slot, Material material, String name, String type, int level, String description) {
        long price = plugin.getConfig().getLong("research.base-token-cost", 100) * (level + 1L) * (level + 1L);
        int mineReq = (level + 1) * plugin.getConfig().getInt("research.mining-level-per-tier", 4);
        gui.setItem(slot, item(material, "&b&l" + name, "&7" + description, "&7Skill Level: &f" + level + "/" + plugin.getConfig().getInt("research.max-level",10),
            "&7Next cost: &e" + Amounts.format(price) + " tokens", "&7Required mining level: &b" + mineReq, "&eClick to research " + type));
    }
    public void openContracts(Player p) {
        PrisonProfile d = plugin.profile(p);
        d.refreshDaily();
        Inventory gui = gui(CONTRACTS, 4);
        gui.setItem(4, item(Material.WRITABLE_BOOK, "&d&lDAILY CONTRACTS", "&7Reset at midnight UTC", "&7Blocks mined today: &e" + d.dailyBlocks, "&7Each tier has an independent reward"));
        int[] slots = {11,13,15};
        Material[] icons = {Material.IRON_PICKAXE, Material.DIAMOND_PICKAXE, Material.NETHERITE_PICKAXE};
        for (int tier = 0; tier < 3; tier++) {
            int goal = plugin.getConfig().getInt("contracts.tier-"+(tier+1)+"-blocks",new int[]{150,500,1500}[tier]);
            boolean done = (d.contractClaims & (1 << tier)) != 0;
            gui.setItem(slots[tier], item(icons[tier], "&b&lCONTRACT TIER " + (tier+1), "&7Mine &e" + Amounts.format(goal) + "&7 blocks today",
                "&7Progress: &b" + Math.min(goal,d.dailyBlocks) + "/" + goal,
                "&7Token reward: &e" + Amounts.format(plugin.getConfig().getLong("contracts.tier-"+(tier+1)+"-tokens",(tier+1)*75)),
                done ? "&aAlready claimed" : (d.dailyBlocks >= goal ? "&aClick to CLAIM!" : "&cStill mining...")));
        }
        back(gui); p.openInventory(gui);
    }
    public void openCrates(Player p) {
        PrisonProfile d = plugin.profile(p);
        Inventory gui = gui(CRATES, 4);
        gui.setItem(4, item(Material.TRIAL_KEY, "&6&lMINE CRATES", "&7Mining rewards earned through gameplay", "&7Current keys: &e" + d.crateKeys, "&7Total opened: &b" + d.cratesOpened));
        gui.setItem(11, item(Material.GOLD_INGOT, "&e&lMONEY REWARD", "&740% chance", "&7Scales with current rank and prestige"));
        gui.setItem(13, item(Material.CHEST, "&a&lOPEN A CRATE", "&7Consume &e1 key &7to roll loot", "&7You earn keys automatically by mining", "&eClick to open now"));
        gui.setItem(15, item(Material.BLAZE_POWDER, "&d&lBOOSTERS & TOKENS", "&7Boosters: 10% chance", "&7Tokens: 50% chance"));
        back(gui); p.openInventory(gui);
    }
    public void openLeaderboard(Player p) {
        Inventory gui = gui(LEADERBOARD, 4);
        gui.setItem(4, item(Material.NETHER_STAR, "&e&lHALL OF FAME", "&7Rankings include saved offline players"));
        gui.setItem(10, item(Material.DIAMOND_PICKAXE, "&bMOST BLOCKS MINED", "&eClick for top 10"));
        gui.setItem(12, item(Material.BEACON, "&6HIGHEST PRESTIGE", "&eClick for top 10"));
        gui.setItem(14, item(Material.EXPERIENCE_BOTTLE, "&aHIGHEST MINING LEVEL", "&eClick for top 10"));
        gui.setItem(16, item(Material.GOLD_INGOT, "&eRICHEST MINERS", "&eClick for top 10"));
        back(gui); p.openInventory(gui);
    }
    private boolean isMenu(String title) {
        return title.equals(MAIN) || title.equals(MINES) || title.equals(UPGRADES) || title.equals(BACKPACK)
            || title.equals(REWARDS) || title.equals(PROFILE) || title.equals(PROGRESSION) || title.equals(RESEARCH)
            || title.equals(CONTRACTS) || title.equals(CRATES) || title.equals(LEADERBOARD);
    }
    @EventHandler public void click(InventoryClickEvent e) {
        String title = e.getView().getTitle();
        if (!isMenu(title)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        int slot = e.getRawSlot();
        if (slot < 0 || slot >= e.getView().getTopInventory().getSize()) return;
        ItemStack clicked = e.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.BLACK_STAINED_GLASS_PANE) return;
        Bukkit.getScheduler().runTask(plugin, () -> handleClick(title,p,slot));
    }
    @EventHandler public void drag(InventoryDragEvent e) { if (isMenu(e.getView().getTitle())) e.setCancelled(true); }
    private void handleClick(String title, Player p, int slot) {
        if (!p.isOnline()) return;
        switch (title) {
            case MAIN -> {
                switch (slot) {
                    case 10 -> openMines(p);
                    case 12 -> openProgression(p);
                    case 14 -> openUpgrades(p);
                    case 16 -> openBackpack(p);
                    case 19 -> { p.closeInventory(); p.performCommand("quests"); }
                    case 21 -> { p.closeInventory(); p.performCommand("sell"); }
                    case 23 -> openRewards(p);
                    case 25 -> openProfile(p);
                    case 30 -> { p.closeInventory(); p.performCommand("autosell"); }
                    case 32 -> openResearch(p);
                    case 37 -> openContracts(p);
                    case 39 -> openCrates(p);
                    case 41 -> { p.closeInventory(); p.performCommand("gang info"); }
                    case 43 -> openLeaderboard(p);
                    case 45 -> {p.closeInventory();p.performCommand("plot " + (plugin.plots().owns(p.getUniqueId())?"home":"claim"));}
                    case 47 -> {p.closeInventory();p.performCommand("auction list");}
                    case 51 -> {p.closeInventory();p.performCommand("season");}
                    case 53 -> {p.closeInventory();p.performCommand("gang info");}
                    case 49 -> p.closeInventory();
                    default -> { }
                }
            }
            case MINES -> {
                if (slot == 49) {openMain(p); return;}
                int[] mineSlots = {10,11,12,13,14,15,16,19,20,21,22,23,24,25,28,29,30,31,32,33,34,37,38,39,40,41};
                for (int i = 0; i < 26; i++) if (mineSlots[i] == slot) {
                    if (!plugin.canEnterMine(p, i)) {
                        plugin.message(p, "&cMine " + Amounts.rank(i) + " is locked. Use /rankup."); return;
                    }
                    p.closeInventory(); plugin.worlds().travel(p,i); return;
                }
            }
            case UPGRADES -> {
                switch (slot) {
                    case 10 -> plugin.upgrade(p,"efficiency");
                    case 12 -> plugin.upgrade(p,"fortune");
                    case 14 -> plugin.upgrade(p,"jackhammer");
                    case 16 -> plugin.upgrade(p,"autosell");
                    case 22 -> plugin.grantPickaxe(p);
                    case 28 -> plugin.upgrade(p,"prospector");
                    case 30 -> plugin.upgrade(p,"veinminer");
                    case 32 -> plugin.upgrade(p,"treasure");
                    case 31 -> openMain(p);
                    default -> { }
                }
            }
            case BACKPACK -> {
                switch (slot) {
                    case 11 -> plugin.upgradeBackpack(p);
                    case 13 -> {p.closeInventory();p.performCommand("sell");}
                    case 15 -> {p.closeInventory();p.performCommand("autosell");}
                    case 31 -> openMain(p);
                    default -> { }
                }
            }
            case REWARDS -> {
                switch (slot) {
                    case 11 -> plugin.claimLoginReward(p);
                    case 13 -> plugin.claimAchievement(p);
                    case 15 -> plugin.purchaseBooster(p);
                    case 31 -> openMain(p);
                    default -> { }
                }
            }
            case PROFILE -> { if (slot == 31) openMain(p); }
            case RESEARCH -> {
                switch(slot) {
                    case 10 -> plugin.research(p, "income");
                    case 12 -> plugin.research(p, "tokens");
                    case 14 -> plugin.research(p, "xp");
                    case 16 -> plugin.research(p, "jackhammer");
                    case 31 -> openMain(p);
                    default -> { }
                }
            }
            case CONTRACTS -> {
                switch(slot) {
                    case 11 -> plugin.claimContract(p, 0);
                    case 13 -> plugin.claimContract(p, 1);
                    case 15 -> plugin.claimContract(p, 2);
                    case 31 -> openMain(p);
                    default -> { }
                }
            }
            case CRATES -> {
                if (slot == 13) plugin.openCrate(p);
                if (slot == 31) openMain(p);
            }
            case LEADERBOARD -> {
                if (slot == 31) { openMain(p); return; }
                String type = switch(slot) {
                    case 10 -> "blocks";
                    case 12 -> "prestige";
                    case 14 -> "level";
                    case 16 -> "money";
                    default -> null;
                };
                if (type != null) { p.closeInventory(); plugin.leaderboard(p, type); }
            }
            case PROGRESSION -> {
                switch (slot) {
                    case 11 -> {p.closeInventory();p.performCommand("rankup");}
                    case 13 -> {p.closeInventory();p.performCommand("rankup max");}
                    case 15 -> {p.closeInventory();p.performCommand("prestige");}
                    case 31 -> openMain(p);
                    default -> { }
                }
            }
            default -> { }
        }
    }
}
