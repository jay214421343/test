package world.arvee.prison;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.generator.ChunkGenerator;
import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Non-destructive single-world plots. Claims and generated plot IDs are persisted independently of worlds. */
public final class PrisonPlots implements Listener {
    private final ArveePrison plugin;
    private final File file;
    private final Map<UUID, Claim> claims = new HashMap<>();
    private final Map<Integer, Claim> ids = new HashMap<>();
    private int nextId = 1;
    private static final int Y = 80;
    private static final class Claim {
        UUID owner; int id; boolean built; Set<UUID> trusted = new HashSet<>();
        Claim(UUID owner, int id) { this.owner = owner; this.id = id; }
    }
    public PrisonPlots(ArveePrison plugin) {
        this.plugin = plugin; this.file = new File(plugin.getDataFolder(), "plots.yml");
        load(); Bukkit.getPluginManager().registerEvents(this, plugin);
    }
    private int spacing() { return Math.max(96, plugin.getConfig().getInt("plots.spacing", 160)); }
    private int radius() { return Math.max(8, Math.min(40, plugin.getConfig().getInt("plots.radius", 18))); }
    private String worldName() { return plugin.getConfig().getString("plots.world", "prison_plots"); }
    private int cx(int id) { return (id % 1000) * spacing(); }
    private int cz(int id) { return (id / 1000) * spacing(); }
    private World world() {
        World world = Bukkit.getWorld(worldName());
        if (world != null) return world;
        WorldCreator creator = new WorldCreator(worldName()).generateStructures(false);
        creator.generator(new ChunkGenerator() {
            @Override public boolean shouldGenerateNoise() { return false; }
            @Override public boolean shouldGenerateSurface() { return false; }
            @Override public boolean shouldGenerateCaves() { return false; }
            @Override public boolean shouldGenerateDecorations() { return false; }
            @Override public boolean shouldGenerateMobs() { return false; }
            @Override public boolean shouldGenerateStructures() { return false; }
        });
        world = Bukkit.createWorld(creator);
        if (world != null) {
            world.setDifficulty(Difficulty.PEACEFUL); world.setPVP(false); world.setSpawnFlags(false, false);
            world.setGameRule(GameRule.DO_MOB_SPAWNING, false);
            world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
            world.setTime(6000L);
        }
        return world;
    }
    private void generate(World w, Claim claim) {
        int x = cx(claim.id), z = cz(claim.id), r = radius();
        for (int dx=-r-1; dx<=r+1; dx++) for(int dz=-r-1; dz<=r+1; dz++) {
            boolean edge = Math.abs(dx)>r || Math.abs(dz)>r;
            w.getBlockAt(x+dx,Y-1,z+dz).setType(edge ? Material.POLISHED_DEEPSLATE : Material.GRASS_BLOCK, false);
            w.getBlockAt(x+dx,Y-2,z+dz).setType(Material.STONE, false);
        }
        w.getBlockAt(x,Y,z).setType(Material.TORCH, false);
        claim.built = true; save();
    }
    private Location home(World w, Claim claim) { return new Location(w,cx(claim.id)+.5,Y+1,cz(claim.id)+.5,0,0); }
    private Claim at(int x,int z) {
        int s = spacing(); int px = (int)Math.floor((x + s/2.0) / s), pz = (int)Math.floor((z + s/2.0) / s);
        int dx=x-px*s, dz=z-pz*s;
        if (Math.abs(dx)>radius() || Math.abs(dz)>radius() || px<0 || pz<0 || px>=1000) return null;
        return ids.get(pz*1000+px);
    }
    public boolean owns(UUID uuid) { return claims.containsKey(uuid); }
    public int plotId(UUID uuid) { Claim c=claims.get(uuid); return c==null?0:c.id; }
    public void command(Player p, String[] args) {
        String sub = args.length==0 ? "info" : args[0].toLowerCase(Locale.ROOT);
        Claim claim = claims.get(p.getUniqueId());
        switch(sub) {
            case "claim", "create" -> {
                if (claim != null) { plugin.message(p,"&eYou already have a plot. Use /plot home."); return; }
                if (nextId >= 999999) {plugin.message(p,"&cPlot capacity reached."); return;}
                World w = world(); if (w==null) {plugin.message(p,"&cCould not load plot world."); return;}
                Claim c = new Claim(p.getUniqueId(),nextId++);
                claims.put(p.getUniqueId(),c); ids.put(c.id,c); save();
                generate(w,c); p.teleport(home(w,c)); plugin.message(p,"&aYour plot #"+c.id+" is ready. It will never be regenerated automatically.");
            }
            case "home" -> {
                if (claim==null) {plugin.message(p,"&eUse /plot claim first.");return;}
                World w=world(); if(w==null)return;
                if(!claim.built)generate(w,claim);
                p.teleport(home(w,claim));
            }
            case "visit" -> {
                if(args.length<2){plugin.message(p,"&cUsage: /plot visit <online player>");return;}
                Player target=Bukkit.getPlayerExact(args[1]);
                Claim other=target==null?null:claims.get(target.getUniqueId());
                if(other==null){plugin.message(p,"&cThat player has no plot or is offline.");return;}
                World w=world();if(w==null)return;
                if(!other.built)generate(w,other);
                p.teleport(home(w,other));
            }
            case "trust", "untrust" -> {
                if(claim==null){plugin.message(p,"&cClaim a plot first.");return;}
                Player target=args.length>1?Bukkit.getPlayerExact(args[1]):null;
                if(target==null || target.getUniqueId().equals(p.getUniqueId())) {plugin.message(p,"&cSpecify another online player.");return;}
                if(sub.equals("trust"))claim.trusted.add(target.getUniqueId()); else claim.trusted.remove(target.getUniqueId());
                save();plugin.message(p,"&aPlot permissions updated for "+target.getName()+".");
            }
            case "info" -> plugin.message(p, claim==null?"&bPlots: /plot claim | visit <player> | home":"&bPlot #"+claim.id+" &7| &f/plot home &7| &f/plot trust <player> &7| &f/plot untrust <player>");
            default -> plugin.message(p,"&cUse /plot claim|home|visit|trust|untrust|info");
        }
    }
    private boolean canEdit(Player p, Block b) {
        if(!b.getWorld().getName().equals(worldName()))return true;
        Claim c=at(b.getX(),b.getZ());
        return c!=null && b.getY()>=Y && (c.owner.equals(p.getUniqueId()) || c.trusted.contains(p.getUniqueId()));
    }
    @EventHandler(ignoreCancelled=true,priority=EventPriority.HIGHEST) public void breakBlock(BlockBreakEvent e){if(!canEdit(e.getPlayer(),e.getBlock()))e.setCancelled(true);}
    @EventHandler(ignoreCancelled=true,priority=EventPriority.HIGHEST) public void place(BlockPlaceEvent e){if(!canEdit(e.getPlayer(),e.getBlock()))e.setCancelled(true);}
    @EventHandler(ignoreCancelled=true,priority=EventPriority.HIGHEST) public void bucket(PlayerBucketEmptyEvent e){if(!canEdit(e.getPlayer(),e.getBlockClicked().getRelative(e.getBlockFace())))e.setCancelled(true);}
    @EventHandler(ignoreCancelled=true,priority=EventPriority.HIGHEST) public void interact(PlayerInteractEvent e){
        if(e.getClickedBlock()==null)return;
        if(!e.getClickedBlock().getWorld().getName().equals(worldName()))return;
        switch(e.getAction()){
            case RIGHT_CLICK_BLOCK -> {
                Block b=e.getClickedBlock();
                if((b.getState() instanceof org.bukkit.block.Container || b.getType().name().contains("DOOR") || b.getType().name().contains("BUTTON") || b.getType().name().contains("LEVER")) && !canEdit(e.getPlayer(),b))e.setCancelled(true);
            }
            default -> { }
        }
    }
    @EventHandler(ignoreCancelled=true) public void explosion(org.bukkit.event.entity.EntityExplodeEvent e){if(e.getLocation().getWorld().getName().equals(worldName()))e.blockList().clear();}
    @EventHandler(ignoreCancelled=true) public void blockExplosion(BlockExplodeEvent e){if(e.getBlock().getWorld().getName().equals(worldName()))e.blockList().clear();}
    @EventHandler(ignoreCancelled=true) public void flow(BlockFromToEvent e){
        if(!e.getBlock().getWorld().getName().equals(worldName()))return;
        Claim from=at(e.getBlock().getX(),e.getBlock().getZ()), to=at(e.getToBlock().getX(),e.getToBlock().getZ());
        if(from==null || to==null || from!=to)e.setCancelled(true);
    }
    @EventHandler(ignoreCancelled=true) public void piston(BlockPistonExtendEvent e){if(e.getBlock().getWorld().getName().equals(worldName()))e.setCancelled(true);}
    @EventHandler(ignoreCancelled=true) public void pistonRetract(BlockPistonRetractEvent e){if(e.getBlock().getWorld().getName().equals(worldName()))e.setCancelled(true);}
    private void load() {
        YamlConfiguration y=YamlConfiguration.loadConfiguration(file);
        nextId=Math.max(1,y.getInt("next-id",1));
        if(y.getConfigurationSection("plots")!=null)for(String key:y.getConfigurationSection("plots").getKeys(false)){
            try{
                UUID owner=UUID.fromString(key);int id=y.getInt("plots."+key+".id",0);
                if(id<=0 || ids.containsKey(id))continue;
                Claim c=new Claim(owner,id);c.built=y.getBoolean("plots."+key+".built",false);
                for(String v:y.getStringList("plots."+key+".trusted"))try{c.trusted.add(UUID.fromString(v));}catch(IllegalArgumentException ignored){}
                claims.put(owner,c);ids.put(id,c);nextId=Math.max(nextId,id+1);
            }catch(IllegalArgumentException ignored){}
        }
    }
    public void save() {
        YamlConfiguration y=new YamlConfiguration(); y.set("next-id",nextId);
        for(Claim c:claims.values()){
            String key="plots."+c.owner+".";y.set(key+"id",c.id);y.set(key+"built",c.built);y.set(key+"trusted",c.trusted.stream().map(UUID::toString).toList());
        }
        try { File tmp=new File(file.getParentFile(),"plots.yml.tmp");y.save(tmp);try{Files.move(tmp.toPath(),file.toPath(),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}catch(AtomicMoveNotSupportedException e){Files.move(tmp.toPath(),file.toPath(),StandardCopyOption.REPLACE_EXISTING);} }
        catch(IOException e){plugin.getLogger().severe("Could not save plots: "+e.getMessage());}
    }
}
