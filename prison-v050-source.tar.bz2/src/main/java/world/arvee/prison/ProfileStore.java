package world.arvee.prison;

import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

public final class ProfileStore {
    private final ArveePrison plugin;
    private final Map<UUID, PrisonProfile> data = new HashMap<>();
    private final File file;
    public ProfileStore(ArveePrison plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "players.yml");
        load();
    }

    public PrisonProfile profile(UUID uuid) {
        return data.computeIfAbsent(uuid, id -> {
            PrisonProfile p = new PrisonProfile(id);
            p.money = plugin.getConfig().getDouble("progression.starting-money", 0);
            p.tokens = plugin.getConfig().getLong("progression.starting-tokens", 0);
            return p;
        });
    }

    public void load() {
        data.clear();
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        if (yaml.getConfigurationSection("players") == null) return;
        for (String key : yaml.getConfigurationSection("players").getKeys(false)) {
            try {
                UUID id = UUID.fromString(key);
                String path = "players." + key + ".";
                PrisonProfile p = new PrisonProfile(id);
                p.lastName = yaml.getString(path + "name", "");
                p.rank = Math.max(0, Math.min(25, yaml.getInt(path + "rank", 0)));
                p.prestige = Math.max(0, yaml.getInt(path + "prestige", 0));
                p.money = Math.max(0, yaml.getDouble(path + "money", 0));
                p.tokens = Math.max(0, yaml.getLong(path + "tokens", 0));
                p.backpackValue = Math.max(0, yaml.getDouble(path + "backpack", 0));
                p.minedBlocks = Math.max(0, yaml.getLong(path + "mined", 0));
                p.efficiency = Math.max(0, yaml.getInt(path + "efficiency", 0));
                p.fortune = Math.max(0, yaml.getInt(path + "fortune", 0));
                p.jackhammer = Math.max(0, yaml.getInt(path + "jackhammer", 0));
                p.backpackLevel = Math.max(0, yaml.getInt(path + "backpack-level", 0));
                p.miningXp = Math.max(0, yaml.getLong(path + "mining-xp", 0));
                p.miningLevel = Math.max(1, Math.min(200, yaml.getInt(path + "mining-level", 1)));
                p.achievementClaims = Math.max(0, yaml.getInt(path + "achievement-claims", 0));
                p.totalEarned = Math.max(0, yaml.getLong(path + "total-earned", 0));
                p.dailyStreak = Math.max(0, yaml.getInt(path + "daily-streak", 0));
                p.lastDailyClaim = yaml.getString(path + "last-daily-claim", "");
                p.boosterUntil = Math.max(0, yaml.getLong(path + "booster-until", 0));
                p.boosterPurchases = Math.max(0, yaml.getInt(path + "booster-purchases", 0));
                p.lifetimeTokens = Math.max(0, yaml.getLong(path + "lifetime-tokens", 0));
                p.researchIncome = safeInt(yaml.getInt(path + "research-income", 0), 10);
                p.researchTokens = safeInt(yaml.getInt(path + "research-tokens", 0), 10);
                p.researchXp = safeInt(yaml.getInt(path + "research-xp", 0), 10);
                p.researchJackhammer = safeInt(yaml.getInt(path + "research-jackhammer", 0), 10);
                p.contractClaims = safeInt(yaml.getInt(path + "contract-claims", 0), 7);
                p.prospector = safeInt(yaml.getInt(path + "prospector", 0), 10);
                p.veinminer = safeInt(yaml.getInt(path + "veinminer", 0), 10);
                p.treasure = safeInt(yaml.getInt(path + "treasure", 0), 10);
                p.seasonId = Math.max(1, yaml.getInt(path + "season-id", 1));
                p.seasonXp = Math.max(0, yaml.getLong(path + "season-xp", 0));
                p.seasonClaims = Math.max(0, yaml.getLong(path + "season-claims", 0));
                p.crateKeys = safeInt(yaml.getInt(path + "crate-keys", 0), 1000000);
                p.cratesOpened = Math.max(0, yaml.getInt(path + "crates-opened", 0));
                p.menuEnabled = yaml.getBoolean(path + "hotbar-menu", true);
                p.autoSellUnlocked = yaml.getBoolean(path + "autosell-unlocked", false);
                p.autoSellEnabled = yaml.getBoolean(path + "autosell-enabled", false);
                p.questDay = yaml.getString(path + "quest-day", p.questDay);
                p.dailyBlocks = Math.max(0, yaml.getInt(path + "daily-blocks", 0));
                p.claimedDaily = yaml.getBoolean(path + "daily-claimed", false);
                data.put(id, p);
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("Skipping invalid profile ID " + key);
            }
        }
        plugin.getLogger().info("Loaded " + data.size() + " prison profiles");
    }

    public java.util.List<PrisonProfile> all() { return java.util.List.copyOf(data.values()); }
    private static int safeInt(int n, int limit) { return Math.max(0, Math.min(limit, n)); }
    public void save() {
        YamlConfiguration yaml = new YamlConfiguration();
        for (PrisonProfile p : data.values()) {
            String path = "players." + p.uuid + ".";
            yaml.set(path + "name", p.lastName);
            yaml.set(path + "rank", p.rank);
            yaml.set(path + "prestige", p.prestige);
            yaml.set(path + "money", p.money);
            yaml.set(path + "tokens", p.tokens);
            yaml.set(path + "backpack", p.backpackValue);
            yaml.set(path + "mined", p.minedBlocks);
            yaml.set(path + "efficiency", p.efficiency);
            yaml.set(path + "fortune", p.fortune);
            yaml.set(path + "jackhammer", p.jackhammer);
            yaml.set(path + "backpack-level", p.backpackLevel);
            yaml.set(path + "mining-xp", p.miningXp);
            yaml.set(path + "mining-level", p.miningLevel);
            yaml.set(path + "achievement-claims", p.achievementClaims);
            yaml.set(path + "total-earned", p.totalEarned);
            yaml.set(path + "daily-streak", p.dailyStreak);
            yaml.set(path + "last-daily-claim", p.lastDailyClaim);
            yaml.set(path + "booster-until", p.boosterUntil);
            yaml.set(path + "booster-purchases", p.boosterPurchases);
            yaml.set(path + "lifetime-tokens", p.lifetimeTokens);
            yaml.set(path + "research-income", p.researchIncome);
            yaml.set(path + "research-tokens", p.researchTokens);
            yaml.set(path + "research-xp", p.researchXp);
            yaml.set(path + "research-jackhammer", p.researchJackhammer);
            yaml.set(path + "contract-claims", p.contractClaims);
            yaml.set(path + "prospector", p.prospector);
            yaml.set(path + "veinminer", p.veinminer);
            yaml.set(path + "treasure", p.treasure);
            yaml.set(path + "season-id", p.seasonId);
            yaml.set(path + "season-xp", p.seasonXp);
            yaml.set(path + "season-claims", p.seasonClaims);
            yaml.set(path + "crate-keys", p.crateKeys);
            yaml.set(path + "crates-opened", p.cratesOpened);
            yaml.set(path + "hotbar-menu", p.menuEnabled);
            yaml.set(path + "autosell-unlocked", p.autoSellUnlocked);
            yaml.set(path + "autosell-enabled", p.autoSellEnabled);
            yaml.set(path + "quest-day", p.questDay);
            yaml.set(path + "daily-blocks", p.dailyBlocks);
            yaml.set(path + "daily-claimed", p.claimedDaily);
        }
        try {
            File tmp = new File(file.getParentFile(), "players.yml.tmp");
            yaml.save(tmp);
            try {
                java.nio.file.Files.move(tmp.toPath(), file.toPath(),
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                    java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            } catch (java.nio.file.AtomicMoveNotSupportedException ex) {
                java.nio.file.Files.move(tmp.toPath(), file.toPath(),
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Unable to save Prison profiles", ex);
        }
    }
}
