import world.arvee.prison.Amounts;
import world.arvee.prison.PrisonProfile;
import java.util.UUID;
public class ArveeSmokeTest {
 public static void main(String[] args) {
  if (!Amounts.rank(0).equals("A") || !Amounts.rank(25).equals("Z")) throw new AssertionError("A-Z ranks");
  if (Amounts.rank("C") != 2 || Amounts.rank("z") != 25 || Amounts.rank("27") != -1) throw new AssertionError("parse rank");
  if (!Amounts.format(1500000).endsWith("M")) throw new AssertionError("format money");
  PrisonProfile p = new PrisonProfile(UUID.randomUUID());
  p.prestige=3;
  if (Math.abs(p.multiplier(.2)-1.6)>.000001) throw new AssertionError("prestige multiplier");
  System.out.println("PASS: rank parsing A-Z, money formatting, prestige scaling");
 }
}
