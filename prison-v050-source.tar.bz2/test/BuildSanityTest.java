// Independent source consistency check; the actual build must use Paper API from Gradle.
// Compile plugin with: gradle clean build --no-daemon (Java 25).
public class BuildSanityTest {
    public static void main(String[] args) { System.out.println("Build against the real Paper API."); }
}
