package world.arvee.prison;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.UUID;

public final class ArveePrison extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {
    private final Random random = new Random();
    private ProfileStore profiles;
    private Worlds worlds;
    private PrisonMenus menus;
    private NamespacedKey pickaxeKey;
    private NamespacedKey ownerKey;

    @Override public void onEnable() {
        saveDefaultConfig();
        pickaxeKey = new NamespacedKey(this, "prison_pickaxe");
        ownerKey = new NamespacedKey(this, "pickaxe_owner");
        profiles = new ProfileStore(this);
        worlds = new Worlds(this);
        menus = new PrisonMenus(this);
        Bukkit.getPluginManager().registerEvents(this, this);
        for (String name : Arrays.asList("prison", "mines", "mine", "rankup", "prestige", "sell",
            "balance", "tokens", "pickaxe", "autosell", "quests", "prisonadmin")) {
            PluginCommand command = getCommand(name);
            if (command == null) { getLogger().severe("Missing command in plugin.yml: " + name); continue; }
            command.setExecutor(this);
            command.setTabCompleter(this);
        }
        Bukkit.getScheduler().runTaskTimer(this, profiles::save, 20L * 300, 20L * 300);
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (getConfig().contains("lobby-spawn")) worlds.loadConfiguredLobby();
            else if (getConfig().getBoolean("worlds.create-lobby-on-start", false)) worlds.setupLobby();
        }, 5L);
        getLogger().info("ARVEE Prison 0.1.1 enabled. Use /prisonadmin setup, then /prison.");
    }

    @Override public void onDisable() {
        if (profiles != null) profiles.save();
        if (worlds != null) worlds.saveState();
    }

    public PrisonProfile profile(Player player) {
        PrisonProfile p = profiles.profile(player.getUniqueId());
        p.lastName = player.getName();
        p.refreshDaily();
        return p;
    }
    public void message(CommandSender recipient, String text) {
        String prefix = getConfig().getString("messages.prefix", "&b&lARVEE &8» &7");
        recipient.sendMessage(color(prefix + text));
    }
    public String color(String str) { return ChatColor.translateAlternateColorCodes('&', str); }
    public Worlds worlds() { return worlds; }
    public PrisonMenus menus() { return menus; }

    public double nextRankPrice(int rank) {
        if (rank >= 25) return Double.POSITIVE_INFINITY;
        return getConfig().getDouble("progression.rankup-base-price", 1500.0)
            * Math.pow(getConfig().getDouble("progression.rankup-price-multiplier", 1.7), rank);
    }
    public double prestigePrice(int prestige) {
        return getConfig().getDouble("progression.prestige-cost", 500000000.0) * Math.pow(3.0, prestige);
    }
    public double blockValue(PrisonProfile p, int rank, Material type) {
        double materialBonus = switch (type) {
            case COAL_ORE -> 1.15;
            case IRON_ORE -> 1.25;
            case GOLD_ORE -> 1.5;
            case DIAMOND_ORE, DEEPSLATE_DIAMOND_ORE -> 1.75;
            case EMERALD_ORE, DEEPSLATE_EMERALD_ORE -> 2.0;
            case ANCIENT_DEBRIS -> 2.6;
            default -> 1.0;
        };
        double base = getConfig().getDouble("progression.ore-base-value", 8.0);
        double byRank = getConfig().getDouble("progression.ore-rank-value-multiplier", 1.50);
        return base * Math.pow(byRank, rank) * materialBonus
            * p.multiplier(getConfig().getDouble("progression.prestige-sell-bonus-per-level", 0.2));
    }

    @EventHandler public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        profile(player);
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (!player.isOnline()) return;
            if (getConfig().getBoolean("worlds.teleport-on-join", true)) {
                Location spawn = worlds.lobbySpawn();
                if (spawn != null) player.teleport(spawn);
            }
        }, 5L);
    }
    @EventHandler public void onQuit(PlayerQuitEvent event) {
        profile(event.getPlayer());
        profiles.save();
    }
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Block block = event.getBlock();
        int rank = worlds.rankFor(block.getWorld());
        if (rank < 0) { if (worlds.isLobby(block.getWorld())) event.setCancelled(true); return; }
        if (!player.hasPermission("arveeprison.admin") && (rank > profile(player).rank || !worlds.isMineBlock(block))) {
            event.setCancelled(true);
            message(player, "&cYou cannot mine here. Use /mines to select an unlocked mine.");
            return;
        }
        if (!worlds.isMineBlock(block)) { event.setCancelled(true); return; }
        if (worlds.isResetting(rank)) { event.setCancelled(true); return; }
        if (block.getType().isAir() || block.getType() == Material.BEDROCK) { event.setCancelled(true); return; }
        if (!getConfig().getBoolean("mines.allow-breaking-without-arvee-pickaxe", true) && !hasArveePickaxe(player)) {
            event.setCancelled(true);
            message(player, "&cYou must use an ARVEE pickaxe. Type /pickaxe get.");
            return;
        }
        event.setDropItems(false);
        event.setExpToDrop(0);
        PrisonProfile p = profile(player);
        creditBlock(p, rank, block.getType(), hasArveePickaxe(player));
        worlds.recordBreak(rank);
        if (p.jackhammer > 0 && hasArveePickaxe(player)
            && random.nextDouble() < p.jackhammer * getConfig().getDouble("pickaxe.jackhammer-chance-per-level", .008)) {
            for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) continue;
                if (worlds.isResetting(rank)) return;
                Block target = block.getRelative(dx, 0, dz);
                if (!worlds.isMineBlock(target) || target.getType().isAir()) continue;
                Material type = target.getType();
                target.setType(Material.AIR, false);
                creditBlock(p, rank, type, true);
                worlds.recordBreak(rank);
            }
        }
    }

    private void creditBlock(PrisonProfile p, int rank, Material blockType, boolean customPickaxe) {
        double amount = blockValue(p, rank, blockType);
        if (customPickaxe && p.fortune > 0 && random.nextDouble() < Math.min(.75, p.fortune * .10)) {
            amount *= 2.0;
        }
        if (p.autoSellUnlocked && p.autoSellEnabled) p.money = safeAdd(p.money, amount);
        else p.backpackValue = safeAdd(p.backpackValue, amount);
        p.minedBlocks++;
        p.dailyBlocks++;
        if (random.nextDouble() < getConfig().getDouble("progression.tokens-chance-per-block", 0.03)) {
            p.tokens = safeAddTokens(p.tokens, getConfig().getLong("progression.token-reward", 1));
        }
    }
    static double safeAdd(double a, double b) {
        double sum = a + b;
        return !Double.isFinite(sum) ? Double.MAX_VALUE : Math.max(0, sum);
    }
    static long safeAddTokens(long a, long b) { return b > Long.MAX_VALUE - a ? Long.MAX_VALUE : a + b; }

    @EventHandler(ignoreCancelled = true) public void onPlace(BlockPlaceEvent e) {
        if (worlds.rankFor(e.getBlock().getWorld()) >= 0 || worlds.isLobby(e.getBlock().getWorld())) e.setCancelled(true);
    }
    @EventHandler(ignoreCancelled = true) public void onExplosion(EntityExplodeEvent e) {
        if (worlds.rankFor(e.getLocation().getWorld()) >= 0 || worlds.isLobby(e.getLocation().getWorld())) e.blockList().clear();
    }
    @EventHandler(ignoreCancelled = true) public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player && (worlds.rankFor(e.getEntity().getWorld()) >= 0 || worlds.isLobby(e.getEntity().getWorld()))
            && (e.getCause() == EntityDamageEvent.DamageCause.FALL || e.getCause() == EntityDamageEvent.DamageCause.VOID)) {
            e.setCancelled(true);
        }
    }

    private boolean isPrisonPickaxe(ItemStack item) {
        return item != null && item.hasItemMeta()
            && item.getItemMeta().getPersistentDataContainer().has(pickaxeKey, PersistentDataType.BYTE);
    }
    public boolean hasArveePickaxe(Player player) {
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item.getType() != Material.NETHERITE_PICKAXE || !isPrisonPickaxe(item)) return false;
        String owner = item.getItemMeta().getPersistentDataContainer().get(ownerKey, PersistentDataType.STRING);
        return player.getUniqueId().toString().equals(owner);
    }
    @EventHandler(ignoreCancelled = true) public void onDrop(PlayerDropItemEvent e) {
        if (isPrisonPickaxe(e.getItemDrop().getItemStack())) {
            e.setCancelled(true);
            message(e.getPlayer(), "&cYour ARVEE pickaxe is soulbound and cannot be dropped.");
        }
    }
    @EventHandler public void onDeath(PlayerDeathEvent e) {
        e.getDrops().removeIf(this::isPrisonPickaxe);
    }
    public void grantPickaxe(Player player) {
        PrisonProfile p = profile(player);
        ItemStack pickaxe = new ItemStack(Material.NETHERITE_PICKAXE);
        ItemMeta meta = pickaxe.getItemMeta();
        meta.setDisplayName(color("&b&lARVEE &f&lPRISON PICKAXE"));
        int efficiency = getConfig().getInt("pickaxe.base-efficiency", 3)
            + p.efficiency * getConfig().getInt("pickaxe.efficiency-per-upgrade", 2);
        meta.addEnchant(Enchantment.EFFICIENCY, efficiency, true);
        meta.setUnbreakable(true);
        meta.getPersistentDataContainer().set(pickaxeKey, PersistentDataType.BYTE, (byte) 1);
        meta.getPersistentDataContainer().set(ownerKey, PersistentDataType.STRING, player.getUniqueId().toString());
        meta.setLore(Arrays.asList(color("&7Efficiency Upgrade: &b" + p.efficiency),
            color("&7Fortune Upgrade: &b" + p.fortune),
            color("&7Jackhammer Upgrade: &b" + p.jackhammer),
            color("&8Use /pickaxe to improve this tool.")));
        pickaxe.setItemMeta(meta);
        for (int slot = 0; slot < player.getInventory().getSize(); slot++) {
            ItemStack old = player.getInventory().getItem(slot);
            if (old != null && isPrisonPickaxe(old)) {
                player.getInventory().setItem(slot, pickaxe);
                message(player, "&aARVEE Pickaxe updated.");
                return;
            }
        }
        if (player.getInventory().firstEmpty() == -1) {
            message(player, "&cInventory full. Clear a slot before claiming your pickaxe.");
            return;
        }
        player.getInventory().addItem(pickaxe);
        message(player, "&aReceived your ARVEE Prison Pickaxe!");
    }

    private void rankup(Player player, boolean max) {
        PrisonProfile p = profile(player);
        int purchases = 0;
        while (p.rank < 25) {
            double cost = nextRankPrice(p.rank);
            if (p.money < cost) break;
            p.money -= cost;
            p.rank++;
            purchases++;
            if (!max) break;
        }
        if (purchases == 0) {
            if (p.rank == 25) message(player, "&eYou're rank Z! Save up for /prestige.");
            else message(player, "&cRank " + Amounts.rank(p.rank + 1) + " costs &6$" + Amounts.format(nextRankPrice(p.rank)) + "&c.");
            return;
        }
        message(player, "&aRanked up " + purchases + " time(s)! You're now &bRank " + Amounts.rank(p.rank) + "&a!");
    }
    private void prestige(Player player) {
        PrisonProfile p = profile(player);
        if (p.rank != 25) { message(player, "&cReach Rank Z before prestiging."); return; }
        double cost = prestigePrice(p.prestige);
        if (p.money < cost) { message(player, "&cPrestige costs &6$" + Amounts.format(cost) + "&c."); return; }
        p.money -= cost;
        p.prestige++;
        p.rank = 0;
        message(player, "&6&lPRESTIGE! &eNow Prestige " + p.prestige + ". You keep your upgrades and gain a permanent sell bonus!");
        worlds.travel(player, 0);
    }
    private void sell(Player player) {
        PrisonProfile p = profile(player);
        if (p.backpackValue <= 0) { message(player, "&eYour virtual backpack is empty."); return; }
        double amount = p.backpackValue;
        p.money = safeAdd(p.money, amount);
        p.backpackValue = 0;
        message(player, "&aSold your ores for &6$" + Amounts.format(amount) + "&a!");
    }
    private void toggleAutoSell(Player player) {
        PrisonProfile p = profile(player);
        if (!p.autoSellUnlocked) { message(player, "&cUnlock Auto-Sell through /pickaxe first."); return; }
        p.autoSellEnabled = !p.autoSellEnabled;
        message(player, "&fAuto-Sell is now " + (p.autoSellEnabled ? "&aENABLED" : "&cDISABLED"));
    }
    private void quests(Player player, boolean claim) {
        PrisonProfile p = profile(player);
        int target = getConfig().getInt("quests.daily-blocks", 400);
        if (!claim) {
            message(player, "&bDaily Quest: &fMine " + target + " blocks. Progress: &e" + Math.min(target, p.dailyBlocks) + "/" + target
                + "&7 | &fClaimed: " + (p.claimedDaily ? "&aYes" : "&cNo") + "&7 | &fUse /quests claim");
            return;
        }
        if (p.claimedDaily) { message(player, "&cYou've already claimed today's quest."); return; }
        if (p.dailyBlocks < target) { message(player, "&cMine " + (target - p.dailyBlocks) + " more blocks first."); return; }
        p.claimedDaily = true;
        double money = getConfig().getDouble("quests.reward-money", 30000);
        long tokens = getConfig().getLong("quests.reward-tokens", 75);
        p.money = safeAdd(p.money, money);
        p.tokens = safeAddTokens(p.tokens, tokens);
        message(player, "&aDaily quest complete! &6$" + Amounts.format(money) + " &7+ &e" + tokens + " tokens&a!");
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String cmd = command.getName().toLowerCase(Locale.ROOT);
        if (cmd.equals("prisonadmin")) return admin(sender, args);
        if (!(sender instanceof Player player)) { message(sender, "&cThis is a player command."); return true; }
        PrisonProfile p = profile(player);
        switch (cmd) {
            case "prison" -> menus.openMain(player);
            case "mines" -> menus.openMines(player);
            case "mine" -> {
                if (args.length == 0) { menus.openMines(player); return true; }
                int rank = Amounts.rank(args[0]);
                if (rank < 0) { message(player, "&cUse /mine A through /mine Z."); return true; }
                if (rank > p.rank && !player.hasPermission("arveeprison.admin")) {
                    message(player, "&cUnlock Rank " + Amounts.rank(rank) + " first."); return true;
                }
                worlds.travel(player, rank);
            }
            case "rankup" -> rankup(player, args.length > 0 && args[0].equalsIgnoreCase("max"));
            case "prestige" -> prestige(player);
            case "sell" -> sell(player);
            case "balance" -> message(player, "&fMoney: &6$" + Amounts.format(p.money) + "&7 | &fUnsold ore: &e$" + Amounts.format(p.backpackValue));
            case "tokens" -> message(player, "&fTokens: &e" + Amounts.format(p.tokens));
            case "pickaxe" -> {
                if (args.length > 0 && args[0].equalsIgnoreCase("get")) grantPickaxe(player);
                else menus.openUpgrades(player);
            }
            case "autosell" -> toggleAutoSell(player);
            case "quests" -> quests(player, args.length > 0 && args[0].equalsIgnoreCase("claim"));
            default -> { return false; }
        }
        return true;
    }

    public void upgrade(Player player, String type) {
        PrisonProfile p = profile(player);
        int cost;
        int level;
        int cap;
        switch (type) {
            case "efficiency" -> { level = p.efficiency; cap = getConfig().getInt("pickaxe.max-efficiency-upgrade", 6); cost = getConfig().getInt("pickaxe.efficiency-token-cost", 80) * (level + 1); }
            case "fortune" -> { level = p.fortune; cap = getConfig().getInt("pickaxe.max-fortune-upgrade", 5); cost = getConfig().getInt("pickaxe.fortune-token-cost", 125) * (level + 1); }
            case "jackhammer" -> { level = p.jackhammer; cap = getConfig().getInt("pickaxe.max-jackhammer-upgrade", 5); cost = getConfig().getInt("pickaxe.jackhammer-token-cost", 250) * (level + 1); }
            case "autosell" -> {
                if (p.autoSellUnlocked) { message(player, "&eAuto-Sell already unlocked. Toggle with /autosell."); return; }
                cost = getConfig().getInt("pickaxe.autosell-token-cost", 500);
                if (p.tokens < cost) { message(player, "&cAuto-Sell costs " + cost + " tokens."); return; }
                p.tokens -= cost;
                p.autoSellUnlocked = true;
                p.autoSellEnabled = true;
                message(player, "&aAuto-Sell unlocked and enabled!");
                menus.openUpgrades(player);
                return;
            }
            default -> { return; }
        }
        if (level >= cap) { message(player, "&eThat upgrade is already maxed."); return; }
        if (p.tokens < cost) { message(player, "&cYou need " + cost + " tokens for this upgrade."); return; }
        p.tokens -= cost;
        switch (type) {
            case "efficiency" -> p.efficiency++;
            case "fortune" -> p.fortune++;
            case "jackhammer" -> p.jackhammer++;
        }
        message(player, "&aUpgraded " + type + " to level " + (level + 1) + "!");
        // Refreshes the already-held pickaxe, or gives one when there is room.
        grantPickaxe(player);
        menus.openUpgrades(player);
    }

    private boolean admin(CommandSender sender, String[] args) {
        if (!sender.hasPermission("arveeprison.admin")) { message(sender, "&cNo permission."); return true; }
        if (args.length == 0) {
            message(sender, "&eAdmin: /prisonadmin setup | setspawn | reset <A-Z> | setrank <player> <A-Z> | addmoney <player> <amount> | addtokens <player> <amount> | reload | status");
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "setup" -> {
                World lobby = worlds.setupLobby();
                message(sender, lobby == null ? "&cCould not create Prison spawn." : "&aPrison lobby ready! Use /prisonadmin setspawn to change its spawn.");
            }
            case "setspawn" -> {
                if (!(sender instanceof Player player)) { message(sender, "&cStand at the intended spawn in-game."); break; }
                getConfig().set("worlds.lobby", player.getWorld().getName());
                getConfig().set("lobby-spawn", player.getLocation());
                saveConfig();
                worlds.markCustomLobbyReady();
                message(sender, "&aSpawn saved in world " + player.getWorld().getName() + ".");
            }
            case "reset" -> {
                if (args.length < 2 || Amounts.rank(args[1]) < 0) { message(sender, "&cUsage: /prisonadmin reset <A-Z>"); break; }
                int rank = Amounts.rank(args[1]);
                worlds.getMine(rank);
                worlds.queueReset(rank, false);
                message(sender, "&aQueued reset for mine " + Amounts.rank(rank) + ".");
            }
            case "setrank" -> {
                if (args.length < 3 || Amounts.rank(args[2]) < 0) { message(sender, "&cUsage: /prisonadmin setrank <online-player> <A-Z>"); break; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { message(sender, "&cPlayer not online."); break; }
                profile(target).rank = Amounts.rank(args[2]);
                message(sender, "&aRank updated for " + target.getName() + ".");
            }
            case "addmoney", "addtokens" -> {
                if (args.length < 3) { message(sender, "&cUsage: /prisonadmin " + sub + " <online-player> <positive-number>"); break; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { message(sender, "&cPlayer not online."); break; }
                try {
                    double value = Double.parseDouble(args[2]);
                    if (!Double.isFinite(value) || value <= 0) throw new NumberFormatException();
                    PrisonProfile p = profile(target);
                    if (sub.equals("addmoney")) p.money = safeAdd(p.money, value);
                    else {
                        if (value > Long.MAX_VALUE) throw new NumberFormatException();
                        p.tokens = safeAddTokens(p.tokens, (long) value);
                    }
                    message(sender, "&aAwarded " + Amounts.format(value) + " " + sub.substring(3) + " to " + target.getName() + ".");
                } catch (NumberFormatException e) { message(sender, "&cAmount must be a positive finite number."); }
            }
            case "reload" -> { reloadConfig(); message(sender, "&aConfig reloaded. Structural mine changes require a fresh world or restart."); }
            case "status" -> message(sender, "&bARVEE Prison 0.1.0 &7| &fLoaded worlds: &e" + Bukkit.getWorlds().stream().filter(w -> worlds.rankFor(w) >= 0).count() + "/26 &7| &fData: &eYAML");
            default -> message(sender, "&cUnknown subcommand. Use /prisonadmin.");
        }
        return true;
    }

    @Override public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);
        if (name.equals("mine") && args.length == 1) return match(args[0], rankLetters());
        if (name.equals("rankup") && args.length == 1) return match(args[0], List.of("max"));
        if (name.equals("pickaxe") && args.length == 1) return match(args[0], List.of("get"));
        if (name.equals("quests") && args.length == 1) return match(args[0], List.of("claim"));
        if (name.equals("prisonadmin")) {
            if (!sender.hasPermission("arveeprison.admin")) return Collections.emptyList();
            if (args.length == 1) return match(args[0], List.of("setup", "setspawn", "reset", "setrank", "addmoney", "addtokens", "reload", "status"));
            if (args.length == 2 && args[0].equalsIgnoreCase("reset")) return match(args[1], rankLetters());
            if (args.length == 3 && args[0].equalsIgnoreCase("setrank")) return match(args[2], rankLetters());
        }
        return Collections.emptyList();
    }
    private static List<String> rankLetters() {
        List<String> letters = new ArrayList<>();
        for (int i = 0; i < 26; i++) letters.add(Amounts.rank(i));
        return letters;
    }
    private static List<String> match(String token, List<String> options) {
        return options.stream().filter(option -> option.toLowerCase(Locale.ROOT).startsWith(token.toLowerCase(Locale.ROOT))).toList();
    }
}
