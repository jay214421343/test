package world.arvee.prison;

import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

public final class ProfileStore {
    private final ArveePrison plugin;
    private final Map<UUID, PrisonProfile> data = new HashMap<>();
    private final File file;
    public ProfileStore(ArveePrison plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "players.yml");
        load();
    }

    public PrisonProfile profile(UUID uuid) {
        return data.computeIfAbsent(uuid, id -> {
            PrisonProfile p = new PrisonProfile(id);
            p.money = plugin.getConfig().getDouble("progression.starting-money", 0);
            p.tokens = plugin.getConfig().getLong("progression.starting-tokens", 0);
            return p;
        });
    }

    public void load() {
        data.clear();
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        if (yaml.getConfigurationSection("players") == null) return;
        for (String key : yaml.getConfigurationSection("players").getKeys(false)) {
            try {
                UUID id = UUID.fromString(key);
                String path = "players." + key + ".";
                PrisonProfile p = new PrisonProfile(id);
                p.lastName = yaml.getString(path + "name", "");
                p.rank = Math.max(0, Math.min(25, yaml.getInt(path + "rank", 0)));
                p.prestige = Math.max(0, yaml.getInt(path + "prestige", 0));
                p.money = Math.max(0, yaml.getDouble(path + "money", 0));
                p.tokens = Math.max(0, yaml.getLong(path + "tokens", 0));
                p.backpackValue = Math.max(0, yaml.getDouble(path + "backpack", 0));
                p.minedBlocks = Math.max(0, yaml.getLong(path + "mined", 0));
                p.efficiency = Math.max(0, yaml.getInt(path + "efficiency", 0));
                p.fortune = Math.max(0, yaml.getInt(path + "fortune", 0));
                p.jackhammer = Math.max(0, yaml.getInt(path + "jackhammer", 0));
                p.autoSellUnlocked = yaml.getBoolean(path + "autosell-unlocked", false);
                p.autoSellEnabled = yaml.getBoolean(path + "autosell-enabled", false);
                p.questDay = yaml.getString(path + "quest-day", p.questDay);
                p.dailyBlocks = Math.max(0, yaml.getInt(path + "daily-blocks", 0));
                p.claimedDaily = yaml.getBoolean(path + "daily-claimed", false);
                data.put(id, p);
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("Skipping invalid profile ID " + key);
            }
        }
        plugin.getLogger().info("Loaded " + data.size() + " prison profiles");
    }

    public void save() {
        YamlConfiguration yaml = new YamlConfiguration();
        for (PrisonProfile p : data.values()) {
            String path = "players." + p.uuid + ".";
            yaml.set(path + "name", p.lastName);
            yaml.set(path + "rank", p.rank);
            yaml.set(path + "prestige", p.prestige);
            yaml.set(path + "money", p.money);
            yaml.set(path + "tokens", p.tokens);
            yaml.set(path + "backpack", p.backpackValue);
            yaml.set(path + "mined", p.minedBlocks);
            yaml.set(path + "efficiency", p.efficiency);
            yaml.set(path + "fortune", p.fortune);
            yaml.set(path + "jackhammer", p.jackhammer);
            yaml.set(path + "autosell-unlocked", p.autoSellUnlocked);
            yaml.set(path + "autosell-enabled", p.autoSellEnabled);
            yaml.set(path + "quest-day", p.questDay);
            yaml.set(path + "daily-blocks", p.dailyBlocks);
            yaml.set(path + "daily-claimed", p.claimedDaily);
        }
        try {
            File tmp = new File(file.getParentFile(), "players.yml.tmp");
            yaml.save(tmp);
            try {
                java.nio.file.Files.move(tmp.toPath(), file.toPath(),
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                    java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            } catch (java.nio.file.AtomicMoveNotSupportedException ex) {
                java.nio.file.Files.move(tmp.toPath(), file.toPath(),
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Unable to save Prison profiles", ex);
        }
    }
}
