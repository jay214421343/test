package world.arvee.prison;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.UUID;

public final class PrisonProfile {
    public final UUID uuid;
    public String lastName;
    public int rank = 0;
    public int prestige = 0;
    public double money;
    public long tokens;
    public double backpackValue = 0;
    public long minedBlocks = 0;
    public int efficiency = 0;
    public int fortune = 0;
    public int jackhammer = 0;
    public boolean autoSellUnlocked = false;
    public boolean autoSellEnabled = false;
    public String questDay = LocalDate.now(ZoneOffset.UTC).toString();
    public int dailyBlocks = 0;
    public boolean claimedDaily = false;

    public PrisonProfile(UUID uuid) { this.uuid = uuid; }

    public void refreshDaily() {
        String today = LocalDate.now(ZoneOffset.UTC).toString();
        if (!today.equals(questDay)) {
            questDay = today;
            dailyBlocks = 0;
            claimedDaily = false;
        }
    }

    public double multiplier(double bonusPerPrestige) {
        return 1 + prestige * bonusPerPrestige;
    }
}
