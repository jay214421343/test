package world.arvee.prison;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import java.util.ArrayList;
import java.util.List;

public final class PrisonMenus implements Listener {
    private final ArveePrison plugin;
    private static final String MAIN = "ARVEE | Prison";
    private static final String MINES = "ARVEE | Mine Selector";
    private static final String UPGRADES = "ARVEE | Pickaxe Upgrades";

    public PrisonMenus(ArveePrison plugin) {
        this.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }
    private ItemStack item(Material material, String name, String... description) {
        ItemStack result = new ItemStack(material);
        ItemMeta meta = result.getItemMeta();
        meta.setDisplayName(plugin.color(name));
        List<String> lore = new ArrayList<>();
        for (String s : description) lore.add(plugin.color(s));
        meta.setLore(lore);
        result.setItemMeta(meta);
        return result;
    }
    private void fill(Inventory inventory) {
        ItemStack filler = item(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int s = 0; s < inventory.getSize(); s++) inventory.setItem(s, filler);
    }
    public void openMain(Player p) {
        PrisonProfile data = plugin.profile(p);
        Inventory gui = Bukkit.createInventory(null, 27, MAIN);
        fill(gui);
        gui.setItem(10, item(Material.NETHERITE_PICKAXE, "&b&lSELECT MINE", "&7Browse all 26 Prison mines", "&eClick to open"));
        gui.setItem(11, item(Material.EMERALD, "&a&lRANK UP", "&7Current: &f" + Amounts.rank(data.rank),
            "&7Next cost: &6$" + Amounts.format(plugin.nextRankPrice(data.rank)), "&eClick to rank up"));
        gui.setItem(12, item(Material.GOLD_INGOT, "&6&lSELL ORES", "&7Unsold: &6$" + Amounts.format(data.backpackValue), "&eClick to sell"));
        gui.setItem(13, item(Material.DIAMOND_PICKAXE, "&b&lPICKAXE UPGRADES", "&7Tokens: &e" + Amounts.format(data.tokens), "&eClick to open"));
        gui.setItem(14, item(Material.WRITABLE_BOOK, "&d&lDAILY QUEST", "&7Progress: &f" + data.dailyBlocks + " blocks", "&eClick to see progress"));
        gui.setItem(15, item(Material.NETHER_STAR, "&6&lPRESTIGE", "&7Current: &f" + data.prestige, "&7Reach rank Z to unlock", "&eClick to prestige"));
        gui.setItem(16, item(Material.COMPARATOR, "&e&lAUTO-SELL", "&7Unlocked: &f" + data.autoSellUnlocked,
            "&7Enabled: &f" + data.autoSellEnabled, "&eClick to toggle"));
        gui.setItem(22, item(Material.PAPER, "&f&lYOUR PROFILE", "&7Rank: &b" + Amounts.rank(data.rank),
            "&7Money: &6$" + Amounts.format(data.money), "&7Tokens: &e" + Amounts.format(data.tokens),
            "&7Total mined: &f" + Amounts.format(data.minedBlocks)));
        p.openInventory(gui);
    }
    public void openMines(Player p) {
        PrisonProfile data = plugin.profile(p);
        Inventory gui = Bukkit.createInventory(null, 54, MINES);
        fill(gui);
        for (int r = 0; r < 26; r++) {
            boolean unlocked = r <= data.rank || p.hasPermission("arveeprison.admin");
            gui.setItem(r, item(unlocked ? Material.EMERALD_ORE : Material.REDSTONE_BLOCK,
                (unlocked ? "&a" : "&c") + "&lMINE " + Amounts.rank(r),
                unlocked ? "&aUnlocked" : "&cLocked - rank up to unlock", "&7World: &f" + plugin.worlds().mineName(r),
                unlocked ? "&eClick to teleport" : "&7Use /rankup"));
        }
        gui.setItem(49, item(Material.ARROW, "&bBack to Prison Menu"));
        p.openInventory(gui);
    }
    public void openUpgrades(Player p) {
        PrisonProfile data = plugin.profile(p);
        Inventory gui = Bukkit.createInventory(null, 27, UPGRADES);
        fill(gui);
        int efficiencyCost = plugin.getConfig().getInt("pickaxe.efficiency-token-cost", 80) * (data.efficiency + 1);
        int fortuneCost = plugin.getConfig().getInt("pickaxe.fortune-token-cost", 125) * (data.fortune + 1);
        int jackhammerCost = plugin.getConfig().getInt("pickaxe.jackhammer-token-cost", 250) * (data.jackhammer + 1);
        gui.setItem(10, item(Material.GOLDEN_PICKAXE, "&bEfficiency " + data.efficiency,
            "&7Next upgrade: &e" + efficiencyCost + " tokens", "&eClick to purchase"));
        gui.setItem(11, item(Material.DIAMOND, "&bFortune " + data.fortune,
            "&7Doubles ore value sometimes", "&7Next upgrade: &e" + fortuneCost + " tokens", "&eClick to purchase"));
        gui.setItem(12, item(Material.TNT, "&cJackhammer " + data.jackhammer,
            "&7Occasionally breaks surrounding blocks", "&7Next upgrade: &e" + jackhammerCost + " tokens", "&eClick to purchase"));
        gui.setItem(13, item(Material.HOPPER, "&aAuto-Sell", data.autoSellUnlocked ? "&aUnlocked" : "&7Cost: &e" +
            plugin.getConfig().getInt("pickaxe.autosell-token-cost", 500) + " tokens", "&eClick to unlock"));
        gui.setItem(14, item(Material.NETHERITE_PICKAXE, "&bClaim / Refresh Pickaxe", "&eClick to claim"));
        gui.setItem(22, item(Material.SUNFLOWER, "&6Tokens: &e" + Amounts.format(data.tokens)));
        gui.setItem(26, item(Material.ARROW, "&bBack"));
        p.openInventory(gui);
    }

    @EventHandler public void click(InventoryClickEvent e) {
        String title = e.getView().getTitle();
        if (!title.equals(MAIN) && !title.equals(MINES) && !title.equals(UPGRADES)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        int slot = e.getRawSlot();
        if (slot < 0 || slot >= e.getView().getTopInventory().getSize()) return;
        ItemStack clicked = e.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.BLACK_STAINED_GLASS_PANE) return;
        // Bukkit warns against opening or closing inventories inside InventoryClickEvent.
        // Dispatch menu actions on the next server tick instead.
        Bukkit.getScheduler().runTask(plugin, () -> handleClick(title, p, slot));
    }

    private void handleClick(String title, Player p, int slot) {
        if (!p.isOnline()) return;
        switch (title) {
            case MAIN -> {
                switch (slot) {
                    case 10 -> openMines(p);
                    case 11 -> { p.closeInventory(); p.performCommand("rankup"); }
                    case 12 -> { p.closeInventory(); p.performCommand("sell"); }
                    case 13 -> openUpgrades(p);
                    case 14 -> { p.closeInventory(); p.performCommand("quests"); }
                    case 15 -> { p.closeInventory(); p.performCommand("prestige"); }
                    case 16 -> { p.closeInventory(); p.performCommand("autosell"); }
                    default -> { }
                }
            }
            case MINES -> {
                if (slot == 49) { openMain(p); return; }
                if (slot >= 26) return;
                int mine = slot;
                PrisonProfile data = plugin.profile(p);
                if (mine > data.rank && !p.hasPermission("arveeprison.admin")) {
                    plugin.message(p, "&cThat mine is locked. Use /rankup."); return;
                }
                p.closeInventory();
                plugin.worlds().travel(p, mine);
            }
            case UPGRADES -> {
                switch (slot) {
                    case 10 -> plugin.upgrade(p, "efficiency");
                    case 11 -> plugin.upgrade(p, "fortune");
                    case 12 -> plugin.upgrade(p, "jackhammer");
                    case 13 -> plugin.upgrade(p, "autosell");
                    case 14 -> plugin.grantPickaxe(p);
                    case 26 -> openMain(p);
                    default -> { }
                }
            }
            default -> { }
        }
    }
}
